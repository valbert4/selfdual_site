# Extremal 72 — genus-3 (triweight) routines

Reusable tooling for computing and constraining the genus-3 weight enumerator
(triweight) of doubly-even self-dual codes, developed for the [72,36,16] search.

## Requirements
- SageMath (>= 9.5) — `from sage.all import ...`
- Python 3.10+ with numpy

## Layout
- top level: orbit/basis builders, d_n+ atoms, self-equation null spaces,
  validators (`triweight_lib.py`, `triweight_orbits.py`, `dnplus.py`,
  `make_dnplus_atoms.py`, `selfeq_nullspace.sage`, `validate_*.py`, ...).
- `V_play/`: the exact 6-dim invariant-space recovery and pinning experiments.
- `cft/`: the genus-3 theta map (projection of the triweight onto Siegel
  modular forms / lattice functions) and the splitting/Fourier-Jacobi checks.

All paths are relative to this directory; nothing points outside the bundle.
Large precomputed caches and the genus-3 data artifacts are distributed
separately (see the site's Enumerators tab).
