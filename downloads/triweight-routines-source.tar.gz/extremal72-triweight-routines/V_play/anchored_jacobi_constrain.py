#!/usr/bin/env python3
"""Constrain the 5 triweight freedoms by the anchored genus-2 Jacobi (TEST.md
section 17).

The triweight's w-weight-16 slice, re-indexed to the anchored (b,r) states and
divided by A_16, is the average anchored genus-2 Jacobi J_avg, which must lie in
the pre-computed 8-dim affine family

    x = x_p + sum_{i=1}^{8} t_i homo_i      (anchored_jacobi/anchored_genus2_family.json)

So  v_slice(a)/A_16 - x_p  must be in span(homo), where v = R_0 + sum a_i F_i.
Equivalently  v_slice(a) - 64*A_16*x_p  in span(homo)  (R_k = N_k/64).

The freedom AFTER this constraint is
    a_freedom = 5 - (rank[F_slices | homo] - rank[homo]).
If a_freedom < 5 the anchored Jacobi REDUCES the dimension.  We also check that the
genuine slice (R_0) is consistent with the family (else it would be an obstruction).
"""
import gzip
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
AJ = os.path.join(os.path.dirname(os.path.dirname(HERE)), "anchored_jacobi")
sys.path.insert(0, SP)
sys.path.insert(0, AJ)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                              # noqa: E402
from reconstruct_charzero import build_structure              # noqa: E402
import build_genus2_system as g2                              # noqa: E402

A16 = 249849                  # number of weight-16 words of the extremal [72,36,16]
POW73 = (73 ** np.arange(8)).astype(object)


def gf_rank(M, p):
    M = [[int(x) % p for x in row] for row in M]
    nr = len(M); nc = len(M[0]) if M else 0
    r = 0
    for c in range(nc):
        piv = None
        for i in range(r, nr):
            if M[i][c] % p:
                piv = i; break
        if piv is None:
            continue
        M[r], M[piv] = M[piv], M[r]
        inv = pow(M[r][c], p - 2, p)
        M[r] = [(x * inv) % p for x in M[r]]
        for i in range(nr):
            if i != r and M[i][c]:
                f = M[i][c]
                M[i] = [(M[i][k] - f * M[r][k]) % p for k in range(nc)]
        r += 1
        if r == nr:
            break
    return r


def main():
    print("building anchored genus-2 orbits ...", flush=True)
    valid, orbits, orbit_of = g2.build_support_and_orbits()
    norb = len(orbits)
    print("anchored orbits: %d" % norb, flush=True)

    with open(os.path.join(AJ, "anchored_genus2_family.json")) as fh:
        fam = json.load(fh)
    assert fam["norb"] == norb, "orbit count mismatch %d vs %d" % (fam["norb"], norb)
    x_p = [int(x) for x in fam["x_p"]]
    homo = [[int(x) for x in row] for row in fam["homo"]]      # 8 x norb
    fdim = fam["free_dimension"]
    print("family: free_dim=%d, %d homo vectors" % (fdim, len(homo)), flush=True)

    # triweight V + monomial->orbit map
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; g = int(V["genuine_row"])
    free_idx = [k for k in range(len(N)) if k != g]
    t = Target.load(72, "mindist")
    struct = build_structure(t)
    mono2col = struct[0]
    raw = t.raw
    keys = (raw.astype(object) * POW73).sum(1)
    key2orb = {int(keys[i]): int(mono2col[i]) for i in range(raw.shape[0])}
    print("target support: %d monomials -> %d orbits" % (raw.shape[0], len(t.orbit_items)), flush=True)

    # slice: for each anchored orbit, the triweight orbit value (or 0 if monomial
    # falls outside the mindist support)
    Ng = N[g]; Nf = [N[k] for k in free_idx]
    R0s = [0] * norb
    Fs = [[0] * norb for _ in range(len(Nf))]
    in_supp = 0
    for o in range(norb):
        b, r = orbits[o][0]                                    # rep state
        mono = (r[0], r[1], r[2], r[3], b[0], b[1], b[2], b[3])  # (n0..n7)
        k = sum(int(mono[p]) * (73 ** p) for p in range(8))
        idx = key2orb.get(k)
        if idx is not None:
            in_supp += 1
            R0s[o] = int(Ng[idx])
            for i in range(len(Nf)):
                Fs[i][o] = int(Nf[i][idx])
    print("anchored orbits mapping INTO mindist support: %d / %d" % (in_supp, norb), flush=True)

    # ranks mod a large prime
    p = 2_000_000_011
    rk_homo = gf_rank(homo, p)
    Fmat = [[Fs[i][o] for i in range(len(Nf))] for o in range(norb)]      # norb x 5
    homoT = [[homo[i][o] for i in range(len(homo))] for o in range(norb)]  # norb x 8
    FplusH = [Fmat[o] + homoT[o] for o in range(norb)]                    # norb x 13
    rk_FH = gf_rank(FplusH, p)
    a_freedom = 5 - (rk_FH - rk_homo)
    print("\nrank(homo)=%d ; rank[F_slices | homo]=%d" % (rk_homo, rk_FH), flush=True)
    print("=> anchored-Jacobi a_freedom = 5 - (%d - %d) = %d" % (rk_FH, rk_homo, a_freedom), flush=True)

    # consistency of the genuine slice: rhs = 64*A16*x_p - R0_slice  in span(homo)?
    rhs = [(64 * A16 * x_p[o] - R0s[o]) for o in range(norb)]
    H_rhs = [homoT[o] + [rhs[o]] for o in range(norb)]
    rk_Hrhs = gf_rank(H_rhs, p)
    consistent = (rk_Hrhs == rk_homo)
    print("genuine slice in family (R_0 consistent)? rank[homo|rhs]=%d vs rank[homo]=%d -> %s"
          % (rk_Hrhs, rk_homo, "YES" if consistent else "NO (obstruction!)"), flush=True)

    verdict = ("REDUCES freedom 5 -> %d" % a_freedom) if a_freedom < 5 else "no reduction (vacuous at this level)"
    if not consistent:
        verdict = "GENUINE SLICE NOT IN FAMILY -> genus-3 obstruction (nonexistence)"
    print("\nverdict: %s" % verdict, flush=True)
    with open(os.path.join(HERE, "anchored_jacobi_verdict.json"), "w") as fh:
        json.dump({"a_freedom": int(a_freedom), "genuine_consistent": bool(consistent),
                   "rank_homo": int(rk_homo), "rank_F_homo": int(rk_FH),
                   "anchored_orbits": norb, "in_support": in_supp}, fh)


if __name__ == "__main__":
    main()
