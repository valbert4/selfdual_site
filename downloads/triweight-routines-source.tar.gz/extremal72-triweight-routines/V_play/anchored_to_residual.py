#!/usr/bin/env python3
"""Does the genus-3 triweight pin the [56,21,16] residual biweight beyond RECURSIVE.md
section 24?

Chain:  triweight v  ->  w-weight-16 slice = anchored genus-2 Jacobi (8-dim family)
        ->  b=(16,0,0,0) sub-block "B_D" = biweight of the residual C_B=[56,21,16].

RECURSIVE.md section 24: the STANDALONE residual MacWilliams gives a 9-dim biweight
family; projecting the 8-dim anchored Jacobi family to B_D cuts it to 5-dim.

The triweight provides the anchored Jacobi as a SPECIFIC point parametrized by its 5
freedoms (image dim = rank(F_slices)).  So the triweight's residual biweight family
= R0|_BD + span(F_slices|_BD).  We compute:
  rk_homo_BD  = dim of the section-24 biweight family (= span homo|_BD)   [expect 5]
  rk_F_BD     = dim the triweight pins it to                              [the answer]
If rk_F_BD < rk_homo_BD the triweight CUTS the residual biweight below section 24.
"""
import gzip
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
AJ = os.path.join(os.path.dirname(os.path.dirname(HERE)), "anchored_jacobi")
sys.path.insert(0, SP); sys.path.insert(0, AJ)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                              # noqa: E402
from reconstruct_charzero import build_structure              # noqa: E402
import build_genus2_system as g2                              # noqa: E402


def gf_rank(rows, p):
    M = [[int(x) % p for x in row] for row in rows]
    nr = len(M); nc = len(M[0]) if M else 0
    r = 0
    for c in range(nc):
        piv = next((i for i in range(r, nr) if M[i][c] % p), None)
        if piv is None:
            continue
        M[r], M[piv] = M[piv], M[r]
        inv = pow(M[r][c], p - 2, p)
        M[r] = [(x * inv) % p for x in M[r]]
        for i in range(nr):
            if i != r and M[i][c]:
                f = M[i][c]; M[i] = [(M[i][k] - f * M[r][k]) % p for k in range(nc)]
        r += 1
        if r == nr:
            break
    return r


def main():
    valid, orbits, orbit_of = g2.build_support_and_orbits()
    norb = len(orbits)
    with open(os.path.join(AJ, "anchored_genus2_family.json")) as fh:
        fam = json.load(fh)
    homo = [[int(x) for x in row] for row in fam["homo"]]      # 8 x norb
    print("anchored orbits=%d ; family free_dim=%d" % (norb, fam["free_dimension"]), flush=True)

    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; g = int(V["genuine_row"])
    free_idx = [k for k in range(len(N)) if k != g]
    Ng = N[g]; Nf = [N[k] for k in free_idx]

    t = Target.load(72, "mindist")
    mono2col = build_structure(t)[0]
    raw = t.raw
    POW = [73 ** p for p in range(8)]
    keys = (raw.astype(object) * np.array(POW, dtype=object)).sum(1)
    key2orb = {int(keys[i]): int(mono2col[i]) for i in range(raw.shape[0])}

    # slices + B_D mask (rep marked-comp is pure: one entry == 16 => u,v vanish on B)
    Fs = [[0] * norb for _ in range(len(Nf))]
    is_BD = [False] * norb
    for o in range(norb):
        b, r = orbits[o][0]
        if max(b) == 16:
            is_BD[o] = True
        mono = (r[0], r[1], r[2], r[3], b[0], b[1], b[2], b[3])
        idx = key2orb.get(sum(int(mono[p]) * POW[p] for p in range(8)))
        if idx is not None:
            for i in range(len(Nf)):
                Fs[i][o] = int(Nf[i][idx])
    bd = [o for o in range(norb) if is_BD[o]]
    print("B_D (residual-biweight) orbits: %d / %d" % (len(bd), norb), flush=True)

    p = 2_000_000_011
    homoT = [[homo[i][o] for i in range(len(homo))] for o in range(norb)]
    Fmat = [[Fs[i][o] for i in range(len(Nf))] for o in range(norb)]

    rk_homo = gf_rank(homoT, p)
    rk_F = gf_rank(Fmat, p)
    rk_homo_BD = gf_rank([homoT[o] for o in bd], p)
    rk_F_BD = gf_rank([Fmat[o] for o in bd], p)
    rk_FH_BD = gf_rank([Fmat[o] + homoT[o] for o in bd], p)
    print("\n-- full anchored Jacobi --")
    print("rank(homo)=%d (family dim) ; rank(F_slices)=%d (triweight image dim)" % (rk_homo, rk_F))
    print("-- residual biweight (B_D block) --")
    print("rank(homo|BD)=%d  <- section-24 standalone biweight family dim (expect 5)" % rk_homo_BD)
    print("rank(F|BD)   =%d  <- dimension the TRIWEIGHT pins the residual biweight to" % rk_F_BD)
    print("rank([F|homo]|BD)=%d" % rk_FH_BD)
    cut = rk_homo_BD - rk_F_BD
    print("\n=> triweight %s the section-24 residual biweight (5 -> %d ; cut %d dims)"
          % ("CUTS" if cut > 0 else "does NOT cut", rk_F_BD, cut), flush=True)
    with open(os.path.join(HERE, "residual_biweight_verdict.json"), "w") as fh:
        json.dump({"section24_dim": rk_homo_BD, "triweight_dim": rk_F_BD,
                   "dims_cut": cut, "triweight_image_dim": rk_F, "family_dim": rk_homo,
                   "BD_orbits": len(bd)}, fh)


if __name__ == "__main__":
    main()
