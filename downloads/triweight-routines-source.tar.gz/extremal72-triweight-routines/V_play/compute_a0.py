#!/usr/bin/env python3
"""Compute a_0: the unique design-forced residue of the 5 freedom parameters.

The 5-design (Jacobi-integrality) congruences have rank 5 mod each odd prime in
{3,5,7,17,23,71}, so they DETERMINE a uniquely mod each.  CRT -> a_0 mod
M_odd = 3*5*7*17*23*71.  (Higher prime powers 3^3 and the 2-adic part refine
further; the 2-adic system is only rank 1, so it barely pins.)  We report a_0,
build the residue representative v_0 = R_0 + sum a_0_i F_i, and check the box.
"""
import gzip
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
sys.path.insert(0, SP)
sys.set_int_max_str_digits(10_000_000)


def solve_unique_modp(A, b, p):
    """Unique solution of A x = b over GF(p) when A has full column rank; else None."""
    m, n = A.shape
    M = np.concatenate([A % p, (b % p).reshape(-1, 1)], axis=1).astype(np.int64)
    piv_col = [-1] * n
    r = 0
    for c in range(n):
        nz = np.nonzero(M[r:, c])[0]
        if nz.size == 0:
            continue
        piv = r + int(nz[0])
        M[[r, piv]] = M[[piv, r]]
        inv = pow(int(M[r, c]), p - 2, p)
        M[r] = (M[r] * inv) % p
        col = M[:, c].copy(); col[r] = 0
        nzr = np.nonzero(col)[0]
        if nzr.size:
            M[nzr] = (M[nzr] - np.multiply.outer(col[nzr], M[r])) % p
        piv_col[c] = r
        r += 1
        if r == m:
            break
    if any(pc == -1 for pc in piv_col):
        return None                      # not full column rank -> not unique
    # consistency: rows below rank must be zero in the b column
    for rr in range(r, m):
        if M[rr, n] % p:
            return None
    return [int(M[piv_col[i], n]) % p for i in range(n)]


def crt_pair(r1, m1, r2, m2):
    from math import gcd
    g = gcd(m1, m2)
    if (r2 - r1) % g:
        raise ValueError("CRT inconsistent")
    lcm = m1 // g * m2
    inv = pow((m1 // g) % (m2 // g), -1, m2 // g) if m2 // g > 1 else 0
    x = (r1 + (m1) * (((r2 - r1) // g * inv) % (m2 // g))) % lcm
    return x, lcm


def main():
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; DEN = int(V["den"]); g = int(V["genuine_row"])
    free_idx = [k for k in range(len(N)) if k != g]
    Ng = [int(x) for x in N[g]]
    Nf = [[int(x) for x in N[k]] for k in free_idx]
    ncol = len(Ng); free_dim = len(Nf)
    with gzip.open(os.path.join(HERE, "jacobi_divisors.json.gz"), "rt") as fh:
        d = json.load(fh)["divisors"]

    ODD = [3, 5, 7, 17, 23, 71]
    a_res = [(0, 1)] * free_dim          # (residue, modulus) per parameter
    for p in ODD:
        rows = [j for j in range(ncol) if d[j] % p == 0]
        A = np.array([[int(Nf[i][j]) % p for i in range(free_dim)] for j in rows], dtype=np.int64)
        b = np.array([(-int(Ng[j])) % p for j in rows], dtype=np.int64)
        sol = solve_unique_modp(A, b, p)
        if sol is None:
            print("p=%d: NOT unique / inconsistent -> abort" % p); return
        print("p=%-3d : a = %s (mod %d)" % (p, sol, p), flush=True)
        for i in range(free_dim):
            a_res[i] = crt_pair(a_res[i][0], a_res[i][1], sol[i], p)

    M_odd = a_res[0][1]
    a0 = [a_res[i][0] for i in range(free_dim)]
    print("\n=== a_0 (unique design residue mod M_odd) ===")
    print("M_odd = 3*5*7*17*23*71 = %d  (~2^%.1f)" % (M_odd, M_odd.bit_length()))
    print("a_0 =", a0)

    # 2-adic rank (integrality mod 2, all orbits): how much the 2-part pins
    A2 = np.array([[int(Nf[i][j]) % 2 for i in range(free_dim)] for j in range(ncol)], dtype=np.int64)
    # rank over GF(2)
    M = A2.copy(); r = 0
    for c in range(free_dim):
        nz = np.nonzero(M[r:, c])[0]
        if nz.size == 0:
            continue
        piv = r + int(nz[0]); M[[r, piv]] = M[[piv, r]]
        col = M[:, c].copy(); col[r] = 0
        M[np.nonzero(col)[0]] ^= M[r]
        r += 1
        if r == M.shape[0]:
            break
    print("2-adic integrality: GF(2) rank = %d / %d  -> 2-part pins only %d of 5 directions mod 2"
          % (r, free_dim, r))

    # residue representative v_0 = R_0 + sum a0_i F_i  (a0 small);  R_k = N_k/64
    with gzip.open(os.path.join(HERE, "charzero_integer.json.gz"), "rt") as fh:
        bounds = json.load(fh)["coefficient_bounds"]
    v0_num = [Ng[j] + sum(a0[i] * Nf[i][j] for i in range(free_dim)) for j in range(ncol)]
    intg = all(x % DEN == 0 for x in v0_num)
    neg = sum(1 for x in v0_num if x < 0)
    over = sum(1 for j, x in enumerate(v0_num) if x > DEN * int(bounds[j]))
    print("\nresidue representative v_0 = R_0 + sum a_0_i F_i:")
    print("  integer (div by 64)? %s ; negative coords: %d ; over-bound coords: %d" % (intg, neg, over))
    print("  (v_0 is the residue rep; positive enumerators are a_0 + M_odd*b for suitable integer b)")

    with gzip.open(os.path.join(HERE, "a0.json.gz"), "wt") as fh:
        json.dump({"a0": a0, "M_odd": M_odd, "primes_used": ODD, "two_adic_rank": int(r)}, fh)
    print("\nsaved -> a0.json.gz")


if __name__ == "__main__":
    main()
