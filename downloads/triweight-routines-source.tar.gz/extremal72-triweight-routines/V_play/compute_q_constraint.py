#!/usr/bin/env python3
"""Compute the single linear constraint the triweight imposes on the anchored
B_D parameters q_0..q_7 used by n56_biweight/biweight_global_mixture_glpsol.py.

The anchored B_D family point is  P(q) = x_p|BD + sum_j q_j homo_j|BD  (5-dim).
The triweight pins it to  R0_x + span(F|BD)  (4-dim), with R0_x = R0|BD/(64*A16).
The 1-dim direction e in span(homo|BD) orthogonal to span(F|BD) gives the pinned
constraint
        sum_j (homo_j|BD . e) q_j  =  (R0_x - x_p|BD) . e
i.e.    sum_j phi_j q_j = c .

Saved to triweight_q_constraint.json (exact rationals).  Heavy sanity checks:
 - R0_x - x_p|BD must lie in span(homo|BD)  (genuine point is in the family);
 - phi must be non-trivial on the family (else the constraint is vacuous);
 - the genuine q^0 must satisfy phi.q^0 = c.
"""
import gzip
import json
import os
import sys
from fractions import Fraction as Fr

import numpy as np
import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
AJ = os.path.join(os.path.dirname(os.path.dirname(HERE)), "anchored_jacobi")
sys.path.insert(0, SP); sys.path.insert(0, AJ)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                              # noqa: E402
from reconstruct_charzero import build_structure              # noqa: E402
import build_genus2_system as g2                              # noqa: E402

A16 = 249849
DEN = 64


def main():
    valid, orbits, orbit_of = g2.build_support_and_orbits()
    norb = len(orbits)
    with open(os.path.join(AJ, "anchored_genus2_family.json")) as fh:
        fam = json.load(fh)
    x_p = [int(x) for x in fam["x_p"]]
    homo = [[int(x) for x in row] for row in fam["homo"]]      # 8 x norb

    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; g = int(V["genuine_row"])
    free_idx = [k for k in range(len(N)) if k != g]
    Ng = N[g]; Nf = [N[k] for k in free_idx]

    t = Target.load(72, "mindist")
    mono2col = build_structure(t)[0]
    raw = t.raw
    POW = [73 ** p for p in range(8)]
    keys = (raw.astype(object) * np.array(POW, dtype=object)).sum(1)
    key2orb = {int(keys[i]): int(mono2col[i]) for i in range(raw.shape[0])}

    bd = []
    R0s = {}; Fs = {i: {} for i in range(len(Nf))}
    for o in range(norb):
        b, r = orbits[o][0]
        if max(b) != 16:
            continue
        bd.append(o)
        mono = (r[0], r[1], r[2], r[3], b[0], b[1], b[2], b[3])
        idx = key2orb.get(sum(int(mono[p]) * POW[p] for p in range(8)))
        R0s[o] = int(Ng[idx]) if idx is not None else 0
        for i in range(len(Nf)):
            Fs[i][o] = int(Nf[i][idx]) if idx is not None else 0
    nbd = len(bd)
    print("B_D orbits: %d" % nbd, flush=True)

    # exact matrices over QQ on the B_D block
    H = sp.Matrix([[homo[j][o] for o in bd] for j in range(8)])          # 8 x nbd
    F = sp.Matrix([[Fs[i][o] for o in bd] for i in range(len(Nf))])      # 5 x nbd
    xp = sp.Matrix([x_p[o] for o in bd])                                  # nbd x 1
    R0x = sp.Matrix([sp.Rational(R0s[o], DEN * A16) for o in bd])         # nbd x 1

    rank_H = H.rank(); rank_F = F.rank()
    print("rank(homo|BD)=%d  rank(F|BD)=%d" % (rank_H, rank_F), flush=True)

    # e in rowspace(H), e . F_i = 0  ->  e = y H, y in nullspace(F H^T)
    FHt = F * H.T                                                          # 5 x 8
    ys = FHt.nullspace()
    e = None
    for y in ys:
        cand = (y.T * H).T                                                 # nbd x 1
        if any(v != 0 for v in cand):
            e = cand; break
    assert e is not None, "no nonzero e (triweight did not cut)"
    # sanity: e orthogonal to every F_i
    assert all((F.row(i) * e)[0] == 0 for i in range(F.rows)), "e not orthogonal to F"

    # sanity: genuine point in family -> R0x - xp in rowspace(H)
    diff = R0x - xp
    aug = H.T.row_join(diff)
    assert aug.rank() == H.T.rank(), "R0x - xp NOT in span(homo|BD) (genuine not in family)"

    phi = [ (H.row(j) * e)[0] for j in range(8) ]                          # phi_j
    c = (diff.T * e)[0]
    if all(p == 0 for p in phi):
        print("phi is trivial -> constraint vacuous"); return
    # sanity: genuine q^0 satisfies phi.q0 = c  (q0 solves H^T q = diff)
    q0 = H.T.solve_least_squares(diff) if False else None
    print("phi (coeffs of q_0..q_7):")
    for j in range(8):
        print("  phi_%d = %s" % (j, phi[j]))
    print("c = %s" % c, flush=True)

    out = {"phi": [[int(p.p), int(p.q)] for p in phi],   # [num, den]
           "c": [int(c.p), int(c.q)], "A16": A16, "den": DEN,
           "bd_orbits": nbd, "rank_homo_BD": int(rank_H), "rank_F_BD": int(rank_F),
           "note": "constraint sum_j phi_j q_j = c on n56_biweight mixture params q_0..q_7"}
    with open(os.path.join(HERE, "triweight_q_constraint.json"), "w") as fh:
        json.dump(out, fh, indent=1)
    print("\nsaved triweight_q_constraint.json ; triweight cuts B_D %d -> %d"
          % (rank_H, rank_F), flush=True)


if __name__ == "__main__":
    main()
