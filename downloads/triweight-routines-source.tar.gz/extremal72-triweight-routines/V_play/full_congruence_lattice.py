#!/usr/bin/env python3
"""Compute the full prime-power congruence lattice for the genus-3 freedoms.

For every triweight orbit mu, the exact family is

    v_mu = (N0_mu + sum_i a_i F_i,mu) / 64.

Ordinary integrality and polarized Jacobi 5-design integrality require

    N0_mu + sum_i a_i F_i,mu == 0  (mod 64*d_mu),

where d_mu is saved by jacobi_design.py.  Earlier scripts checked consistency
mod the relevant primes and saved the squarefree odd residue.  This script keeps
the full prime-power information, including the 2-adic and 3^3 parts.

Output format:

    for each prime p:
      a = offset + basis_columns*z, z in Z^5, modulo p^E.

This per-prime affine lattice is the exact congruence data needed for later
SDP/lattice intersection tests.
"""
import gzip
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.set_int_max_str_digits(10_000_000)


def vp(n, p):
    e = 0
    while n and n % p == 0:
        n //= p
        e += 1
    return e


def factor_int(n):
    n = abs(int(n))
    out = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
        p += 1 if p == 2 else 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def egcd(a, b):
    old_r, r = abs(a), abs(b)
    old_s, s = 1, 0
    old_t, t = 0, 1
    while r:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_s, s = s, old_s - q * s
        old_t, t = t, old_t - q * t
    return old_r, old_s if a >= 0 else -old_s, old_t if b >= 0 else -old_t


def mat_mul(A, B):
    nr, mid, nc = len(A), len(B), len(B[0])
    return [[sum(A[i][k] * B[k][j] for k in range(mid)) for j in range(nc)]
            for i in range(nr)]


def mat_vec(A, v):
    return [sum(A[i][j] * v[j] for j in range(len(v))) for i in range(len(A))]


def row_times_mat(row, A):
    return [sum(row[i] * A[i][j] for i in range(len(row))) for j in range(len(A[0]))]


def row_reduction_transform(c):
    """Return U with c*U = [g,0,...,0], g=gcd(c_i)."""
    r = len(c)
    U = [[1 if i == j else 0 for j in range(r)] for i in range(r)]
    row = [int(x) for x in c]
    for i in range(1, r):
        a, b = row[0], row[i]
        if b == 0:
            continue
        if a == 0:
            for rr in range(r):
                U[rr][0], U[rr][i] = U[rr][i], U[rr][0]
            row[0], row[i] = row[i], row[0]
            continue
        g, x, y = egcd(a, b)
        T00, T01 = x, -b // g
        T10, T11 = y, a // g
        for rr in range(r):
            u0, ui = U[rr][0], U[rr][i]
            U[rr][0] = u0 * T00 + ui * T10
            U[rr][i] = u0 * T01 + ui * T11
        row[0], row[i] = g, 0
    if row[0] < 0:
        for rr in range(r):
            U[rr][0] = -U[rr][0]
        row[0] = -row[0]
    return row[0], U


def impose_congruence(x0, L, coeff, rhs, mod, cap_mod=None):
    """Update x = x0 + L*z by coeff*x == rhs (mod mod)."""
    coeff = [v % mod for v in coeff]
    c = [v % mod for v in row_times_mat(coeff, L)]
    d = (rhs - sum(coeff[i] * x0[i] for i in range(len(x0)))) % mod
    if all(v == 0 for v in c):
        if d % mod:
            raise ValueError("inconsistent zero congruence")
        return x0, L, False

    g, U = row_reduction_transform(c)
    h = math.gcd(g, mod)
    if d % h:
        raise ValueError("inconsistent congruence: gcd does not divide rhs")
    m1 = mod // h
    if m1 == 1:
        y1 = 0
    else:
        y1 = ((d // h) * pow((g // h) % m1, -1, m1)) % m1

    y0 = [0] * len(c)
    y0[0] = y1
    z0 = mat_vec(U, y0)
    x1 = [x0[i] + sum(L[i][j] * z0[j] for j in range(len(z0)))
          for i in range(len(x0))]

    D = [[0] * len(c) for _ in range(len(c))]
    for i in range(len(c)):
        D[i][i] = m1 if i == 0 else 1
    L1 = mat_mul(L, mat_mul(U, D))
    if cap_mod is not None:
        x1 = [v % cap_mod for v in x1]
        L1 = [[v % cap_mod for v in row] for row in L1]
    return x1, L1, m1 != 1


def load_data():
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]
    den = int(V["den"])
    g = int(V["genuine_row"])
    free_idx = [k for k in range(len(N)) if k != g]
    N0 = [int(x) for x in N[g]]
    F = [[int(x) for x in N[k]] for k in free_idx]
    with gzip.open(os.path.join(HERE, "jacobi_divisors.json.gz"), "rt") as fh:
        divisors = [int(x) for x in json.load(fh)["divisors"]]
    return den, N0, F, divisors


def crt_pair(r1, m1, r2, m2):
    g = math.gcd(m1, m2)
    if (r2 - r1) % g:
        raise ValueError("CRT inconsistent")
    lcm = m1 // g * m2
    if m2 // g == 1:
        return r1 % lcm, lcm
    inv = pow((m1 // g) % (m2 // g), -1, m2 // g)
    t = ((r2 - r1) // g * inv) % (m2 // g)
    return (r1 + m1 * t) % lcm, lcm


def solve_primary(p, E, den, N0, F, divisors):
    q = p ** E
    n = len(F)
    x0 = [0] * n
    L = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    rows = []
    rows_by_precision = {}
    for j, dj in enumerate(divisors):
        e = vp(den * dj, p)
        if e:
            rows.append((e, j))
            rows_by_precision[e] = rows_by_precision.get(e, 0) + 1
    rows.sort(reverse=True)

    changed = 0
    for e, j in rows:
        pe = p ** e
        coeff = [F[i][j] for i in range(n)]
        x0, L, did = impose_congruence(x0, L, coeff, -N0[j], pe, cap_mod=q)
        changed += int(did)

    bad_offset = 0
    bad_basis = 0
    for e, j in rows:
        pe = p ** e
        coeff = [F[i][j] for i in range(n)]
        val = N0[j] + sum(coeff[i] * x0[i] for i in range(n))
        if val % pe:
            bad_offset += 1
        for col in range(n):
            step = sum(coeff[i] * L[i][col] for i in range(n))
            if step % pe:
                bad_basis += 1
                break
    if bad_offset or bad_basis:
        raise AssertionError("p=%d validation failed: offset=%d basis=%d"
                             % (p, bad_offset, bad_basis))

    return {
        "p": p,
        "E": E,
        "modulus": q,
        "constraint_rows": len(rows),
        "rows_by_precision": {str(k): v for k, v in sorted(rows_by_precision.items())},
        "effective_updates": changed,
        "offset": [int(x % q) for x in x0],
        "basis_columns": [[int(L[i][j] % q) for i in range(n)] for j in range(n)],
    }


def main():
    den, N0, F, divisors = load_data()
    prime_exp = {}
    for d in divisors:
        for p, e in factor_int(den * d).items():
            prime_exp[p] = max(prime_exp.get(p, 0), e)

    print("full congruence system: %d orbits, %d freedoms" % (len(N0), len(F)), flush=True)
    print("prime powers:", " ".join("%s^%s" % (p, e) for p, e in sorted(prime_exp.items())), flush=True)

    solutions = []
    for p, E in sorted(prime_exp.items()):
        sol = solve_primary(p, E, den, N0, F, divisors)
        solutions.append(sol)
        print("\np=%d, E=%d, modulus=%d" % (p, E, sol["modulus"]), flush=True)
        print("  rows by precision:", sol["rows_by_precision"], flush=True)
        print("  effective updates:", sol["effective_updates"], flush=True)
        print("  offset:", sol["offset"], flush=True)
        print("  basis columns:", flush=True)
        for col in sol["basis_columns"]:
            print("   ", col, flush=True)

    odd_mod = 1
    odd_offset = [0] * len(F)
    for sol in solutions:
        if sol["p"] == 2:
            continue
        for i, res in enumerate(sol["offset"]):
            odd_offset[i], new_mod = crt_pair(odd_offset[i], odd_mod, res, sol["modulus"])
        odd_mod = new_mod

    print("\ncombined odd residue:", flush=True)
    print("  modulus:", odd_mod, flush=True)
    print("  offset :", odd_offset, flush=True)

    out = {
        "note": "Full prime-power affine congruence lattice for genus-3 freedoms.",
        "interpretation": "For each prime p: a = offset + basis_columns*z modulo p^E.",
        "den": den,
        "num_freedoms": len(F),
        "num_orbits": len(N0),
        "combined_odd_modulus": odd_mod,
        "combined_odd_offset": odd_offset,
        "prime_power_solutions": solutions,
    }
    out_path = os.path.join(HERE, "full_congruence_lattice.json.gz")
    with gzip.open(out_path, "wt") as fh:
        json.dump(out, fh)
    print("\nsaved -> %s" % out_path, flush=True)


if __name__ == "__main__":
    main()
