#!/usr/bin/env python3
"""Save the full forced biweight B, and compute the Assmus-Mattson 5-design
divisibility constraints from the polarized genus-3 Jacobi integrality.

J_t = A_(3)^t W / (72)_t has coefficients (t!/prod tau_a!) prod_a (mu_a)_{tau_a}
v_mu / (72)_t.  Positivity is vacuous (each is a positive multiple of one v_mu),
but INTEGRALITY (the 5-design property) forces, for every orbit mu and every
tau<=mu, |tau|=t<=5:

    (72)_t  |  (t!/prod tau_a!) prod_a (mu_a)_{tau_a} * v_mu

i.e. v_mu = 0 (mod d_mu),  d_mu = lcm over (t,tau) of (72)_t / gcd((72)_t, factor).

The orbit's exponent multiset is AGL-invariant, so d_mu is well defined per orbit
(use the representative).  We report the distribution; the feasibility solve over
the 5-dim family follows in jacobi_feasible.py.
"""
import gzip
import json
import os
import sys
from math import factorial, gcd

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
sys.path.insert(0, SP)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                              # noqa: E402
from reconstruct_charzero import build_structure              # noqa: E402
from reconstruct_integer import (NC, build_col_marginal_counts,   # noqa: E402
                                 marginal_of_orbit_vector_int, target_wuvt_data)

N_LEN = 72
TMAX = 5


def falling(n, k):
    r = 1
    for i in range(k):
        r *= (n - i)
    return r


def poch(N, t):
    r = 1
    for i in range(t):
        r *= (N - i)
    return r


def compositions(t, mu):
    """8-tuples tau, sum(tau)=t, 0<=tau_a<=mu_a."""
    res = []
    def rec(pos, rem, cur):
        if pos == 8:
            if rem == 0:
                res.append(tuple(cur))
            return
        hi = min(rem, mu[pos])
        for v in range(hi + 1):
            cur.append(v); rec(pos + 1, rem - v, cur); cur.pop()
    rec(0, t, [])
    return res


def jacobi_divisor(mu):
    d = 1
    POCH = [poch(N_LEN, t) for t in range(TMAX + 1)]
    for t in range(1, TMAX + 1):
        Nt = POCH[t]
        for tau in compositions(t, mu):
            fac = factorial(t)
            for a in range(8):
                if tau[a]:
                    fac //= factorial(tau[a])
                    fac *= falling(mu[a], tau[a])
            dt = Nt // gcd(Nt, fac)
            if dt > 1:
                d = d // gcd(d, dt) * dt
    return d


def main():
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; DEN = int(V["den"]); g = int(V["genuine_row"])
    Ng = [int(x) for x in N[g]]
    ncol = len(Ng)

    t = Target.load(72, "mindist")
    col_reps = [tuple(int(x) for x in r) for r in t.col_reps]
    struct = build_structure(t)
    mono2col, inv, nW = struct[0], struct[1], struct[2]

    # --- save full forced B (from M2(N_0) = DEN*|C|*B) ---
    _, B_known, row000, inv2, missing, known, forced = target_wuvt_data(t, inv)
    col_counts = build_col_marginal_counts(ncol, inv2, mono2col)
    m2N0 = marginal_of_orbit_vector_int(Ng, col_counts, nW)
    uniqkeys = sorted({k for k in range(nW)})  # rows are 0..nW-1 already aligned with inv
    # recover (wu,wv,t) per row from target_wuvt_data ordering
    import numpy as np
    raw = t.raw
    wu = raw[:, [1, 3, 5, 7]].sum(1); wv = raw[:, [2, 3, 6, 7]].sum(1); tt = raw[:, [3, 7]].sum(1)
    key = (wu * 5329 + wv * 73 + tt).astype(np.int64)
    uniq = np.unique(key)
    Bfull = {}
    scale = DEN * NC
    for row in range(nW):
        kk = int(uniq[row])
        wuvt = (kk // 5329, (kk // 73) % 73, kk % 73)
        Bfull["%d,%d,%d" % wuvt] = int(m2N0[row]) // scale
    out = os.path.join(HERE, "full_forced_B.json.gz")
    with gzip.open(out, "wt") as fh:
        json.dump({"note": "full forced genus-2 biweight B[(wu,wv,t)] from M2(R_0)/|C|, all rows",
                   "rows": nW, "B": Bfull}, fh)
    print("saved full forced B (%d rows) -> %s" % (nW, out), flush=True)

    # --- 5-design divisibilities d_j per orbit ---
    d = [jacobi_divisor(col_reps[j]) for j in range(ncol)]
    from collections import Counter
    bits = Counter(int(x).bit_length() for x in d)
    print("\n5-design divisibilities d_mu (v_mu must be 0 mod d_mu):", flush=True)
    print("  orbits with d=1 (no constraint): %d / %d" % (sum(1 for x in d if x == 1), ncol))
    print("  d bit-length histogram: %s" % dict(sorted(bits.items())))
    print("  max d = %d (2^%.1f)" % (max(d), max(d).bit_length()))
    # how many forced fully to 0? (d > bound would force v=0, but bounds are huge; report d vs typical)
    out2 = os.path.join(HERE, "jacobi_divisors.json.gz")
    with gzip.open(out2, "wt") as fh:
        json.dump({"den": DEN, "divisors": [int(x) for x in d]}, fh)
    print("saved per-orbit divisors -> %s" % out2, flush=True)


if __name__ == "__main__":
    main()
