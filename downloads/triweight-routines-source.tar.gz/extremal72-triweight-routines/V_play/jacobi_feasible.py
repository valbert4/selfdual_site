#!/usr/bin/env python3
"""Test whether the 5-design (Jacobi-integrality) divisibilities are satisfiable
by ANY integer enumerator v = R_0 + sum_i a_i F_i in the family.

For each orbit j: v_j = (N_0[j] + sum_i a_i N_i[j]) / 64 must be 0 mod d_j.
=> N_0[j] + sum_i a_i N_i[j] ≡ 0 (mod 64*d_j)  for all 4228 orbits.

5 unknowns a_i, 4228 congruences -> wildly over-determined.  We reduce mod each
prime p dividing the moduli and solve the linear system over GF(p) (p in
{5,7,17,23,71}; the prime-power parts 2^12, 3^3 come next).  If the system is
INCONSISTENT for any prime, NO integer 5-design-consistent enumerator exists with
the forced marginal -> the extremal [72,36,16] code DOES NOT EXIST.
"""
import gzip
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def gf_rref_consistency(A, b, p):
    """rank(A), rank([A|b]) over GF(p); A: (m,n), b: (m,)."""
    M = np.concatenate([A % p, (b % p).reshape(-1, 1)], axis=1).astype(np.int64)
    nr, nc = M.shape
    r = 0
    for c in range(nc):
        nz = np.nonzero(M[r:, c])[0]
        if nz.size == 0:
            continue
        piv = r + int(nz[0])
        M[[r, piv]] = M[[piv, r]]
        inv = pow(int(M[r, c]), p - 2, p)
        M[r] = (M[r] * inv) % p
        col = M[:, c].copy(); col[r] = 0
        nzr = np.nonzero(col)[0]
        if nzr.size:
            M[nzr] = (M[nzr] - np.multiply.outer(col[nzr], M[r])) % p
        r += 1
        if r == nr:
            break
    # rank of full augmented = r (rows used). rank(A) = pivots in first nc-1 cols.
    # recompute pivot columns:
    rankA = 0
    rr = 0
    Mr = M[:r]
    for c in range(nc - 1):
        # is there a pivot row whose leading col is c?
        pass
    # simpler: rank([A|b]) = r ; rank(A) via separate rref on A
    return r


def gf_rank(A, p):
    M = (A % p).astype(np.int64)
    nr, nc = M.shape
    r = 0
    for c in range(nc):
        nz = np.nonzero(M[r:, c])[0]
        if nz.size == 0:
            continue
        piv = r + int(nz[0])
        M[[r, piv]] = M[[piv, r]]
        inv = pow(int(M[r, c]), p - 2, p)
        M[r] = (M[r] * inv) % p
        col = M[:, c].copy(); col[r] = 0
        nzr = np.nonzero(col)[0]
        if nzr.size:
            M[nzr] = (M[nzr] - np.multiply.outer(col[nzr], M[r])) % p
        r += 1
        if r == nr:
            break
    return r


def main():
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; g = int(V["genuine_row"]); rank = len(N)
    free_idx = [k for k in range(rank) if k != g]
    Ng = np.array([int(x) for x in N[g]], dtype=object)
    Nf = [np.array([int(x) for x in N[k]], dtype=object) for k in free_idx]
    ncol = len(Ng)
    free_dim = len(Nf)
    with gzip.open(os.path.join(HERE, "jacobi_divisors.json.gz"), "rt") as fh:
        d = json.load(fh)["divisors"]
    print("family: %d orbits, %d freedoms ; testing 5-design congruences" % (ncol, free_dim), flush=True)

    # v_j = (Ng[j] + sum a_i Nf[i][j])/64 ; need v_j ≡ 0 mod d_j  AND v_j integer.
    # mod prime p (p odd, p | d_j): since 64 is a unit mod p, v_j ≡ 0 mod p
    #   <=> Ng[j] + sum a_i Nf[i][j] ≡ 0 (mod p).   (the /64 is invertible mod odd p)
    verdict = "CONSISTENT (so far)"
    # p=2: integrality requires v_j integer for ALL orbits -> N_0+sum a_i N_i ≡ 0 mod 2 (base of mod 64).
    # odd p: /64 is a unit, so only the design rows (p | d_j) constrain, as v_j ≡ 0 mod p.
    for p in (2, 3, 5, 7, 17, 23, 71):
        if p == 2:
            rows = list(range(ncol))                      # integrality (all orbits)
            tag = "integrality"
        else:
            rows = [j for j in range(ncol) if d[j] % p == 0]
            tag = "design"
        if not rows:
            print("p=%-3d : no constraint rows (skip)" % p); continue
        A = np.array([[int(Nf[i][j]) % p for i in range(free_dim)] for j in rows], dtype=np.int64)
        b = np.array([(-int(Ng[j])) % p for j in rows], dtype=np.int64)
        rA = gf_rank(A, p)
        rAb = gf_rank(np.concatenate([A, b.reshape(-1, 1)], axis=1), p)
        ok = (rA == rAb)
        print("p=%-3d : %5d %-11s rows ; rank(A)=%d rank(A|b)=%d -> %s"
              % (p, len(rows), tag, rA, rAb, "consistent" if ok else "INCONSISTENT"), flush=True)
        if not ok:
            verdict = "NONEXISTENCE"
            print("\n>>> 5-design congruences INCONSISTENT mod %d" % p)
            print(">>> NO integer enumerator satisfies the genus-3 Jacobi 5-design integrality.")
            print(">>> The extremal Type II [72,36,16] code DOES NOT EXIST.")
            break

    print("\nverdict (field primes): %s" % verdict, flush=True)
    with open(os.path.join(HERE, "jacobi_verdict.json"), "w") as fh:
        json.dump({"verdict": verdict, "tested_primes": [5, 7, 17, 23, 71]}, fh)


if __name__ == "__main__":
    main()
