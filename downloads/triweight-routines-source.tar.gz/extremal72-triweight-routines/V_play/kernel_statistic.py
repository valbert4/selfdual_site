#!/usr/bin/env python3
"""Section 28.4 steps 1-2: compute the B_D-invisible direction ker(F -> B_D) and
read off the combinatorial type of the triweight orbits it is supported on, so we
can name the statistic S and decide which bound applies.

ker(F -> B_D) = nullspace of the 64x5 matrix [F_1|BD ... F_5|BD]  (1-dimensional).
Let a* be that kernel vector; the invisible direction is K = sum_i a*_i F_i in the
4228-orbit space.  Its support orbits (K_orbit != 0) are exactly the triweight
coordinates that detect this direction.  For each we report the joint (u,v,w) type:
weights, pairwise intersections, triple intersection, and union-support size.
"""
import gzip
import json
import os
import sys
from collections import Counter

import numpy as np
import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
AJ = os.path.join(os.path.dirname(os.path.dirname(HERE)), "anchored_jacobi")
sys.path.insert(0, SP); sys.path.insert(0, AJ)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                              # noqa: E402
from reconstruct_charzero import build_structure              # noqa: E402
import build_genus2_system as g2                              # noqa: E402


def main():
    valid, orbits, orbit_of = g2.build_support_and_orbits()
    norb = len(orbits)

    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; g = int(V["genuine_row"])
    free_idx = [k for k in range(len(N)) if k != g]
    Nf = [N[k] for k in free_idx]

    t = Target.load(72, "mindist")
    mono2col = build_structure(t)[0]
    col_reps = [tuple(int(x) for x in r) for r in t.col_reps]
    raw = t.raw
    POW = [73 ** p for p in range(8)]
    keys = (raw.astype(object) * np.array(POW, dtype=object)).sum(1)
    key2orb = {int(keys[i]): int(mono2col[i]) for i in range(raw.shape[0])}

    # F|BD : 64 x 5
    FBD = []
    for o in range(norb):
        b, r = orbits[o][0]
        if max(b) != 16:
            continue
        mono = (r[0], r[1], r[2], r[3], b[0], b[1], b[2], b[3])
        idx = key2orb.get(sum(int(mono[p]) * POW[p] for p in range(8)))
        FBD.append([int(Nf[i][idx]) if idx is not None else 0 for i in range(len(Nf))])
    FBD = sp.Matrix(FBD)
    print("F|BD shape %s, rank %d" % (FBD.shape, FBD.rank()), flush=True)

    ker = FBD.nullspace()
    assert len(ker) == 1, "expected 1-dim kernel, got %d" % len(ker)
    a = ker[0]
    den = sp.lcm([x.q for x in a]); a = [int(x * den) for x in a]
    gg = 0
    for x in a:
        gg = sp.igcd(gg, x)
    a = [x // gg for x in a]
    print("kernel coeffs a* (primitive integer, B_D-invisible combo):", a, flush=True)

    # K = sum a*_i F_i  in 4228 orbit space (exact integer)
    ncol = len(Nf[0])
    K = [sum(a[i] * int(Nf[i][j]) for i in range(len(Nf))) for j in range(ncol)]
    supp = [j for j in range(ncol) if K[j] != 0]
    print("support of K: %d / %d orbits" % (len(supp), ncol), flush=True)

    # type of each support orbit:  p = u + 2v + 4w
    def typ(mu):
        wu = mu[1] + mu[3] + mu[5] + mu[7]
        wv = mu[2] + mu[3] + mu[6] + mu[7]
        ww = mu[4] + mu[5] + mu[6] + mu[7]
        uv = mu[3] + mu[7]; uw = mu[5] + mu[7]; vw = mu[6] + mu[7]; uvw = mu[7]
        union = 72 - mu[0]
        return (wu, wv, ww, uv, uw, vw, uvw, union)

    wts = Counter(); inter3 = Counter(); unions = Counter(); pair_pat = Counter()
    for j in supp:
        wu, wv, ww, uv, uw, vw, uvw, union = typ(col_reps[j])
        wts[tuple(sorted((wu, wv, ww)))] += 1
        inter3[uvw] += 1
        unions[union] += 1
        pair_pat[tuple(sorted((uv, uw, vw)))] += 1
    print("\nweight triples {wt(u),wt(v),wt(w)} on supp(K) (sorted):")
    for k, c in sorted(wts.items()):
        print("   %s : %d orbits" % (list(k), c))
    print("triple-intersection |u^v^w| distribution:", dict(sorted(inter3.items())))
    print("union-support |supp(u)Usupp(v)Usupp(w)| distribution:", dict(sorted(unions.items())))
    print("pairwise-intersection {|uv|,|uw|,|vw|} (top 12):")
    for k, c in sorted(pair_pat.items(), key=lambda kv: -kv[1])[:12]:
        print("   %s : %d" % (list(k), c))

    json.dump({"a_star": a, "supp_size": len(supp),
               "weight_triples": {str(list(k)): c for k, c in wts.items()},
               "triple_intersection": {str(k): c for k, c in inter3.items()},
               "union_support": {str(k): c for k, c in unions.items()}},
              open(os.path.join(HERE, "kernel_statistic.json"), "w"), indent=1)
    print("\nsaved kernel_statistic.json", flush=True)


if __name__ == "__main__":
    main()
