#!/usr/bin/env python3
"""Pin ONE feasible genus-3 triweight point in
   positivity  INTERSECT  the §28.2 per-orbit box  INTERSECT  the task's tight
   per-axis intervals (esp. the a_1 lower bound 1.095e10 coming from the §28.1
   menu/abar coupling), snapped to the full congruence period lattice.

Run:  HOME=/tmp DOT_SAGE=/tmp/sage /usr/bin/sage -python pin_in_taskbox.py

Everything is exact (ppl + Fraction + sage ZZ/QQ).
"""
import gzip
import json
import os
import sys
from fractions import Fraction

import ppl
from sage.all import ZZ, QQ, matrix, vector
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
sys.path.insert(0, SP)
sys.set_int_max_str_digits(10_000_000)

DEN = 64
A16 = 249849
A1_PER_ABAR = 1269732618

# task-stated tight per-axis intervals (the feasible region this session)
TASK_BOX = {
    0: (10950000000, 51366455910),     # a1: lower from §28.1 menu/abar coupling
    1: (22778233632, 123741215136),    # a2
    2: (7929287815680, 9520070402304), # a3
    3: (3099879041490, 3368354718960), # a4
    4: (2429267835456, 2661821288280), # a5
}

OUT = os.path.join(HERE, "pinned_triweight.json")


# ---------- congruence period lattice (same construction as pin_triweight_point) ----------
def egcd(a, b):
    old_r, r = abs(a), abs(b)
    old_s, s = 1, 0
    old_t, t = 0, 1
    while r:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_s, s = s, old_s - q * s
        old_t, t = t, old_t - q * t
    return old_r, old_s if a >= 0 else -old_s, old_t if b >= 0 else -old_t


def crt_pair(r1, m1, r2, m2):
    g, s, _ = egcd(m1, m2)
    if (r2 - r1) % g:
        raise ValueError("CRT inconsistent")
    lcm = m1 // g * m2
    if m2 // g == 1:
        return r1 % lcm, lcm
    t = ((r2 - r1) // g * s) % (m2 // g)
    return (r1 + m1 * t) % lcm, lcm


def get_particular(sol):
    return [int(x) for x in sol.get("particular", sol.get("offset"))]


def get_kernel_gens(sol):
    return [[int(x) for x in row]
            for row in sol.get("kernel_gens", sol.get("basis_columns", []))]


def combine_odd_solution(lattice):
    n = int(lattice["num_freedoms"])
    odd_mod = 1
    odd_offset = [0] * n
    for sol in lattice["prime_power_solutions"]:
        if int(sol["p"]) == 2:
            continue
        mod = int(sol["modulus"])
        off = get_particular(sol)
        for i in range(n):
            odd_offset[i], new_mod = crt_pair(odd_offset[i], odd_mod, off[i], mod)
        odd_mod = new_mod
    return odd_mod, odd_offset


def congruence_period_lattice(lattice):
    n = int(lattice["num_freedoms"])
    odd_mod, odd_offset = combine_odd_solution(lattice)
    two = next(sol for sol in lattice["prime_power_solutions"]
               if int(sol["p"]) == 2)
    two_mod = int(two["modulus"])
    two_particular = get_particular(two)
    two_kernel = get_kernel_gens(two)

    full_mod = odd_mod * two_mod
    full_origin = []
    for i in range(n):
        x, mod = crt_pair(odd_offset[i], odd_mod, two_particular[i], two_mod)
        assert mod == full_mod
        full_origin.append(int(x))

    lifted = []
    for row in two_kernel:
        lifted.append([crt_pair(0, odd_mod, row[i], two_mod)[0] for i in range(n)])
    for i in range(n):
        v = [0] * n
        v[i] = full_mod
        lifted.append(v)

    H = matrix(ZZ, lifted).hermite_form(include_zero_rows=False)
    basis = [[int(H[i, j]) for j in range(H.ncols())] for i in range(H.nrows())]
    det = abs(int(H.det()))
    return {
        "odd_modulus": int(odd_mod),
        "two_primary_modulus": int(two_mod),
        "full_modulus": int(full_mod),
        "full_origin": full_origin,
        "period_basis_rows": basis,
        "period_covolume": int(det),
    }


# ---------- ppl helpers ----------
def linexpr(coeffs, const=0):
    e = ppl.Linear_Expression(int(const))
    for i, c in enumerate(coeffs):
        if c:
            e += int(c) * ppl.Variable(i)
    return e


def exact_positivity(N0, F, a):
    nf = len(F)
    worst = None
    for j in range(len(N0)):
        val = int(N0[j]) + sum(int(F[i][j]) * int(a[i]) for i in range(nf))
        if val < 0:
            return False, val
        if worst is None or val < worst:
            worst = val
    return True, worst


def box_ok(a):
    for i, (lo, hi) in TASK_BOX.items():
        if not (lo <= a[i] <= hi):
            return False, i
    return True, None


def chebyshev_center(N0, F):
    """Maximize t s.t.
        N0_j + sum a_i F_i,j >= t*||F_.,j||_1            (positivity, scaled)
        a_i - lo_i          >= t                          (task box lower)
        hi_i - a_i          >= t                          (task box upper)
    Returns rational center (interior of positivity INTERSECT task box)."""
    nf = len(F)
    ncol = len(N0)
    cs = ppl.Constraint_System()
    t = ppl.Variable(nf)
    for j in range(ncol):
        coeffs = [int(F[i][j]) for i in range(nf)]
        norm1 = sum(abs(c) for c in coeffs)
        e = linexpr(coeffs, int(N0[j]))
        if norm1:
            e -= int(norm1) * t
        cs.insert(e >= 0)
    for i in range(nf):
        lo, hi = TASK_BOX[i]
        cs.insert(ppl.Variable(i) - int(lo) - t >= 0)
        cs.insert(int(hi) - ppl.Variable(i) - t >= 0)
    cs.insert(t >= 0)
    print("    built %d constraints; constructing polyhedron ..." % len(list(cs)), flush=True)
    poly = ppl.NNC_Polyhedron(cs)
    print("    checking emptiness ...", flush=True)
    assert not poly.is_empty(), "positivity INTERSECT task box is EMPTY"
    print("    maximizing radius t ...", flush=True)
    t_expr = ppl.Linear_Expression(0) + t
    out = poly.maximize(t_expr)
    assert out["bounded"], "Chebyshev radius unbounded?!"
    best = None
    best_t = None
    for gen in poly.generators():
        if not gen.is_point():
            continue
        d = int(gen.divisor())
        coords = [Fraction(int(gen.coefficient(ppl.Variable(i))), d) for i in range(nf + 1)]
        tv = coords[nf]
        if best_t is None or tv > best_t:
            best_t = tv
            best = coords[:nf]
    assert best is not None
    return best, best_t


def main():
    lattice = json.load(gzip.open(os.path.join(HERE, "full_congruence_lattice.json.gz"), "rt"))
    V = json.load(gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt"))
    assert V.get("verified"), "exact_V not verified"
    N = V["N"]
    g = int(V["genuine_row"])
    N0 = [int(x) for x in N[g]]
    free_idx = [i for i in range(len(N)) if i != g]
    F = [[int(x) for x in N[i]] for i in free_idx]
    nf = len(F)
    print("exact V: free_dim=%d orbits=%d den=%d" % (nf, len(N0), V["den"]), flush=True)

    # numpy (python-object dtype for exact big ints) views for fast positivity
    N0_np = np.array([int(x) for x in N0], dtype=object)
    F_np = np.array([[int(x) for x in row] for row in F], dtype=object)  # nf x ncol

    def positivity_np(a):
        vals = N0_np + sum(int(a[i]) * F_np[i] for i in range(nf))
        mn = vals.min()
        return (mn >= 0), int(mn)

    period = congruence_period_lattice(lattice)
    origin = [int(x) for x in period["full_origin"]]
    basis = [[int(x) for x in row] for row in period["period_basis_rows"]]
    print("congruence: odd_mod=%d two_mod=%d full_mod=%d" % (
        period["odd_modulus"], period["two_primary_modulus"], period["full_modulus"]), flush=True)

    # interior target: per-axis midpoint of the polytope's exact bounding box
    # (positivity INTERSECT §28.2 box) further INTERSECTED with the task box.
    # The bounding-box ranges are precomputed exactly in polytope_lattice_geometry.json
    # (raw_coordinate_widths); we tighten with the task box and take midpoints.
    geo = json.load(open(os.path.join(HERE, "polytope_lattice_geometry.json")))
    geo_rng = {}
    for w in geo["raw_coordinate_widths"]:
        i = int(w["index"])
        lo = Fraction(int(w["min"]["num"]), int(w["min"]["den"]))
        hi = Fraction(int(w["max"]["num"]), int(w["max"]["den"]))
        geo_rng[i] = (lo, hi)
    center = []
    for i in range(nf):
        glo, ghi = geo_rng[i]
        tlo, thi = TASK_BOX[i]
        lo = max(glo, Fraction(tlo))
        hi = min(ghi, Fraction(thi))
        assert lo <= hi, "task box empty against geometry on axis %d" % i
        center.append((lo + hi) / 2)
    radius = Fraction(0)  # not a Chebyshev radius; midpoint target
    print("\ntarget = midpoint of (geometry bounding box INTERSECT task box):", flush=True)
    print("  center a* =", [float(x) for x in center], flush=True)

    # snap to congruence lattice
    Bm = matrix(QQ, basis)
    cvec = vector(QQ, [QQ(int(x.numerator)) / QQ(int(x.denominator)) for x in center])
    ovec = vector(QQ, [QQ(v) for v in origin])
    zreal = (cvec - ovec) * Bm.inverse()
    z0 = [int(round(float(zreal[k]))) for k in range(nf)]
    print("  real z* =", [float(zreal[k]) for k in range(nf)], flush=True)
    print("  nearest z0 =", z0, flush=True)

    def a_of(z):
        return [origin[i] + sum(int(z[k]) * basis[k][i] for k in range(nf))
                for i in range(nf)]

    import itertools
    a_pin = None
    a_pin_z = None
    best_margin = None
    # smarter, fast search: small full-product radius (numpy positivity, vectorized)
    for radius_search in range(0, 4):
        rng = range(-radius_search, radius_search + 1)
        found = False
        ntested = 0
        for delta in itertools.product(rng, repeat=nf):
            if radius_search > 0 and max(abs(d) for d in delta) != radius_search:
                continue
            z = [z0[k] + delta[k] for k in range(nf)]
            avec = a_of(z)
            okb, _ = box_ok(avec)
            if not okb:
                continue
            ntested += 1
            okp, margin = positivity_np(avec)
            if okp:
                if best_margin is None or margin > best_margin:
                    best_margin = margin
                    a_pin = avec
                    a_pin_z = z
                found = True
        print("  shell r=%d: box-feasible candidates tested=%d ; found=%s ; best_margin=%s"
              % (radius_search, ntested, found, best_margin), flush=True)
        if found:
            break
    assert a_pin is not None, "no feasible congruence-lattice point in positivity INTERSECT task box"

    print("\n=> PINNED point a =", a_pin, flush=True)
    print("   lattice z =", a_pin_z, flush=True)
    okp, worst = positivity_np(a_pin)
    okb, _ = box_ok(a_pin)
    print("   positivity ok=%s worst_numerator=%d ; task-box ok=%s" % (okp, worst, okb), flush=True)
    assert okp and okb

    abar = Fraction(a_pin[0], A1_PER_ABAR)
    print("   abar = a_1/%d = %s  (= %.6f)  ; cap 445/11=%.5f" % (
        A1_PER_ABAR, abar, float(abar), 445 / 11), flush=True)
    assert abar <= Fraction(445, 11), "abar exceeds positivity cap 445/11"

    # design-congruence verification (N0_j + sum a_i F_i,j == 0 mod 64*d_j)
    divisors = [int(x) for x in json.load(gzip.open(os.path.join(HERE, "jacobi_divisors.json.gz"), "rt"))["divisors"]]
    assert len(divisors) == len(N0)
    vals_np = N0_np + sum(int(a_pin[i]) * F_np[i] for i in range(nf))
    div_np = np.array(divisors, dtype=object)
    mods = DEN * div_np
    bad = int(np.count_nonzero([int(vals_np[j]) % int(mods[j]) != 0 for j in range(len(N0))]))
    print("   design congruence (mod 64*d_j): %s (%d violations)" % (
        "ALL PASS" if bad == 0 else "FAIL", bad), flush=True)
    assert bad == 0

    result = {
        "a": [str(x) for x in a_pin],
        "a_lattice_coords_z": [int(x) for x in a_pin_z],
        "abar_p": int(abar.numerator),
        "abar_q": int(abar.denominator),
        "abar_float": float(abar),
        "positivity_worst_numerator": int(worst),
        "positivity_ok": bool(okp),
        "taskbox_ok": bool(okb),
        "design_congruence_violations": int(bad),
        "chebyshev_radius_num": str(radius.numerator),
        "chebyshev_radius_den": str(radius.denominator),
        "congruence_full_modulus": period["full_modulus"],
        "den": DEN,
    }
    with open(os.path.join(HERE, "pin_in_taskbox_result.json"), "w") as fh:
        json.dump(result, fh, indent=1)
    print("\nsaved -> pin_in_taskbox_result.json", flush=True)
    print("RESULT_JSON_BEGIN")
    print(json.dumps(result))
    print("RESULT_JSON_END")
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
