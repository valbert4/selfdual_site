#!/usr/bin/env python3
"""PIN the genus-3 triweight to ONE admissible lattice point and emit the
FULLY-DETERMINED n=56 residual biweight.

Run with the Sage/ppl python:
    HOME=/tmp DOT_SAGE=/tmp/sage /usr/bin/sage -python pin_triweight_point.py

Steps:
 (a) Pick ONE admissible point a=(a_1..a_5):
       * positivity-feasible: N0_mu + sum a_i F_i,mu >= 0 for all 4228 orbits;
       * on the full congruence lattice (odd modulus 8744715 + 2-primary).
     We take the lattice point nearest the Chebyshev / analytic center of the
     positivity polytope (in raw a-coords) and verify EXACT positivity; if the
     nearest snap touches a face, we do a small exact local lattice search.
 (b) Compute the fully-determined n=56 residual biweight at that point:
       residual = (R0|_BD + sum a_i F_i|_BD) / 64 over the 64 B_D orbits
       (max(b)==16); also /(64*A16) -> the point in the anchored B_D family
       x_p|BD + sum_j q_j homo_j|BD, solved EXACTLY for q_0..q_7.
     Verify positivity at the point and sum_j phi_j q_j = c.
 (c) Emit point + full fixed B_D residual biweight -> pinned_triweight.json.
"""
import gzip
import json
import os
import sys
from fractions import Fraction

import ppl
from sage.all import ZZ, QQ, matrix, vector

import sympy as sp
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
AJ = os.path.join(ROOT, "anchored_jacobi")
sys.path.insert(0, SP)
sys.path.insert(0, AJ)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                              # noqa: E402
import build_genus2_system as g2                              # noqa: E402


def mono2col_of(t):
    """The mono->orbit-column map used by build_structure; built purely from
    t.orbit_items (avoids the hardcoded genus-2 cols PKL that build_structure
    eagerly loads but which we do not need for mono2col)."""
    raw = t.raw
    M = raw.shape[0]
    m2c = np.empty(M, dtype=np.int64)
    for o, (_k, mem) in enumerate(t.orbit_items):
        m2c[np.asarray(mem, dtype=np.int64)] = o
    return m2c

A16 = 249849
DEN = 64
OUT = os.path.join(HERE, "pinned_triweight.json")


# ---------------------------------------------------------------------------
# congruence period lattice (reuse polytope_lattice_geometry machinery)
# ---------------------------------------------------------------------------
def egcd(a, b):
    old_r, r = abs(a), abs(b)
    old_s, s = 1, 0
    old_t, t = 0, 1
    while r:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_s, s = s, old_s - q * s
        old_t, t = t, old_t - q * t
    return old_r, old_s if a >= 0 else -old_s, old_t if b >= 0 else -old_t


def crt_pair(r1, m1, r2, m2):
    g, s, _ = egcd(m1, m2)
    if (r2 - r1) % g:
        raise ValueError("CRT inconsistent")
    lcm = m1 // g * m2
    if m2 // g == 1:
        return r1 % lcm, lcm
    t = ((r2 - r1) // g * s) % (m2 // g)
    return (r1 + m1 * t) % lcm, lcm


def get_particular(sol):
    return [int(x) for x in sol.get("particular", sol.get("offset"))]


def get_kernel_gens(sol):
    return [[int(x) for x in row]
            for row in sol.get("kernel_gens", sol.get("basis_columns", []))]


def combine_odd_solution(lattice):
    n = int(lattice["num_freedoms"])
    odd_mod = 1
    odd_offset = [0] * n
    for sol in lattice["prime_power_solutions"]:
        if int(sol["p"]) == 2:
            continue
        mod = int(sol["modulus"])
        off = get_particular(sol)
        for i in range(n):
            odd_offset[i], new_mod = crt_pair(odd_offset[i], odd_mod, off[i], mod)
        odd_mod = new_mod
    return odd_mod, odd_offset


def congruence_period_lattice(lattice):
    n = int(lattice["num_freedoms"])
    odd_mod, odd_offset = combine_odd_solution(lattice)
    two = next(sol for sol in lattice["prime_power_solutions"]
               if int(sol["p"]) == 2)
    two_mod = int(two["modulus"])
    two_particular = get_particular(two)
    two_kernel = get_kernel_gens(two)

    full_mod = odd_mod * two_mod
    full_origin = []
    for i in range(n):
        x, mod = crt_pair(odd_offset[i], odd_mod, two_particular[i], two_mod)
        assert mod == full_mod
        full_origin.append(int(x))

    lifted = []
    for row in two_kernel:
        lifted.append([crt_pair(0, odd_mod, row[i], two_mod)[0] for i in range(n)])
    for i in range(n):
        v = [0] * n
        v[i] = full_mod
        lifted.append(v)

    H = matrix(ZZ, lifted).hermite_form(include_zero_rows=False)
    basis = [[int(H[i, j]) for j in range(H.ncols())] for i in range(H.nrows())]
    det = abs(int(H.det()))
    return {
        "odd_modulus": int(odd_mod),
        "two_primary_modulus": int(two_mod),
        "full_modulus": int(full_mod),
        "full_origin": full_origin,
        "period_basis_rows": basis,
        "period_covolume": int(det),
    }


# ---------------------------------------------------------------------------
def linexpr(coeffs, const=0):
    e = ppl.Linear_Expression(int(const))
    for i, c in enumerate(coeffs):
        if c:
            e += int(c) * ppl.Variable(i)
    return e


def exact_feasible(N0, F, a):
    nf = len(F)
    worst = None
    for j in range(len(N0)):
        val = int(N0[j]) + sum(int(F[i][j]) * int(a[i]) for i in range(nf))
        if val < 0:
            return False, val
        if worst is None or val < worst:
            worst = val
    return True, worst


def chebyshev_center_raw(N0, F):
    """Maximize t s.t. N0_j + sum a_i F_i,j >= t * ||F_.,j||  (a real interior point,
    deep in the polytope).  Returns rational a-center (list of Fraction)."""
    nf = len(F)
    ncol = len(N0)
    # ppl variables: a_0..a_{nf-1}, plus radius t = Variable(nf)
    cs = ppl.Constraint_System()
    t = ppl.Variable(nf)
    # scale by a common factor: use integer L1 norm of the column gradient as
    # the "width", which keeps everything exact and integral.
    for j in range(ncol):
        coeffs = [int(F[i][j]) for i in range(nf)]
        norm1 = sum(abs(c) for c in coeffs)
        # N0_j + sum a_i F_i,j - t*norm1 >= 0
        e = linexpr(coeffs, int(N0[j]))
        e -= int(norm1) * t
        cs.insert(e >= 0)
    cs.insert(t >= 0)
    poly = ppl.NNC_Polyhedron(cs)
    t_expr = ppl.Linear_Expression(0) + t
    out = poly.maximize(t_expr)
    assert out["bounded"], "Chebyshev radius unbounded?!"
    # generators give the optimal vertex; pull the point with max t
    best = None
    best_t = None
    for gen in poly.generators():
        if not gen.is_point():
            continue
        d = int(gen.divisor())
        coords = [Fraction(int(gen.coefficient(ppl.Variable(i))), d) for i in range(nf + 1)]
        tv = coords[nf]
        if best_t is None or tv > best_t:
            best_t = tv
            best = coords[:nf]
    assert best is not None
    return best, best_t


def main():
    lattice = json.load(gzip.open(os.path.join(HERE, "full_congruence_lattice.json.gz"), "rt"))
    V = json.load(gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt"))
    assert V.get("verified"), "exact_V not verified"
    N = V["N"]
    g = int(V["genuine_row"])
    N0 = [int(x) for x in N[g]]
    free_idx = [i for i in range(len(N)) if i != g]
    F = [[int(x) for x in N[i]] for i in free_idx]
    nf = len(F)
    print("exact V: free_dim=%d orbits=%d den=%d" % (nf, len(N0), V["den"]), flush=True)

    period = congruence_period_lattice(lattice)
    origin = [int(x) for x in period["full_origin"]]
    basis = [[int(x) for x in row] for row in period["period_basis_rows"]]
    print("congruence: odd_mod=%d two_mod=%d full_mod=%d  basis %dx%d" % (
        period["odd_modulus"], period["two_primary_modulus"], period["full_modulus"],
        len(basis), len(basis[0])), flush=True)

    Bm = matrix(QQ, basis)              # nrows = nf (basis is square nf x nf here)
    ovec = vector(QQ, [QQ(v) for v in origin])

    # Optional override: a chosen point in positivity INTERSECT the §28.2 box
    # INTERSECT the task tight per-axis box (incl. a_1 >= 1.095e10 from §28.1
    # menu/abar coupling), already snapped to the congruence lattice.  We set the
    # search seed z0 to its lattice coords so the radius-0 shell accepts it
    # exactly and the rest of the pipeline runs unchanged.
    override = os.environ.get("PIN_A_OVERRIDE")
    if override:
        a_chosen = [int(x) for x in override.split(",")]
        assert len(a_chosen) == nf, "override length mismatch"
        zvec = (vector(QQ, [QQ(x) for x in a_chosen]) - ovec) * Bm.inverse()
        z0 = [int(zvec[k]) for k in range(nf)]
        a_rebuild = [origin[i] + sum(int(z0[k]) * basis[k][i] for k in range(nf))
                     for i in range(nf)]
        assert a_rebuild == a_chosen, "override point not on congruence lattice"
        radius = Fraction(0)
        print("\nUSING TASK-BOX OVERRIDE point a =", a_chosen, flush=True)
        print("   lattice coords z0 =", z0, flush=True)
    else:
        # (a1) Chebyshev / analytic interior center of the positivity polytope
        print("\ncomputing Chebyshev center of positivity polytope ...", flush=True)
        center, radius = chebyshev_center_raw(N0, F)
        print("  Chebyshev radius t* = %s" % radius, flush=True)
        print("  center a* (decimal) =", [float(x) for x in center], flush=True)
        # (a2) snap to nearest congruence-lattice point.
        cvec = vector(QQ, [QQ(int(x.numerator)) / QQ(int(x.denominator)) for x in center])
        zreal = (cvec - ovec) * Bm.inverse()
        z0 = [int(round(float(zreal[k]))) for k in range(nf)]
        print("  real lattice coords z* =", [float(zreal[k]) for k in range(nf)], flush=True)
        print("  nearest integer z0     =", z0, flush=True)

    def a_of(z):
        return [origin[i] + sum(int(z[k]) * basis[k][i] for k in range(nf))
                for i in range(nf)]

    # small exact local search around z0 for a positivity-feasible lattice point
    import itertools
    a_pin = None
    best_margin = None
    for radius_search in range(0, 4):
        rng = range(-radius_search, radius_search + 1)
        found = False
        for delta in itertools.product(rng, repeat=nf):
            if max(abs(d) for d in delta) != radius_search and radius_search > 0:
                continue  # only the new shell
            z = [z0[k] + delta[k] for k in range(nf)]
            avec = a_of(z)
            ok, margin = exact_feasible(N0, F, avec)
            if ok:
                if best_margin is None or margin > best_margin:
                    best_margin = margin
                    a_pin = avec
                    a_pin_z = z
                found = True
        if found:
            break
    assert a_pin is not None, "no feasible lattice point found near center"
    print("\n=> PINNED lattice point a =", a_pin, flush=True)
    print("   lattice coords z =", a_pin_z, flush=True)
    ok, worst = exact_feasible(N0, F, a_pin)
    print("   EXACT positivity: all 4228 V_mu >= 0  (worst numerator = %d)  ok=%s"
          % (worst, ok), flush=True)
    assert ok and worst >= 0

    # congruence check: each prime-power residue must match
    print("\ncongruence-lattice consistency check:", flush=True)
    cong_ok = True
    for sol in lattice["prime_power_solutions"]:
        p = int(sol["p"]); E = int(sol["E"]); q = int(sol["modulus"])
        off = get_particular(sol)
        basis_cols = get_kernel_gens(sol)
        # a must equal off + basis_cols * z (mod q) for SOME integer z; check that
        # (a - off) is in the column span mod q via the saved basis.
        # Simpler: verify the actual design congruences directly below instead.
    # Direct design-congruence verification: N0_j + sum a_i F_i,j == 0 mod (64*d_j)
    divisors = [int(x) for x in json.load(gzip.open(os.path.join(HERE, "jacobi_divisors.json.gz"), "rt"))["divisors"]]
    assert len(divisors) == len(N0)
    bad = 0
    for j in range(len(N0)):
        val = N0[j] + sum(a_pin[i] * F[i][j] for i in range(nf))
        m = DEN * divisors[j]
        if val % m != 0:
            bad += 1
            if bad <= 5:
                print("  VIOLATION orbit %d: val=%d not div by %d" % (j, val, m))
    print("  design congruence N0_j + sum a_i F_i,j == 0 (mod 64*d_j): %s (%d violations)"
          % ("ALL PASS" if bad == 0 else "FAIL", bad), flush=True)
    assert bad == 0, "pinned point violates design congruence lattice"

    # ----------------------------------------------------------------------
    # (b) fully-determined n=56 residual biweight on the B_D block
    # ----------------------------------------------------------------------
    print("\nbuilding B_D block and anchored family ...", flush=True)
    valid, orbits, orbit_of = g2.build_support_and_orbits()
    norb = len(orbits)
    fam = json.load(open(os.path.join(AJ, "anchored_genus2_family.json")))
    x_p = [int(x) for x in fam["x_p"]]
    homo = [[int(x) for x in row] for row in fam["homo"]]   # 8 x norb

    t = Target.load(72, "mindist")
    mono2col = mono2col_of(t)
    raw = t.raw
    POW = [73 ** p for p in range(8)]
    keys = (raw.astype(object) * np.array(POW, dtype=object)).sum(1)
    key2orb = {int(keys[i]): int(mono2col[i]) for i in range(raw.shape[0])}

    bd = []
    R0s = {}
    Fs = {i: {} for i in range(nf)}
    bd_mono = {}
    for o in range(norb):
        b, r = orbits[o][0]
        if max(b) != 16:
            continue
        bd.append(o)
        mono = (r[0], r[1], r[2], r[3], b[0], b[1], b[2], b[3])
        bd_mono[o] = mono
        idx = key2orb.get(sum(int(mono[p]) * POW[p] for p in range(8)))
        R0s[o] = int(N[g][idx]) if idx is not None else 0
        for i in range(nf):
            Fs[i][o] = int(N[free_idx[i]][idx]) if idx is not None else 0
    nbd = len(bd)
    print("  B_D orbits: %d" % nbd, flush=True)

    # residual biweight VALUES at the pinned point (the genus-3 enumerator restricted):
    #   resid_count_o = (R0|BD_o + sum a_i F_i|BD_o) / DEN     [integer multiplicities]
    resid_num = {}
    resid_val = {}
    for o in bd:
        num = R0s[o] + sum(a_pin[i] * Fs[i][o] for i in range(nf))
        resid_num[o] = num
        assert num % DEN == 0, "residual numerator not divisible by den at orbit %d" % o
        resid_val[o] = num // DEN
        assert resid_val[o] >= 0, "negative residual biweight value at orbit %d" % o

    # the point in the anchored family is R0x = resid / A16  (per compute_q_constraint:
    # R0x_o = R0|BD_o/(DEN*A16); here generalised to R0|BD + sum a_i F_i|BD)
    R0x = sp.Matrix([sp.Rational(resid_num[o], DEN * A16) for o in bd])   # nbd x 1
    H = sp.Matrix([[homo[j][o] for o in bd] for j in range(8)])           # 8 x nbd
    xp = sp.Matrix([x_p[o] for o in bd])                                  # nbd x 1

    # solve H^T q = (R0x - xp) for q (exact least squares == exact solve since in span)
    diff = R0x - xp
    HT = H.T                                                              # nbd x 8
    aug = HT.row_join(diff)
    assert aug.rank() == HT.rank(), "pinned residual NOT in anchored family span!"
    # exact particular solution
    sol_q, params = HT.gauss_jordan_solve(diff)
    # gauss_jordan_solve returns (particular + free*params); pick params = 0
    if params.cols > 0:
        sol_q = sol_q.subs({s: 0 for s in params})
    q = [sp.nsimplify(sol_q[j]) for j in range(8)]
    print("\n  q_0..q_7 (anchored B_D mixture params) at the pinned point:", flush=True)
    for j in range(8):
        print("    q_%d = %s" % (j, q[j]), flush=True)

    # verify it reconstructs the residual point exactly: xp + H^T q == R0x
    recon = xp + HT * sp.Matrix(q)
    assert recon == R0x, "q does not reconstruct the residual point"

    # verify phi . q == c  (the rank-4 cut)
    tc = json.load(open(os.path.join(HERE, "triweight_q_constraint.json")))
    phi = [sp.Rational(p[0], p[1]) for p in tc["phi"]]
    cval = sp.Rational(tc["c"][0], tc["c"][1])
    lhs = sum(phi[j] * q[j] for j in range(8))
    print("\n  phi . q = %s ;  c = %s ;  equal=%s" % (lhs, cval, lhs == cval), flush=True)
    phi_q_ok = bool(lhs == cval)
    assert phi_q_ok, "phi.q != c at the pinned point"

    # ----------------------------------------------------------------------
    # build the residual biweight summary in the (w,t) minword-row coordinates
    # ----------------------------------------------------------------------
    minrow = json.load(open(os.path.join(ROOT, "n56_biweight", "minword_row_n56.json")))
    q_float = [float(q[j]) for j in range(8)]
    # evaluate each minword entry N_D(16,w,t) at the pinned q
    minword_eval = {}
    for key, form in minrow["entries"].items():
        val = sp.Rational(form["constant"])
        for j in range(8):
            val += sp.Rational(form["parameters"][j]) * q[j]
        minword_eval[key] = val
    # row sum sanity
    rs = sum(minword_eval.values())
    exp_rs = sp.Rational(minrow["expected_row_sum"]["constant"])
    print("\n  minword row sum at pinned q = %s ; expected = %s ; ok=%s"
          % (rs, exp_rs, rs == exp_rs), flush=True)
    # all minword entries must be nonneg integers (residual counts)
    minword_int = {}
    neg = 0
    nonint = 0
    for key, val in minword_eval.items():
        if val.q != 1:
            nonint += 1
        if val < 0:
            neg += 1
        minword_int[key] = str(val)
    print("  minword entries: %d total, %d negative, %d non-integer"
          % (len(minword_eval), neg, nonint), flush=True)

    # ----------------------------------------------------------------------
    # B_D orbit residual biweight: the 64 values + summary stats
    # ----------------------------------------------------------------------
    bd_block = []
    for o in bd:
        b, r = orbits[o][0]
        bd_block.append({
            "orbit": int(o),
            "b": [int(x) for x in b],
            "r": [int(x) for x in r],
            "residual_count": int(resid_val[o]),
        })
    bd_block.sort(key=lambda d: (-d["residual_count"], d["orbit"]))

    # key counts: q0,q1,q2 and A16/A20 of the residual code C_B from the biweight row
    # A16 of residual = N_D(16,16,0)? the (16,0) minword entry = q0 (coefficient form)
    # Use the standard markers documented in compute_q_constraint / the q-form.
    q0v = int(q[0]) if q[0].q == 1 else float(q[0])
    q1v = int(q[1]) if q[1].q == 1 else float(q[1])
    q2v = int(q[2]) if q[2].q == 1 else float(q[2])

    out = {
        "note": "PINNED genus-3 triweight: ONE admissible lattice point + fully-determined n=56 residual biweight.",
        "den": DEN,
        "A16_residual": A16,
        "a_point": [str(x) for x in a_pin],
        "a_point_lattice_coords_z": [int(x) for x in a_pin_z],
        "chebyshev_radius": [str(radius.numerator), str(radius.denominator)],
        "positivity": {
            "all_V_mu_nonneg": True,
            "worst_numerator": int(worst),
            "num_orbits": len(N0),
        },
        "congruence": {
            "odd_modulus": period["odd_modulus"],
            "two_primary_modulus": period["two_primary_modulus"],
            "full_modulus": period["full_modulus"],
            "design_congruence_all_pass": True,
            "num_violations": 0,
        },
        "q_vector": [str(q[j]) for j in range(8)],
        "phi_q_check": {
            "phi": tc["phi"],
            "c": tc["c"],
            "lhs": [str(lhs.p), str(lhs.q)],
            "equal": phi_q_ok,
            "rank_homo_BD": tc["rank_homo_BD"],
            "rank_F_BD": tc["rank_F_BD"],
        },
        "residual_biweight": {
            "n": 56,
            "k": 21,
            "bd_orbits": nbd,
            "den": DEN,
            "q0_A16marker": str(q[0]),
            "q1": str(q[1]),
            "q2": str(q[2]),
            "bd_orbit_values": bd_block,
            "minword_row_Nt": minword_int,
            "minword_row_sum": str(rs),
            "minword_row_sum_expected": str(exp_rs),
            "minword_all_nonneg_integer": bool(neg == 0 and nonint == 0),
        },
        "is_single_point_not_family": True,
    }
    with open(OUT, "w") as fh:
        json.dump(out, fh, indent=1)
    print("\nsaved -> %s" % OUT, flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
