#!/usr/bin/env python3
"""Section 28.2: widths of the genus-3 freedom polytope.

The exact genus-3 family is

    v_mu = (N0_mu + sum_i a_i F_i,mu) / 64.

This script computes exact PPL widths of the positivity polytope

    N0_mu + sum_i a_i F_i,mu >= 0        for all 4228 orbits mu

in two coordinate systems:

* the raw freedom coordinates a_i;
* integer coordinates for the full design-congruence period lattice.

The second coordinate system combines the odd residue pinning with the
2-primary module in full_congruence_lattice.json.gz.  If the resulting integer
box is small enough, the script enumerates all congruence-lattice points that
survive positivity.

Run with the Sage/conda Python that provides ``ppl`` and ``sage.all``:

    HOME=/tmp /home/vva/miniforge3/bin/python polytope_lattice_geometry.py
"""
import argparse
import gzip
import itertools
import json
import math
import os
import sys
from decimal import Decimal, getcontext
from fractions import Fraction

try:
    import ppl
except ImportError as exc:  # pragma: no cover - exercised only on wrong runner.
    raise SystemExit(
        "This script needs the PPL Python bindings.  In this workspace use:\n"
        "  HOME=/tmp /home/vva/miniforge3/bin/python "
        "triweight/V_play/polytope_lattice_geometry.py"
    ) from exc

try:
    from sage.all import ZZ, matrix
except ImportError as exc:  # pragma: no cover - exercised only on wrong runner.
    raise SystemExit(
        "This script needs Sage's integer matrix Hermite form.  In this "
        "workspace use:\n"
        "  HOME=/tmp /home/vva/miniforge3/bin/python "
        "triweight/V_play/polytope_lattice_geometry.py"
    ) from exc


HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "polytope_lattice_geometry.json")
sys.set_int_max_str_digits(10_000_000)
getcontext().prec = 32


def load_json_gz(path):
    with gzip.open(path, "rt") as fh:
        return json.load(fh)


def linear_expression(coeffs, const=0):
    e = ppl.Linear_Expression(int(const))
    for i, c in enumerate(coeffs):
        if c:
            e += int(c) * ppl.Variable(i)
    return e


def optimize(poly, coeffs, sense):
    expr = linear_expression(coeffs)
    if sense == "max":
        out = poly.maximize(expr)
        if not out["bounded"]:
            return None
        return Fraction(int(out["sup_n"]), int(out["sup_d"]))
    if sense == "min":
        out = poly.minimize(expr)
        if not out["bounded"]:
            return None
        return Fraction(int(out["inf_n"]), int(out["inf_d"]))
    raise ValueError("unknown optimization sense %r" % (sense,))


def frac_json(x):
    if x is None:
        return None
    return {
        "num": str(x.numerator),
        "den": str(x.denominator),
        "decimal": str(Decimal(x.numerator) / Decimal(x.denominator)),
    }


def ceil_div(a, b):
    return -((-a) // b)


def floor_fraction(x):
    return x.numerator // x.denominator


def ceil_fraction(x):
    return ceil_div(x.numerator, x.denominator)


def congruent_integer_summary(lo, hi, residue, modulus, sample_limit=20):
    """Integers in [lo, hi] that equal residue modulo modulus."""
    lo_i = ceil_fraction(lo)
    hi_i = floor_fraction(hi)
    if lo_i > hi_i:
        return {
            "integer_lower": str(lo_i),
            "integer_upper": str(hi_i),
            "count": 0,
            "first": None,
            "last": None,
            "values": [],
        }
    k0 = ceil_div(lo_i - residue, modulus)
    first = residue + modulus * k0
    if first > hi_i:
        count = 0
        last = None
    else:
        count = (hi_i - first) // modulus + 1
        last = first + modulus * (count - 1)
    values = []
    if count and count <= sample_limit:
        values = [str(first + modulus * k) for k in range(count)]
    return {
        "integer_lower": str(lo_i),
        "integer_upper": str(hi_i),
        "count": int(count),
        "first": (None if first > hi_i else str(first)),
        "last": (None if last is None else str(last)),
        "values": values,
    }


def interval_summary(lo, hi, compare_modulus=None, residue=None):
    if lo is None or hi is None:
        return {
            "bounded": False,
            "min": frac_json(lo),
            "max": frac_json(hi),
            "width": None,
        }
    width = hi - lo
    out = {
        "bounded": True,
        "min": frac_json(lo),
        "max": frac_json(hi),
        "width": frac_json(width),
    }
    if compare_modulus is not None:
        out["width_less_than_modulus"] = bool(width < compare_modulus)
    if compare_modulus is not None and residue is not None:
        out["integers_in_interval_with_residue"] = congruent_integer_summary(
            lo, hi, residue, compare_modulus
        )
    return out


def build_polyhedron(N0, F, origin=None, basis_rows=None):
    """Build positivity polyhedron.

    If basis_rows is None, variables are the raw a_i.  Otherwise variables y_k
    mean a = origin + sum_k y_k * basis_rows[k].
    """
    nfree = len(F)
    if basis_rows is None:
        dim = nfree
        origin = [0] * nfree
        basis_rows = [[1 if i == k else 0 for i in range(nfree)]
                      for k in range(nfree)]
    else:
        dim = len(basis_rows)
        if origin is None:
            raise ValueError("origin is required with basis_rows")

    cs = ppl.Constraint_System()
    ncol = len(N0)
    for j in range(ncol):
        const = int(N0[j]) + sum(int(F[i][j]) * int(origin[i])
                                 for i in range(nfree))
        coeffs = []
        for k in range(dim):
            coeffs.append(sum(int(F[i][j]) * int(basis_rows[k][i])
                              for i in range(nfree)))
        cs.insert(linear_expression(coeffs, const) >= 0)
    return ppl.NNC_Polyhedron(cs)


def width_table(poly, labels, compare_modulus=None, residues=None):
    out = []
    for i, label in enumerate(labels):
        coeffs = [0] * len(labels)
        coeffs[i] = 1
        lo = optimize(poly, coeffs, "min")
        hi = optimize(poly, coeffs, "max")
        residue = None if residues is None else residues[i]
        item = {
            "index": i,
            "label": label,
        }
        item.update(interval_summary(lo, hi, compare_modulus, residue))
        out.append(item)
        if lo is None or hi is None:
            print("  %-8s unbounded" % label, flush=True)
        else:
            print("  %-8s width=%s/%s  interval=[%s/%s, %s/%s]" %
                  (label, (hi - lo).numerator, (hi - lo).denominator,
                   lo.numerator, lo.denominator, hi.numerator, hi.denominator),
                  flush=True)
    return out


def egcd(a, b):
    old_r, r = abs(a), abs(b)
    old_s, s = 1, 0
    old_t, t = 0, 1
    while r:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_s, s = s, old_s - q * s
        old_t, t = t, old_t - q * t
    return old_r, old_s if a >= 0 else -old_s, old_t if b >= 0 else -old_t


def crt_pair(r1, m1, r2, m2):
    g, s, _ = egcd(m1, m2)
    if (r2 - r1) % g:
        raise ValueError("CRT inconsistent")
    lcm = m1 // g * m2
    if m2 // g == 1:
        return r1 % lcm, lcm
    t = ((r2 - r1) // g * s) % (m2 // g)
    return (r1 + m1 * t) % lcm, lcm


def get_particular(sol):
    return [int(x) for x in sol.get("particular", sol.get("offset"))]


def get_kernel_gens(sol):
    return [[int(x) for x in row]
            for row in sol.get("kernel_gens", sol.get("basis_columns", []))]


def combine_odd_solution(lattice):
    n = int(lattice["num_freedoms"])
    odd_mod = 1
    odd_offset = [0] * n
    for sol in lattice["prime_power_solutions"]:
        if int(sol["p"]) == 2:
            continue
        mod = int(sol["modulus"])
        off = get_particular(sol)
        for i in range(n):
            odd_offset[i], new_mod = crt_pair(odd_offset[i], odd_mod,
                                              off[i], mod)
        odd_mod = new_mod
    return odd_mod, odd_offset


def congruence_period_lattice(lattice):
    n = int(lattice["num_freedoms"])
    odd_mod, odd_offset = combine_odd_solution(lattice)
    two = next(sol for sol in lattice["prime_power_solutions"]
               if int(sol["p"]) == 2)
    two_mod = int(two["modulus"])
    two_particular = get_particular(two)
    two_kernel = get_kernel_gens(two)

    full_mod = odd_mod * two_mod
    full_origin = []
    for i in range(n):
        x, mod = crt_pair(odd_offset[i], odd_mod,
                          two_particular[i], two_mod)
        assert mod == full_mod
        full_origin.append(int(x))

    lifted = []
    for row in two_kernel:
        lifted.append([crt_pair(0, odd_mod, row[i], two_mod)[0]
                       for i in range(n)])
    for i in range(n):
        v = [0] * n
        v[i] = full_mod
        lifted.append(v)

    H = matrix(ZZ, lifted).hermite_form(include_zero_rows=False)
    basis = [[int(H[i, j]) for j in range(H.ncols())]
             for i in range(H.nrows())]
    det = abs(int(H.det()))
    odd_covolume = odd_mod ** n
    if det % odd_covolume:
        raise AssertionError("period determinant is not divisible by odd covolume")
    two_primary_index = det // odd_covolume

    return {
        "odd_modulus": int(odd_mod),
        "odd_offset": [int(x) for x in odd_offset],
        "two_primary_modulus": int(two_mod),
        "two_primary_particular": two_particular,
        "two_primary_kernel_gens": two_kernel,
        "full_modulus": int(full_mod),
        "full_origin": full_origin,
        "period_basis_rows": basis,
        "period_covolume": int(det),
        "odd_covolume": int(odd_covolume),
        "two_primary_index": int(two_primary_index),
    }


def exact_feasible(N0, F, a):
    for j in range(len(N0)):
        val = int(N0[j]) + sum(int(F[i][j]) * int(a[i])
                               for i in range(len(F)))
        if val < 0:
            return False
    return True


def enumerate_lattice_points(N0, F, origin, basis_rows, widths, max_product):
    ranges = []
    product = 1
    for item in widths:
        if not item["bounded"]:
            return {
                "attempted": False,
                "reason": "unbounded lattice coordinate interval",
            }
        lo = Fraction(int(item["min"]["num"]), int(item["min"]["den"]))
        hi = Fraction(int(item["max"]["num"]), int(item["max"]["den"]))
        lo_i = ceil_fraction(lo)
        hi_i = floor_fraction(hi)
        count = max(0, hi_i - lo_i + 1)
        ranges.append((lo_i, hi_i, count))
        product *= count

    if product > max_product:
        return {
            "attempted": False,
            "reason": "coordinate box exceeds max_product",
            "coordinate_box_product": str(product),
            "max_product": int(max_product),
            "ranges": [{"min": str(a), "max": str(b), "count": int(c)}
                       for a, b, c in ranges],
        }

    points = []
    for y in itertools.product(*(range(a, b + 1) for a, b, _ in ranges)):
        avec = [int(origin[i]) + sum(int(y[k]) * int(basis_rows[k][i])
                                    for k in range(len(basis_rows)))
                for i in range(len(origin))]
        if exact_feasible(N0, F, avec):
            points.append({"lattice_coordinates": [int(v) for v in y],
                           "a": [int(v) for v in avec]})

    return {
        "attempted": True,
        "coordinate_box_product": str(product),
        "num_points": int(len(points)),
        "points": points,
        "ranges": [{"min": str(a), "max": str(b), "count": int(c)}
                   for a, b, c in ranges],
    }


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--max-enumerate", type=int, default=200_000,
                    help="maximum lattice-coordinate box size to enumerate")
    args = ap.parse_args(argv)

    V = load_json_gz(os.path.join(HERE, "exact_V.json.gz"))
    lattice = load_json_gz(os.path.join(HERE, "full_congruence_lattice.json.gz"))

    if not V.get("verified", False):
        raise SystemExit("exact_V.json.gz is not marked verified")
    N = V["N"]
    g = int(V["genuine_row"])
    N0 = [int(x) for x in N[g]]
    free_idx = [i for i in range(len(N)) if i != g]
    F = [[int(x) for x in N[i]] for i in free_idx]
    labels = ["a%d" % (i + 1) for i in range(len(F))]

    print("exact V: rank=%d genuine=%d free_dim=%d orbits=%d den=%s" %
          (len(N), g, len(F), len(N0), V["den"]), flush=True)

    print("\nbuilding positivity polytope in raw freedom coordinates ...",
          flush=True)
    poly = build_polyhedron(N0, F)
    empty = poly.is_empty()
    if empty:
        out = {"verdict": "EMPTY_POSITIVITY_POLYTOPE", "empty": True}
        with open(args.out, "w") as fh:
            json.dump(out, fh, indent=2, sort_keys=True)
        print("PPL: positivity polytope is EMPTY.", flush=True)
        return 0
    raw_dim = int(poly.affine_dimension())
    print("PPL: nonempty, affine dim %d" % raw_dim, flush=True)

    period = congruence_period_lattice(lattice)
    print("\ncongruence lattice:", flush=True)
    print("  odd modulus: %d" % period["odd_modulus"], flush=True)
    print("  odd offset :", period["odd_offset"], flush=True)
    print("  2-primary modulus: %d" % period["two_primary_modulus"], flush=True)
    print("  2-primary index : %d" % period["two_primary_index"], flush=True)
    print("  period basis determinant: %d" % period["period_covolume"],
          flush=True)

    print("\nraw coordinate widths:", flush=True)
    raw_widths = width_table(poly, labels,
                             compare_modulus=period["odd_modulus"],
                             residues=period["odd_offset"])

    print("\nbuilding positivity polytope in congruence-lattice coordinates ...",
          flush=True)
    lpoly = build_polyhedron(N0, F,
                             origin=period["full_origin"],
                             basis_rows=period["period_basis_rows"])
    if lpoly.is_empty():
        lattice_widths = []
        enum = {
            "attempted": False,
            "reason": "full congruence residue class does not meet positivity",
        }
        verdict = "NO_CONGRUENCE_LATTICE_POINT"
        print("PPL: full congruence lattice slice is empty.", flush=True)
    else:
        ldim = int(lpoly.affine_dimension())
        print("PPL: full congruence lattice slice nonempty over R, affine dim %d"
              % ldim, flush=True)
        lattice_labels = ["z%d" % (i + 1)
                          for i in range(len(period["period_basis_rows"]))]
        print("\nlattice-coordinate widths:", flush=True)
        lattice_widths = width_table(lpoly, lattice_labels,
                                     compare_modulus=1,
                                     residues=[0] * len(lattice_labels))
        enum = enumerate_lattice_points(
            N0, F, period["full_origin"], period["period_basis_rows"],
            lattice_widths, args.max_enumerate
        )
        verdict = "CONSISTENT"

    out = {
        "note": "Section 28.2 exact width/lattice geometry for the genus-3 freedom polytope.",
        "verdict": verdict,
        "empty": False,
        "exact_V": {
            "den": int(V["den"]),
            "genuine_row": g,
            "free_rows": free_idx,
            "num_orbits": len(N0),
        },
        "positivity_affine_dimension": raw_dim,
        "congruence_lattice": period,
        "raw_coordinate_widths": raw_widths,
        "lattice_coordinate_widths": lattice_widths,
        "enumeration": enum,
    }
    with open(args.out, "w") as fh:
        json.dump(out, fh, indent=2, sort_keys=True)
    print("\nsaved -> %s" % args.out, flush=True)
    if enum.get("attempted"):
        print("enumerated lattice points: %d" % enum["num_points"], flush=True)
    else:
        print("enumeration skipped: %s" % enum.get("reason"), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
