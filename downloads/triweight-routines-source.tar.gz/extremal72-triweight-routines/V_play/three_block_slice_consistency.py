#!/usr/bin/env python3
"""Section 28.3: three-block aggregate consistency on the (16,16,.) slice.

A potential *rational-dimension* cut on the genus-3 freedom V -- the thing
positivity and congruences provably cannot deliver (RECURSIVE.md sec 28, 28.3).

Idea.  The (16,16,.) slice of the genus-3 triweight, restricted to ordered
DISJOINT minimum pairs (u,v) = (B,B'), is exactly the aggregate over all
N_DISJ_PAIRS = 249849*5082 ordered disjoint pairs of the sec-15.1 three-block
split tables

    Z[i,j,k] = #{ x in C : wt(x|_B)=i, wt(x|_B')=j, wt(x|_R)=k },   16|16|40.

The triweight orbit  mu = (40-k, 16-i, 16-j, 0, k, i, j, 0)  (cells u=bit0,
v=bit1, w=bit2) counts ordered triples (u,v,w) with u,v a disjoint wt-16 pair and
the third word w of block type (i,j,k); summing over the pair gives

    v_mu  =  sum over ordered disjoint pairs  Z[i,j,k]   ( = "agg[i,j,k]" ).

Every per-pair Z lies in the sec-15.1 affine family z0 + H, H = ker M the
4-dimensional homogeneous space of the three-block system M Z = rhs (rank 91 over
95 toggle orbits).  Therefore the aggregate lies in N*z0 + H, i.e.

    M . agg  =  N_DISJ_PAIRS * rhs.                               (*)

Writing the slice value at orbit o as  v(o)(a) = (Ng[o] + sum_l a_l Nf_l[o]) / DEN
in the exact V coordinates (a = the 5 freedom parameters), (*) becomes

    G a = d,     G_l := M . Nf_l_slice,   d := DEN*N*rhs - M . Ng_slice.

rank(G) is the number of independent NEW equations the slice imposes -- a
rational-dimension cut from 5 to 5-rank(G).  This is EXACT (a genuine triweight's
slice MUST be such an aggregate, so each freedom direction's slice must lie in
span(H); a membership failure M.Nf_l_slice != 0 is an exact kill independent of
the per-pair values -- the sec-28.3 span/membership guarantee).  Inhomogeneous
consistency of G a = d is feasibility-level and inherits the sec-15.2 locality
caveat.

Step 3 (sec 28.3): the sec-15.1 toggle-stabilizer / R-fiber divisibilities push
through the aggregation to congruences on (Ng_slice + sum a_l Nf_l_slice); we
intersect them with the 2-primary block of full_congruence_lattice.json.gz to see
whether they induce a 2-adic divisibility the Jacobi d_mu lattice does not contain.

Run:
    DOT_SAGE=/tmp/sage HOME=/tmp /home/vva/miniforge3/bin/python \\
        three_block_slice_consistency.py
"""
import gzip
import json
import math
import os
import sys
from fractions import Fraction

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
sys.path.insert(0, SP)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                       # noqa: E402
from reconstruct_charzero import build_structure        # noqa: E402

A16_C = 249849
A16_CB = 5082
N_DISJ_PAIRS = A16_C * A16_CB           # ordered disjoint minimum pairs (u,v)
CODE = 1 << 36                          # |C| = 2^36

GLEASON = {0: 1, 16: 249849, 20: 18106704, 24: 462962955, 28: 4397342400,
           32: 16602715899, 36: 25756721120, 40: 16602715899, 44: 4397342400,
           48: 462962955, 52: 18106704, 56: 249849, 72: 1}
W = set(GLEASON)
NB, NBp, NR = 16, 16, 40


# --------------------------------------------------------------------------- #
# exact rational rank (Fraction; small matrices)
# --------------------------------------------------------------------------- #
def mat_rank(rows):
    M = [[Fraction(x) for x in r] for r in rows]
    if not M:
        return 0
    ncols = len(M[0])
    rank = pr = 0
    for c in range(ncols):
        piv = next((r for r in range(pr, len(M)) if M[r][c] != 0), None)
        if piv is None:
            continue
        M[pr], M[piv] = M[piv], M[pr]
        inv = M[pr][c]
        M[pr] = [x / inv for x in M[pr]]
        for r in range(len(M)):
            if r != pr and M[r][c] != 0:
                f = M[r][c]
                M[r] = [a - f * b for a, b in zip(M[r], M[pr])]
        pr += 1
        rank += 1
        if pr == len(M):
            break
    return rank


def rank_mod_np(int_rows, p):
    """Rank of an integer matrix mod prime p (vectorized, p < 2^31)."""
    A = np.array([[x % p for x in row] for row in int_rows], dtype=np.int64)
    nr, nc = A.shape
    rank = pr = 0
    for c in range(nc):
        col = A[pr:, c]
        nz = np.nonzero(col % p)[0]
        if nz.size == 0:
            continue
        piv = pr + int(nz[0])
        A[[pr, piv]] = A[[piv, pr]]
        inv = pow(int(A[pr, c]), p - 2, p)
        A[pr] = (A[pr] * inv) % p
        mask = (A[:, c] % p != 0)
        mask[pr] = False
        if mask.any():
            A[mask] = (A[mask] - np.outer(A[mask, c], A[pr])) % p
        pr += 1
        rank += 1
        if pr == nr:
            break
    return rank


# --------------------------------------------------------------------------- #
def load_V():
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; DEN = int(V["den"]); g = int(V["genuine_row"])
    free = [k for k in range(len(N)) if k != g]
    Ng = [int(x) for x in N[g]]
    Nf = [[int(x) for x in N[k]] for k in free]
    return Ng, Nf, DEN, len(N[0])


def build_key2orb():
    t = Target.load(72, "mindist")
    mono2col = build_structure(t)[0]
    raw_mono = t.raw
    POW = [73 ** p for p in range(8)]
    keys = (raw_mono.astype(object) * np.array(POW, dtype=object)).sum(1)
    return {int(keys[i]): int(mono2col[i]) for i in range(raw_mono.shape[0])}, POW


# --------------------------------------------------------------------------- #
# three-block system M Z = rhs over the 95 toggle orbits
# (faithful port of three_block/three_block_macwilliams.sage eqs 1-4)
# --------------------------------------------------------------------------- #
def krawtchouk(n, r, i):
    return sum((-1) ** l * math.comb(i, l) * math.comb(n - i, r - l)
               for l in range(max(0, r - (n - i)), min(r, i) + 1))


def images(i, j, k):
    return [(a, b, c) for a in (i, 16 - i) for b in (j, 16 - j) for c in (k, 40 - k)]


def build_three_block():
    raw = [(i, j, k) for i in range(0, 17, 2) for j in range(0, 17, 2)
           for k in range(0, 41, 2)
           if all((a + b + c) in W for (a, b, c) in images(i, j, k))]
    rawset = set(raw)
    orb_of, orbits = {}, []
    for tt in raw:
        if tt in orb_of:
            continue
        o = sorted(set(images(*tt)) & rawset)
        idx = len(orbits); orbits.append(o)
        for s in o:
            orb_of[s] = idx
    NV = len(orbits)

    K16 = {(r, i): krawtchouk(NB, r, i) for r in range(0, 17, 2) for i in range(17)}
    K40 = {(r, i): krawtchouk(NR, r, i) for r in range(0, 41, 2) for i in range(41)}

    rows = []      # (coeff list over NV, Fraction rhs, label)
    for r in range(0, 17, 2):                                   # (1) MacWilliams
        for s in range(0, 17, 2):
            for t in range(0, 41, 2):
                c = [0] * NV
                for (i, j, k) in raw:
                    c[orb_of[(i, j, k)]] += K16[(r, i)] * K16[(s, j)] * K40[(t, k)]
                if (r, s, t) in rawset:
                    c[orb_of[(r, s, t)]] -= CODE
                rows.append((c, Fraction(0), "MW:%d,%d,%d" % (r, s, t)))
    for w in sorted(W):                                          # (2) Gleason rows
        c = [0] * NV
        for (i, j, k) in raw:
            if i + j + k == w:
                c[orb_of[(i, j, k)]] += 1
        rows.append((c, Fraction(GLEASON[w]), "ROW:%d" % w))
    for s in range(0, 6):                                        # (3) 5-design moments
        for a in range(0, s + 1):
            for b in range(0, s - a + 1):
                cc = s - a - b
                if cc > NR:
                    continue
                for w in sorted(W):
                    if w == 0:
                        continue
                    lam = Fraction(GLEASON[w]) * math.comb(w, s) / math.comb(72, s)
                    c = [0] * NV
                    for (i, j, k) in raw:
                        if i + j + k == w:
                            c[orb_of[(i, j, k)]] += (math.comb(i, a) * math.comb(j, b)
                                                     * math.comb(k, cc))
                    rr = math.comb(16, a) * math.comb(16, b) * math.comb(40, cc) * lam
                    rows.append((c, rr, "DES:s%d,%d%d%d,w%d" % (s, a, b, cc, w)))
    ce = [0] * NV                                                # (4) corner
    ce[orb_of[(0, 0, 0)]] = 1
    rows.append((ce, Fraction(1), "CORNER"))

    # divisibility data for step 3
    stab_exp = []
    for members in orbits:
        i, j, kk = members[0]
        stab_exp.append((1 if i == 8 else 0) + (1 if j == 8 else 0) + (1 if kk == 20 else 0))
    r_coeff = {}
    for kk in range(0, 41, 2):
        c = [0] * NV
        for (i, j, k0) in raw:
            if k0 == kk:
                c[orb_of[(i, j, k0)]] += 1
        if any(c):
            r_coeff[kk] = c
    return raw, orbits, NV, rows, stab_exp, r_coeff


# --------------------------------------------------------------------------- #
def main():
    print("=" * 78)
    print("Section 28.3  Three-block aggregate consistency on the (16,16,.) slice")
    print("=" * 78, flush=True)

    Ng, Nf, DEN, ncol = load_V()
    free_dim = len(Nf)
    print("V: ncol=%d DEN=%d free_dim=%d  N_DISJ_PAIRS=%d"
          % (ncol, DEN, free_dim, N_DISJ_PAIRS), flush=True)

    key2orb, POW = build_key2orb()

    def col_of_ijk(i, j, k):
        mu = (40 - k, 16 - i, 16 - j, 0, k, i, j, 0)
        return key2orb.get(sum(mu[p] * POW[p] for p in range(8)))

    raw, orbits, NV, rows, stab_exp, r_coeff = build_three_block()
    print("three-block: %d raw points, %d toggle orbits, %d constraint rows"
          % (len(raw), NV, len(rows)), flush=True)

    # build-correctness: M rank == 91 (sage value) over two primes
    int_rows = [c for (c, _r, _l) in rows]
    rk1 = rank_mod_np(int_rows, (1 << 31) - 1)
    rk2 = rank_mod_np(int_rows, 2_147_483_629)
    assert rk1 == rk2 == 91, "three-block M rank mismatch: %d/%d (expected 91)" % (rk1, rk2)
    print("  M rank = %d over two primes (sage value 91); kernel dim H = %d"
          % (rk1, NV - rk1), flush=True)

    # ---- slice numerator vectors over the 95 toggle orbits ------------------ #
    Ng_slice = [0] * NV
    Nf_slice = [[0] * NV for _ in range(free_dim)]
    for o in range(NV):
        vset, col0 = set(), None
        for (i, j, k) in orbits[o]:
            c = col_of_ijk(i, j, k)
            assert c is not None, "no triweight column for three-block point %s" % ((i, j, k),)
            vset.add((Ng[c], tuple(Nf[l][c] for l in range(free_dim))))
            col0 = c
        assert len(vset) == 1, "toggle-orbit %d V-values disagree across images" % o
        Ng_slice[o] = Ng[col0]
        for l in range(free_dim):
            Nf_slice[l][o] = Nf[l][col0]
    nz_F = [sum(1 for o in range(NV) if Nf_slice[l][o] != 0) for l in range(free_dim)]
    print("  slice F-support: " + ", ".join("F_%d:%d/%d" % (l + 1, nz_F[l], NV)
                                             for l in range(free_dim)), flush=True)

    # ---- VALIDATIONS -------------------------------------------------------- #
    # (i) negative control: a generic (non-aggregate) slice is detected by M.
    rng = np.random.default_rng(2803)
    ctrl = rng.integers(-9, 10, size=NV).tolist()
    Mctrl = [sum(c[o] * ctrl[o] for o in range(NV)) for (c, _r, _l) in rows]
    ctrl_detected = any(x != 0 for x in Mctrl)
    # (ii) the nonzero slice freedoms are genuinely independent (rank 3) ...
    nz_dirs = [l for l in range(free_dim) if nz_F[l] > 0]
    rank_slice_F = mat_rank([[Nf_slice[l][o] for l in nz_dirs] for o in range(NV)])
    # (iii) ... yet each lies in H = ker M (so they cannot be cut):
    each_in_H = all(all(sum(c[o] * Nf_slice[l][o] for o in range(NV)) == 0
                        for (c, _r, _l) in rows) for l in nz_dirs)
    # (iv) corner d=0 is structurally real: v(0,0,0) == N_DISJ_PAIRS identically.
    c000 = col_of_ijk(0, 0, 0)
    corner_ok = (Ng[c000] == DEN * N_DISJ_PAIRS and all(Nf[l][c000] == 0 for l in range(free_dim)))
    print("\n  VALIDATION")
    print("    negative control (M detects a generic slice perturbation): %s" % ctrl_detected)
    print("    nonzero slice freedoms F_%s independent: rank %d of %d  (in 4-dim H)"
          % (",".join(str(l + 1) for l in nz_dirs), rank_slice_F, len(nz_dirs)))
    print("    each nonzero slice freedom lies in H = ker M: %s" % each_in_H)
    print("    corner v(0,0,0) == N_DISJ_PAIRS identically (R0 slice aggregate-real): %s"
          % corner_ok, flush=True)
    assert ctrl_detected and corner_ok, "validation failed"

    # ---- G_l = M . Nf_l_slice  and  d = DEN*N*rhs - M . Ng_slice ------------- #
    G_cols = [[sum(c[o] * Nf_slice[l][o] for o in range(NV)) for (c, _r, _l) in rows]
              for l in range(free_dim)]
    d_vec = [DEN * N_DISJ_PAIRS * rr - sum(c[o] * Ng_slice[o] for o in range(NV))
             for (c, rr, _l) in rows]

    G_rows, Gd_rows, carrier = [], [], []
    for ridx in range(len(rows)):
        grow = [G_cols[l][ridx] for l in range(free_dim)]
        d = d_vec[ridx]
        if any(g != 0 for g in grow) or d != 0:
            G_rows.append(grow); Gd_rows.append(grow + [d])
            carrier.append((rows[ridx][2], grow, d))
    rank_G = mat_rank(G_rows)
    rank_Gd = mat_rank(Gd_rows)
    consistent = (rank_G == rank_Gd)
    cut_dirs = [l + 1 for l in range(free_dim)
                if any(G_cols[l][r] != 0 for r in range(len(rows)))]

    print("\n" + "-" * 78)
    print("SPAN / MEMBERSHIP TEST  (the exact rational-dimension cut)")
    print("-" * 78)
    print("  rank(G)        = %d   (independent NEW equations on the 5 freedoms)" % rank_G)
    print("  rational dim   : 5 -> %d" % (free_dim - rank_G))
    print("  rank([G | d])  = %d   inhomogeneous consistent? %s" % (rank_Gd, consistent))
    print("  freedoms whose slice leaves H: %s"
          % (("F_" + ",F_".join(map(str, cut_dirs))) if cut_dirs else "none (all in H)"))
    if rank_G == 0:
        print("\n  RESULT: every freedom's (16,16,.) slice lies in span(H); the three-block")
        print("  aggregate consistency is AUTOMATICALLY satisfied.  No rational-dimension")
        print("  cut -- the slice SATURATES (genus-3 dimension stays 5).")
    else:
        print("\n  RESULT: %d freedom direction(s) leave span(H) -- a rational-dimension CUT,")
        print("  the first below 5.  Rows carrying it (sample):" % rank_G)
        for lab, grow, d in [r for r in carrier if any(g != 0 for g in r[1])][:12]:
            print("     %-18s  G=%s  d=%s" % (lab, grow, d))

    # ---- STEP 3: aggregate divisibilities vs the 2-primary Jacobi lattice ---- #
    print("\n" + "-" * 78)
    print("STEP 3  aggregate sec-15.1 divisibilities  ->  full_congruence_lattice (p=2)")
    print("-" * 78, flush=True)
    with gzip.open(os.path.join(HERE, "full_congruence_lattice.json.gz"), "rt") as fh:
        lat = json.load(fh)
    blk2 = next(b for b in lat["prime_power_solutions"] if b["p"] == 2)
    MOD2 = int(blk2["modulus"]); part = [int(x) for x in blk2["particular"]]
    kers = [[int(x) for x in g] for g in blk2["kernel_gens"]]

    def v2(n):
        c = 0
        while n % 2 == 0:
            n //= 2; c += 1
        return c

    def classify(const, form, m):
        """Is the congruence  const + sum form_l a_l ≡ 0 (mod m)  implied by /
        new to / inconsistent with the 2-primary lattice a ≡ part + Z<kers> (m | MOD2)?

        On the lattice a = part + sum_g t_g kers[g], the congruence becomes
        sum_g (form . kers[g]) t_g ≡ -base (mod m).  Let gd = gcd(m, {form.kers[g]}):
        all gens ≡ 0 (gd==m) -> redundant/inconsistent by base; else solvable
        (cuts the module = "new") iff gd | base, otherwise inconsistent."""
        base = (const + sum(form[l] * part[l] for l in range(free_dim))) % m
        gens = [sum(form[l] * g[l] for l in range(free_dim)) % m for g in kers]
        gd = m
        for gv in gens:
            gd = math.gcd(gd, gv)
        if gd == m:                       # every generator coefficient ≡ 0 (mod m)
            return "redundant" if base == 0 else "inconsistent"
        return "new" if base % gd == 0 else "inconsistent"

    # guard: classify() must certify the lattice's OWN Jacobi divisibilities
    # (v_mu ≡ 0 mod 64*d_mu, 2-part) redundant -- a self-test of the comparison.
    with gzip.open(os.path.join(HERE, "jacobi_divisors.json.gz"), "rt") as fh:
        jdat = json.load(fh)
    jden, divs = int(jdat["den"]), jdat["divisors"]
    selftest_bad = 0
    for mu in range(ncol):
        m2 = 1 << min(v2(jden * int(divs[mu])), v2(MOD2))
        if m2 == 1:
            continue
        if classify(Ng[mu], [Nf[l][mu] for l in range(free_dim)], m2) != "redundant":
            selftest_bad += 1
    assert selftest_bad == 0, "classify() self-test failed on %d Jacobi divisibilities" % selftest_bad
    print("  classify() self-test (lattice's own Jacobi divisibilities -> redundant): OK", flush=True)

    cong = []   # (label, const, form, modulus, kind)
    for o in range(NV):                                  # toggle-stabilizer
        if stab_exp[o] == 0:
            continue
        m = DEN * (1 << stab_exp[o])
        cong.append(("stab[o=%d]" % o, Ng_slice[o],
                     [Nf_slice[l][o] for l in range(free_dim)], m, "stab"))
    for kk, c in r_coeff.items():                        # R-fiber mod 4
        const = sum(c[o] * Ng_slice[o] for o in range(NV))
        form = [sum(c[o] * Nf_slice[l][o] for o in range(NV)) for l in range(free_dim)]
        cong.append(("Rfiber[r=%d]" % kk, const, form, DEN * 4, "rfiber"))
    counts = {"redundant": 0, "new": 0, "inconsistent": 0}
    new_by_kind = {"stab": 0, "rfiber": 0}
    new_examples, inconsistent = [], []
    for lab, const, form, m, kind in cong:
        verdict = classify(const, form, m)
        counts[verdict] += 1
        if verdict == "new":
            new_by_kind[kind] += 1
            if len(new_examples) < 8:
                new_examples.append(lab)
        if verdict == "inconsistent":
            inconsistent.append(lab)
    print("  %d aggregate divisibility congruences (toggle-stabilizer + R-fiber):" % len(cong))
    print("    redundant (implied by the Jacobi 2-lattice) : %d" % counts["redundant"])
    print("    NEW (cut the 2-primary module)              : %d  (%d stabilizer + %d R-fiber)"
          % (counts["new"], new_by_kind["stab"], new_by_kind["rfiber"]))
    if new_examples:
        print("      e.g. " + ", ".join(new_examples))
    print("    inconsistent (would contradict)             : %d %s"
          % (counts["inconsistent"], inconsistent[:6]))
    if counts["inconsistent"]:
        print("    NOTE: an aggregate-feasibility inconsistency inherits the sec-15.2")
        print("          locality caveat; recheck normalization before citing as a kill.")

    # ---- verdict ------------------------------------------------------------ #
    verdict = {
        "section": "28.3",
        "n_disjoint_pairs": N_DISJ_PAIRS,
        "three_block_orbits": NV, "three_block_M_rows": len(rows),
        "three_block_M_rank": int(rk1), "three_block_kernel_dim": int(NV - rk1),
        "slice_F_support": {("F_%d" % (l + 1)): nz_F[l] for l in range(free_dim)},
        "slice_freedom_rank": int(rank_slice_F),
        "slice_freedoms_all_in_H": bool(each_in_H),
        "negative_control_detected": bool(ctrl_detected),
        "corner_aggregate_real": bool(corner_ok),
        "rank_G": int(rank_G),
        "rational_dim_before": free_dim, "rational_dim_after": int(free_dim - rank_G),
        "inhomogeneous_consistent": bool(consistent),
        "cut_directions": cut_dirs, "saturates": (rank_G == 0),
        "step3_congruences": len(cong),
        "step3_redundant": counts["redundant"], "step3_new": counts["new"],
        "step3_new_stabilizer": new_by_kind["stab"], "step3_new_rfiber": new_by_kind["rfiber"],
        "step3_inconsistent": counts["inconsistent"],
        "note": ("rank(G) is the exact sec-28.3 span/membership cut (kills exact "
                 "regardless of per-pair values); inhomogeneous consistency and step-3 "
                 "feasibility inherit the sec-15.2 locality caveat."),
    }
    out = os.path.join(HERE, "three_block_slice_verdict.json")
    json.dump(verdict, open(out, "w"), indent=1)
    print("\nsaved %s" % out, flush=True)
    return verdict


if __name__ == "__main__":
    main()
