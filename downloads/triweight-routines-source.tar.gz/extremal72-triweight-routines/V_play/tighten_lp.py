#!/usr/bin/env python3
"""Tighten the genus-3 positivity LP with the FULL forced biweight B.

The recovered genuine direction R_0 = N_0/64 satisfies M2(R_0) = |C|*B EXACTLY at
ALL 1177 (wu,wv,t) marginal rows (verified on the 357 forced rows in recover_V;
determined everywhere by R_0).  So the full forced biweight is

    B[row] = M2(N_0)[row] / (64 * |C|)      (integer, the unique genus-2 enumerator)

Every candidate genus-3 enumerator v = R_0 + sum_i a_i F_i has the SAME marginal
M2(v) = |C|*B (freedoms have M2=0).  Each orbit coefficient is bounded by every
marginal fibre it sits in:

    0 <= v_j <= min over fibres (row,mult of orbit j) of |C|*B[row] / mult .

Unlike the 357-row partial bounds, this uses ALL rows -- including the B=0
forbidden marginals, which FORCE v_j = 0 for any orbit whose marginal lands on a
forbidden (wu,wv,t).  We rebuild the exact bounds and re-run the PPL LP over the
5-dim freedom space.
"""
import gzip
import json
import os
import sys

import ppl

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
sys.path.insert(0, SP)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                              # noqa: E402
from reconstruct_charzero import build_structure              # noqa: E402
from reconstruct_integer import (NC, build_col_marginal_counts,   # noqa: E402
                                 marginal_of_orbit_vector_int, target_wuvt_data)

COEFF_BOUND = 1 << 108


def main():
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]
    DEN = int(V["den"])
    g = int(V["genuine_row"])
    ncol = len(N[0])
    rank = len(N)
    free_idx = [k for k in range(rank) if k != g]
    Ng = [int(x) for x in N[g]]
    Nf = [[int(x) for x in N[k]] for k in free_idx]
    free_dim = len(Nf)
    print("exact V: rank=%d genuine=%d free_dim=%d den=%d ncol=%d" % (rank, g, free_dim, DEN, ncol), flush=True)

    t = Target.load(72, "mindist")
    struct = build_structure(t)
    mono2col, inv, nW = struct[0], struct[1], struct[2]
    _, B_known, row000, inv2, missing, known, forced = target_wuvt_data(t, inv)
    col_counts = build_col_marginal_counts(ncol, inv2, mono2col)

    # M2(N_0) = DEN * |C| * B  at every marginal row
    m2N0 = marginal_of_orbit_vector_int(Ng, col_counts, nW)
    scale = DEN * NC
    nbad_int = nbad_match = 0
    Bfull = [0] * nW
    nzero = 0
    for row in range(nW):
        x = int(m2N0[row])
        if x % scale != 0:
            nbad_int += 1
        Bfull[row] = x // scale
        if Bfull[row] == 0:
            nzero += 1
        if B_known[row] is not None and Bfull[row] != int(B_known[row]):
            nbad_match += 1
    print("full B from M2(R_0): %d rows ; non-integer=%d ; mismatch-vs-forced=%d (both want 0)"
          % (nW, nbad_int, nbad_match), flush=True)
    print("  B==0 (forbidden) rows: %d / %d ; previously-known rows: %d ; previously-unknown: %d"
          % (nzero, nW, known, missing), flush=True)
    assert nbad_int == 0 and nbad_match == 0, "full-B derivation inconsistent -> stop"

    # tight bound per orbit
    bounds = []
    nz_forced = 0
    tighter = 0
    for j in range(ncol):
        b = COEFF_BOUND
        for row, mult in col_counts[j]:
            cand = int(m2N0[row]) // (DEN * int(mult))        # = |C|*B[row] // mult
            if cand < b:
                b = cand
        bounds.append(b)
        if b == 0:
            nz_forced += 1
        if b < COEFF_BOUND:
            tighter += 1
    print("tight bounds: max=2^%d ; orbits forced to 0 (bound=0): %d ; orbits with finite bound: %d/%d"
          % (max(bounds).bit_length(), nz_forced, tighter, ncol), flush=True)

    # PPL: 0 <= w_j = Ng[j] + sum a_i Nf[i][j] <= DEN * bounds[j]
    a = [ppl.Variable(i) for i in range(free_dim)]
    cs = ppl.Constraint_System()
    for j in range(ncol):
        e = ppl.Linear_Expression(Ng[j])
        for i in range(free_dim):
            c = Nf[i][j]
            if c:
                e += c * a[i]
        cs.insert(e >= 0)
        cs.insert(e <= DEN * int(bounds[j]))
    print("built %d constraints in %d vars" % (2 * ncol, free_dim), flush=True)

    poly = ppl.NNC_Polyhedron(cs)
    empty = poly.is_empty()
    print("\n================ TIGHTENED POSITIVITY VERDICT (full B) ================", flush=True)
    if empty:
        print("PPL: feasible region EMPTY.")
        print(">>> NO nonnegative genus-3 enumerator with the forced FULL marginal exists.")
        print(">>> extremal Type II [72,36,16] DOES NOT EXIST (genus-3 nonexistence certificate).")
        verdict, dof = "NONEXISTENCE", None
    else:
        dof = poly.affine_dimension()
        print("PPL: NONEMPTY, affine dim %d (was 5 with partial bounds)." % dof)
        print(">>> still NOT ruled out; %d-parameter nonnegative family remains." % dof)
        verdict = "CONSISTENT"
    with open(os.path.join(HERE, "tighten_verdict.json"), "w") as fh:
        json.dump({"verdict": verdict, "empty": bool(empty),
                   "remaining_dof": (None if empty else int(dof)),
                   "B_zero_rows": nzero, "orbits_forced_zero": nz_forced}, fh)
    print("\nverdict: %s" % verdict, flush=True)


if __name__ == "__main__":
    main()
