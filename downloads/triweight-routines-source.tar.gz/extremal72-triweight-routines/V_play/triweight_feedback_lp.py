#!/usr/bin/env python3
"""Section 28.1: Menu -> triweight feedback LP on minimum-word triple orbits.

Reverse the information flow that kept saturating (RECURSIVE.md sec 26.4): instead
of pushing the pinned triweight V into the menu mixture (which the continuous
per-row profiles average away), inject the menu's certified `a`-band INTO the
exact V positivity LP + prime-power congruence lattice.

The flagship rigorous input is the disjoint-triple identity.  The genus-3
complete-weight-enumerator coordinate of the orbit

    mu = (24, 16, 16, 0, 16, 0, 0, 0)         (cells: none=24, u-only/v-only/w-only=16)

counts ordered triples (u,v,w) of weight-16 codewords with pairwise-disjoint
supports.  Summing over the pair (u,v) gives the EXACT identity

    v_disj-triple = 249849 * 5082 * abar,

where 249849 = A_16(C), 5082 = A_16(C_B) = #min words disjoint from a fixed B,
and abar = average over ordered disjoint min-word pairs of a(E) = A_16(E) for the
length-40 double residual E.  Because abar is a convex combination of menu
`a`-values, the certified menu band forces

    3 <= abar <= 103          (min surviving menu a = 3 ; A3 certificate a <= 103)

In the exact V coordinate system this orbit is a PIVOT: R_0 = 0 and only F_1 is
nonzero there (F_1 = 1), so the identity collapses to

    a_1  =  v_disj-triple  =  249849 * 5082 * abar,

i.e. the FIRST freedom parameter IS the ordered disjoint-triple count.  The menu
band is therefore a direct interval box on a_1, which we add to the tightened
positivity LP (tighten_lp.py machinery) and intersect with the odd-part
congruence pin a_1 ≡ 0 (mod 8,744,715).

We also census the full [16,16,16] / [16,16,20] / [16,20,20] basket: for each
orbit we record which freedoms it detects and its (u,v,w) intersection type, and
emit `basket_orbits.json` as the structured feed for the gating per-orbit 3-point
Terwilliger/Schrijver SDP on J(72,16) (sec 28.4 step 3 -- the cluster compute that
bounds the F_5-dense orbits the menu/residual tower cannot see).
"""
import gzip
import json
import os
import re
import sys

import ppl

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.join(os.path.dirname(HERE), "support_pruned")
sys.path.insert(0, SP)
sys.set_int_max_str_digits(10_000_000)

from target_support import Target                                   # noqa: E402
from reconstruct_charzero import build_structure                    # noqa: E402
from reconstruct_integer import (NC, build_col_marginal_counts,     # noqa: E402
                                  marginal_of_orbit_vector_int, target_wuvt_data)

COEFF_BOUND = 1 << 108
A16_C = 249849            # A_16(C), number of weight-16 words of the [72,36,16] code
A16_CB = 5082            # A_16(C_B), min words of the [56,21] residual disjoint from B
N_DISJ_PAIRS = A16_C * A16_CB    # # ordered disjoint minimum-word pairs (u,v)
MENU_MD = os.path.join(os.path.dirname(HERE), os.pardir, "c1_search", "MENU.md")
ODD_MODULUS = 8_744_715  # odd-part congruence modulus (3^2 * 5 * 7 * 17 * 23 * 71)


# ----------------------------------------------------------------------------- #
def venn(mu):
    """(sorted weights), (sorted pairwise overlaps), triple overlap, union size.

    Cell index = u*1 + v*2 + w*4  (u=bit0, v=bit1, w=bit2)."""
    wu = mu[1] + mu[3] + mu[5] + mu[7]
    wv = mu[2] + mu[3] + mu[6] + mu[7]
    ww = mu[4] + mu[5] + mu[6] + mu[7]
    uv = mu[3] + mu[7]; uw = mu[5] + mu[7]; vw = mu[6] + mu[7]; uvw = mu[7]
    return (tuple(sorted((wu, wv, ww))), tuple(sorted((uv, uw, vw))), uvw, 72 - mu[0])


def menu_a_band():
    """Certified [min a, max a] over the surviving menu rows (= abar band)."""
    avals = []
    with open(MENU_MD) as fh:
        for line in fh:
            if "Survives" not in line:
                continue
            m = re.search(r"\(k,a,b\)=\((\d+),(\d+),(\d+)\)", line)
            if m:
                avals.append(int(m.group(2)))
    if not avals:
        raise RuntimeError("no surviving menu rows parsed from %s" % MENU_MD)
    return min(avals), max(avals), len(avals)


def load_V():
    with gzip.open(os.path.join(HERE, "exact_V.json.gz"), "rt") as fh:
        V = json.load(fh)
    N = V["N"]; DEN = int(V["den"]); g = int(V["genuine_row"])
    free = [k for k in range(len(N)) if k != g]
    Ng = [int(x) for x in N[g]]
    Nf = [[int(x) for x in N[k]] for k in free]
    return V, Ng, Nf, DEN, g, len(N[0])


def build_full_B_bounds(Ng, DEN):
    """Exact per-orbit tight bound 0 <= v_j <= bound[j] from the full forced B
    (tighten_lp.py logic), plus the marginal vector m2N0 needed to recheck it."""
    t = Target.load(72, "mindist")
    struct = build_structure(t)
    mono2col, inv, nW = struct[0], struct[1], struct[2]
    _, B_known, _row000, inv2, missing, known, _forced = target_wuvt_data(t, inv)
    col_counts = build_col_marginal_counts(len(Ng), inv2, mono2col)
    m2N0 = marginal_of_orbit_vector_int(Ng, col_counts, nW)
    scale = DEN * NC
    for row in range(nW):
        x = int(m2N0[row])
        assert x % scale == 0, "full-B non-integer at row %d" % row
        b = x // scale
        if B_known[row] is not None:
            assert b == int(B_known[row]), "full-B mismatch vs forced at row %d" % row
    bounds = []
    for j in range(len(Ng)):
        b = COEFF_BOUND
        for row, mult in col_counts[j]:
            cand = int(m2N0[row]) // (DEN * int(mult))
            if cand < b:
                b = cand
        bounds.append(b)
    return bounds, t


def freedom_box(poly, free_dim, label):
    """Exact min/max of each freedom parameter over the polyhedron (or None)."""
    rng = []
    for i in range(free_dim):
        ex = ppl.Linear_Expression(ppl.Variable(i))
        lo = poly.minimize(ex); hi = poly.maximize(ex)
        lo_v = (int(lo["inf_n"]), int(lo["inf_d"])) if lo["bounded"] else None
        hi_v = (int(hi["sup_n"]), int(hi["sup_d"])) if hi["bounded"] else None
        rng.append((lo_v, hi_v))
    return rng


def fmt_ratio(r):
    if r is None:
        return "unbounded"
    n, d = r
    return str(n) if d == 1 else "%d/%d" % (n, d)


# ----------------------------------------------------------------------------- #
def main():
    print("=" * 78)
    print("Section 28.1  Menu -> triweight feedback LP")
    print("=" * 78, flush=True)

    V, Ng, Nf, DEN, g, ncol = load_V()
    free_dim = len(Nf)
    a_min, a_max, n_rows = menu_a_band()
    print("\nMenu band (surviving rows = %d): %d <= a(E) <= %d  => %d <= abar <= %d"
          % (n_rows, a_min, a_max, a_min, a_max), flush=True)

    # ---- locate the disjoint-triple orbit and verify v_disj = a_1 ----------- #
    t0 = Target.load(72, "mindist")
    col_reps = [tuple(int(x) for x in r) for r in t0.col_reps]
    DISJ_MU = (24, 16, 16, 0, 16, 0, 0, 0)
    disj = [j for j in range(ncol) if col_reps[j] == DISJ_MU]
    assert len(disj) == 1, "expected one disjoint-triple orbit, got %d" % len(disj)
    jd = disj[0]
    coeffs = [Nf[i][jd] for i in range(free_dim)]
    assert Ng[jd] == 0 and coeffs[0] == DEN and all(c == 0 for c in coeffs[1:]), \
        "disjoint-triple orbit is not the clean a_1 pivot: R0=%d coeffs=%s" % (Ng[jd], coeffs)
    print("\ndisjoint-triple orbit j=%d  mu=%s" % (jd, col_reps[jd]))
    print("  R_0 = 0,  F_1 = 1,  F_2..F_5 = 0   =>   v_disj = a_1  (exact identity)")
    print("  identity:  a_1 = 249849 * 5082 * abar = %d * abar" % N_DISJ_PAIRS)

    lo_box = N_DISJ_PAIRS * a_min
    hi_box = N_DISJ_PAIRS * a_max
    print("  menu box:  %d <= a_1 <= %d" % (lo_box, hi_box), flush=True)

    # ---- census the [16,16,16]/[16,16,20]/[16,20,20] basket ----------------- #
    print("\n" + "-" * 78)
    print("Basket census (min-word-triple support orbits; F_5 lives here)")
    print("-" * 78, flush=True)
    BASKET_WTS = {(16, 16, 16), (16, 16, 20), (16, 20, 20)}
    basket = []
    for j in range(ncol):
        wt, pp, uvw, un = venn(col_reps[j])
        if wt not in BASKET_WTS:
            continue
        nz = [i + 1 for i in range(free_dim) if Nf[i][j]]
        basket.append({"j": j, "weights": list(wt), "pair_overlaps": list(pp),
                       "triple_overlap": uvw, "union": un, "detects": nz,
                       "R0_num": Ng[j], "F_num": [Nf[i][j] for i in range(free_dim)]})
    # clean single-freedom orbits (one box per parameter, no SDP needed for those)
    single = {}
    for o in basket:
        if len(o["detects"]) == 1:
            single.setdefault(o["detects"][0], []).append(o)
    nwt = {wt: sum(1 for o in basket if tuple(o["weights"]) == wt) for wt in BASKET_WTS}
    for wt in sorted(BASKET_WTS):
        print("  %-12s : %3d orbits" % (str(list(wt)), nwt[wt]))
    print("  total basket: %d orbits" % len(basket))
    print("  clean single-freedom orbits (count = one parameter exactly):")
    for fi in sorted(single):
        for o in single[fi]:
            print("     a_%d  <-  j=%d  weights=%s pair=%s tri=%d   (coeff F_%d=%d)"
                  % (fi, o["j"], o["weights"], o["pair_overlaps"], o["triple_overlap"],
                     fi, o["F_num"][fi - 1] // DEN if o["F_num"][fi - 1] % DEN == 0
                     else o["F_num"][fi - 1]))
    # how many basket orbits need the gating 3-point SDP (multi-freedom, F_5-bearing)
    f5_orbits = [o for o in basket if 5 in o["detects"]]
    print("  basket orbits bearing F_5 (the residual-invisible direction): %d"
          % len(f5_orbits))
    print("    -> these need the per-orbit 3-point SDP / Johnson LP (sec 28.4 step 3,"
          " gating compute); emitted to basket_orbits.json for the cluster solver",
          flush=True)

    # ---- exact positivity LP, baseline vs + disjoint box -------------------- #
    print("\n" + "-" * 78)
    print("Exact positivity LP (full forced-B bounds) + disjoint-triple box")
    print("-" * 78, flush=True)
    bounds, _ = build_full_B_bounds(Ng, DEN)

    def base_cs():
        cs = ppl.Constraint_System()
        a = [ppl.Variable(i) for i in range(free_dim)]
        for j in range(ncol):
            e = ppl.Linear_Expression(Ng[j])
            for i in range(free_dim):
                c = Nf[i][j]
                if c:
                    e += c * a[i]
            cs.insert(e >= 0)
            cs.insert(e <= DEN * int(bounds[j]))
        return cs, a

    cs0, _ = base_cs()
    poly0 = ppl.NNC_Polyhedron(cs0)
    print("baseline: empty=%s  affine_dim=%d" % (poly0.is_empty(), poly0.affine_dimension()))
    base_rng = freedom_box(poly0, free_dim, "baseline")
    print("  a_1 baseline range: [%s, %s]"
          % (fmt_ratio(base_rng[0][0]), fmt_ratio(base_rng[0][1])), flush=True)

    cs1, a = base_cs()
    # disjoint-triple menu box on a_1 == v_disj (value = a[0], since w_jd = DEN*a[0])
    cs1.insert(a[0] >= lo_box)
    cs1.insert(a[0] <= hi_box)
    poly1 = ppl.NNC_Polyhedron(cs1)
    empty = poly1.is_empty()
    print("with menu box on a_1: empty=%s  affine_dim=%d"
          % (empty, None if empty else poly1.affine_dimension()), flush=True)
    box_rng = None if empty else freedom_box(poly1, free_dim, "boxed")
    if not empty:
        for i in range(free_dim):
            b0, b1 = base_rng[i]; c0, c1 = box_rng[i]
            tightened = (b0 != c0) or (b1 != c1)
            print("  a_%d : [%s, %s] -> [%s, %s]%s"
                  % (i + 1, fmt_ratio(b0), fmt_ratio(b1), fmt_ratio(c0), fmt_ratio(c1),
                     "   (TIGHTENED)" if tightened else ""))

    # ---- reverse direction (V -> menu): positivity tightens abar ------------ #
    # a_1 = N_DISJ_PAIRS * abar, so positivity's a_1 range is an abar interval.
    from fractions import Fraction
    a1_lo_pos = base_rng[0][0]; a1_hi_pos = base_rng[0][1]   # positivity, no menu box
    abar_pos_hi = Fraction(a1_hi_pos[0], a1_hi_pos[1]) / N_DISJ_PAIRS
    abar_pos_lo = Fraction(a1_lo_pos[0], a1_lo_pos[1]) / N_DISJ_PAIRS
    abar_lo = max(Fraction(a_min), abar_pos_lo)
    abar_hi = min(Fraction(a_max), abar_pos_hi)
    print("\n  REVERSE FEEDBACK (V positivity -> menu mixture):")
    print("    menu alone:            %d <= abar <= %d" % (a_min, a_max))
    print("    + triweight positivity: %s <= abar <= %s  (~%.4f .. ~%.4f)"
          % (abar_lo, abar_hi, float(abar_lo), float(abar_hi)))
    if abar_hi < a_max:
        print("    => NEW aggregate inequality abar <= %s (~%.4f), tighter than the "
              "A3 menu cap a<=%d; feed to the sec 24.3 / 27.6 mixtures."
              % (abar_hi, float(abar_hi), a_max))

    # ---- intersect with odd-part congruence pin a_1 ≡ 0 (mod 8,744,715) ----- #
    print("\n" + "-" * 78)
    print("Congruence intersection (odd part, uniquely pinned mod 8,744,715)")
    print("-" * 78, flush=True)
    with gzip.open(os.path.join(HERE, "full_congruence_lattice.json.gz"), "rt") as fh:
        lat = json.load(fh)
    # Odd part is uniquely pinned (no odd kernel gens): a ≡ particular (mod p^E)
    # for each odd prime power. The a_1 (index-0) residue is 0 in every odd block,
    # so by CRT a_1 ≡ 0 (mod ODD_MODULUS); verify rather than assume.
    a1_mod = 0
    prod = 1
    for blk in lat["prime_power_solutions"]:
        if blk["p"] == 2:
            continue
        assert not blk["kernel_gens"], "odd block p=%d not uniquely pinned" % blk["p"]
        assert blk["particular"][0] % blk["modulus"] == 0, \
            "a_1 odd residue not 0 mod %d (=%d)" % (blk["modulus"], blk["particular"][0])
        prod *= blk["modulus"]
    assert prod == ODD_MODULUS, "odd modulus product %d != %d" % (prod, ODD_MODULUS)
    print("  odd congruence: a_1 ≡ %d (mod %d)" % (a1_mod, ODD_MODULUS))
    m_lo = -(-lo_box // ODD_MODULUS)            # ceil
    m_hi = hi_box // ODD_MODULUS                 # floor
    n_admissible = m_hi - m_lo + 1
    print("  a_1 = %d * m  with m in [%d, %d]  => %d admissible odd-lattice points in box"
          % (ODD_MODULUS, m_lo, m_hi, n_admissible))
    pinned = n_admissible <= 1
    print("  pinned by disjoint box + odd lattice alone? %s" % pinned)
    print("    (basket F_5 boxes from the 3-point SDP are needed to shrink further;"
          " sec 28.1 step 4 / 28.4 step 3)", flush=True)

    # ---- persist artifacts -------------------------------------------------- #
    out_basket = os.path.join(HERE, "basket_orbits.json")
    json.dump({
        "note": "Sec 28.1 basket: min-word-triple support orbits to be bounded by "
                "the per-orbit 3-point Terwilliger/Schrijver SDP on J(72,16). "
                "Each orbit's V coefficients give the linear form on (a_1..a_5) "
                "that an SDP upper bound on its count constrains.",
        "den": DEN, "free_dim": free_dim,
        "disjoint_triple": {"j": jd, "mu": list(col_reps[jd]),
                            "identity": "a_1 = 249849*5082*abar",
                            "menu_box": [lo_box, hi_box]},
        "n_disjoint_pairs": N_DISJ_PAIRS,
        "orbits": basket,
    }, open(out_basket, "w"), indent=1)

    verdict = {
        "section": "28.1",
        "menu_a_band": [a_min, a_max], "surviving_rows": n_rows,
        "abar_menu_band": [a_min, a_max],
        "abar_positivity_tightened": [str(abar_lo), str(abar_hi)],
        "abar_positivity_tightened_float": [float(abar_lo), float(abar_hi)],
        "disjoint_triple_orbit": jd,
        "identity": "a_1 = %d * abar" % N_DISJ_PAIRS,
        "menu_box_a1": [lo_box, hi_box],
        "lp_feasible_with_box": (not empty),
        "lp_affine_dim_with_box": (None if empty else int(poly1.affine_dimension())),
        "a1_baseline_range": [fmt_ratio(base_rng[0][0]), fmt_ratio(base_rng[0][1])],
        "a1_boxed_range": (None if empty else
                           [fmt_ratio(box_rng[0][0]), fmt_ratio(box_rng[0][1])]),
        "odd_modulus": ODD_MODULUS, "a1_odd_residue": a1_mod,
        "admissible_odd_lattice_points_in_box": int(n_admissible),
        "a1_pinned_by_box_and_lattice": bool(pinned),
        "basket_total": len(basket),
        "basket_f5_bearing": len(f5_orbits),
        "clean_single_freedom_orbits": {str(fi): [o["j"] for o in single[fi]]
                                        for fi in single},
        "gating_compute": "per-orbit 3-point Terwilliger/Schrijver SDP on J(72,16) "
                          "for the F_5-bearing basket orbits (sec 28.4 step 3)",
    }
    json.dump(verdict, open(os.path.join(HERE, "feedback_lp_verdict.json"), "w"), indent=1)
    print("\nsaved basket_orbits.json (%d orbits) and feedback_lp_verdict.json"
          % len(basket), flush=True)
    print("\nVERDICT: LP feasible with menu box; %d admissible a_1 odd-lattice points "
          "remain.\n  Disjoint box pins a_1 to a multiple of %d in [%d,%d]; the "
          "F_5-bearing\n  basket (needing the 3-point SDP) is the lever to pin "
          "further (sec 28.1)." % (n_admissible, ODD_MODULUS, lo_box, hi_box), flush=True)


if __name__ == "__main__":
    main()
