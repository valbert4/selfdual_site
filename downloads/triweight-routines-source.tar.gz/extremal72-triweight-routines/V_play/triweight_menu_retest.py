#!/usr/bin/env python
"""Re-run the section-24.3 global biweight/menu mixture with the triweight's extra
constraint  sum_j phi_j q_j = c  (cutting the anchored B_D family 5 -> 4), and see
whether any of the 48 surviving MENU.md rows' m_r >= 1 forcing probe flips from
feasible to INFEASIBLE.

Run with the Sage-enabled python:
    DOT_SAGE=/tmp/sage /home/vva/miniforge3/bin/python triweight_menu_retest.py --workers 20

Per-row forcing probes are exact continuous LPs (glpsol --exact): LP-infeasible =>
ILP-infeasible => rigorous cut.  Each row is probed twice (baseline vs +triweight);
a flip feasible->infeasible attributes the cut to the genus-3 constraint.  All
probes run in a worker pool.
"""
import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from functools import reduce
from math import gcd
from pathlib import Path

ROOT = Path("/home/vva/selfdual")
N56 = ROOT / "n56_biweight"
C1 = ROOT / "c1_search"
for p in (str(N56), str(C1)):
    if p not in sys.path:
        sys.path.insert(0, p)

from sage.all import QQ, lcm                                   # noqa: E402
from residual_3point_lp import build_split_affine_family       # noqa: E402
from biweight_global_mixture import parse_menu, load_minword_row  # noqa: E402
import biweight_global_mixture_glpsol as M                      # noqa: E402

HERE = Path("/home/vva/selfdual/triweight/V_play")


def _probe(rows, which, r, ml, nt):
    lp = Path(f"/tmp/twrt_{which}_{r}.lp")
    M.write_lp(lp, rows, ml, nt, integer=False, force_row=r)
    _, log = M.run_glpsol(lp, exact=True, time_limit=300)
    lp.unlink(missing_ok=True)
    st = M.status_from_log(log)
    return (r, which, "feasible" if st == "optimal" else st)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, default=20)
    args = ap.parse_args()

    tc = json.load(open(HERE / "triweight_q_constraint.json"))
    phi = [QQ(p[0]) / QQ(p[1]) for p in tc["phi"]]
    c = QQ(tc["c"][0]) / QQ(tc["c"][1])

    family = build_split_affine_family()
    menu = parse_menu()
    minrow = load_minword_row()
    base_rows = M.constraint_rows(family, menu, minrow)
    print("menu rows (current MENU.md 'Survives.'): %d ; tau: %d" % (len(menu), family.num_tau), flush=True)
    assert len(menu) == 48, "expected 48 surviving rows, got %d" % len(menu)

    co = {f"q{j}": phi[j] for j in range(8) if phi[j] != 0}
    den = 1
    for v in list(co.values()) + [c]:
        den = lcm(den, QQ(v).denominator())
    ico = {k: int(QQ(v) * den) for k, v in co.items() if QQ(v)}
    irhs = int(QQ(c) * den)
    gg = reduce(gcd, list(ico.values()) + [irhs])
    if gg > 1:
        ico = {k: v // gg for k, v in ico.items()}
        irhs //= gg
    print("triweight constraint (cuts B_D %d->%d): %s = %d"
          % (tc["rank_homo_BD"], tc["rank_F_BD"], " + ".join("%d %s" % (v, k) for k, v in ico.items()), irhs), flush=True)
    rows_tw = base_rows + [("triweight", ico, "=", irhs)]

    # global continuous sanity (should stay feasible)
    cont_lp = Path("/tmp/twrt_cont.lp")
    M.write_lp(cont_lp, rows_tw, len(menu), family.num_tau)
    _, log = M.run_glpsol(cont_lp, exact=True, time_limit=300)
    print("global continuous (with triweight constraint): %s" % M.status_from_log(log), flush=True)

    ml, nt = len(menu), family.num_tau
    jobs = ([(base_rows, "base", r) for r in range(ml)]
            + [(rows_tw, "tw", r) for r in range(ml)])
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(_probe, rows, w, r, ml, nt) for (rows, w, r) in jobs]
        results = [f.result() for f in futs]
    base = {r: s for (r, w, s) in results if w == "base"}
    tw = {r: s for (r, w, s) in results if w == "tw"}

    flips, base_infeas = [], []
    for r, (k, a, b) in enumerate(menu):
        if base[r] != "feasible":
            base_infeas.append((r, k, a, b, base[r]))
        if base[r] == "feasible" and tw[r] != "feasible":
            flips.append((k, a, b, tw[r]))
    print("\nbaseline: %d/%d feasible (control; expect all feasible)"
          % (sum(1 for r in base if base[r] == "feasible"), len(menu)), flush=True)
    if base_infeas:
        print("  baseline NOT feasible (unexpected):", base_infeas)
    print("with triweight constraint: %d/%d feasible" % (sum(1 for r in tw if tw[r] == "feasible"), len(menu)))
    print("\n=== %d menu rows CUT by the triweight constraint ===" % len(flips), flush=True)
    for k, a, b, st in flips:
        print("  (k=%d, a=%d, b=%d): feasible -> %s" % (k, a, b, st))
    if not flips:
        print("  (none -- the dimension cut saturates; next lever: a0 integrality residue)")
    json.dump({"menu_rows": len(menu),
               "rows_cut": [{"k": k, "a": a, "b": b} for k, a, b, _ in flips],
               "baseline_all_feasible": not base_infeas},
              open(HERE / "menu_retest_verdict.json", "w"), indent=1)


if __name__ == "__main__":
    main()
