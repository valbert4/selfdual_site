#!/usr/bin/env python
"""Re-run the section-24.3 global biweight/menu mixture, but instead of adding only
the single rank-4 cut  sum_j phi_j q_j = c  (which cuts the anchored B_D family 5->4),
PIN ALL EIGHT mixture params q_0..q_7 to the genus-3 triweight POINT's values
(8 equality rows q_j = q_j*).  This is the 0-dim pin -- strictly stronger than the
1-dim rank-4 cut -- and tests whether the continuous per-row split (tau) profiles
still absorb even a fully-determined n=56 residual biweight.

Three configurations are probed per menu row (m_r >= 1 forcing, exact glpsol --exact):
  * base : no extra q constraint            (control; expect all 48 feasible)
  * cut  : + single rank-4 cut phi.q = c    (control; current retest -> saturates, 0 cuts)
  * pin  : + all 8 equalities q_j = q_j*    (the 0-dim genus-3 pin -- the TEST)

LP-infeasible => ILP-infeasible => rigorous cut.  A flip feasible->infeasible under
'pin' (but not 'base') attributes the cut to the pinned genus-3 triweight.

Run with the Sage-enabled python on this machine:
    HOME=/tmp DOT_SAGE=/tmp/sage /usr/bin/sage -python triweight_menu_retest_pinned.py --workers 20
"""
import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from functools import reduce
from math import gcd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
N56 = ROOT / "n56_biweight"
C1 = ROOT / "c1_search"
for p in (str(N56), str(C1)):
    if p not in sys.path:
        sys.path.insert(0, p)

from sage.all import QQ, lcm                                   # noqa: E402
from residual_3point_lp import build_split_affine_family       # noqa: E402
from biweight_global_mixture import parse_menu, load_minword_row  # noqa: E402
import biweight_global_mixture_glpsol as M                      # noqa: E402

HERE = Path(__file__).resolve().parent


def _scale_eq(name, co, rhs):
    """Scale a rational constraint  co . x (= sense) rhs  to integer coeffs."""
    den = 1
    for v in list(co.values()) + [rhs]:
        den = lcm(den, QQ(v).denominator())
    ico = {k: int(QQ(v) * den) for k, v in co.items() if QQ(v)}
    irhs = int(QQ(rhs) * den)
    g = reduce(gcd, list(ico.values()) + [irhs]) if (ico or irhs) else 1
    if g > 1:
        ico = {k: v // g for k, v in ico.items()}
        irhs //= g
    return (name, ico, "=", irhs)


def _probe(rows, which, r, ml, nt):
    lp = Path(f"/tmp/twrtp_{which}_{r}.lp")
    M.write_lp(lp, rows, ml, nt, integer=False, force_row=r)
    _, log = M.run_glpsol(lp, exact=True, time_limit=300)
    lp.unlink(missing_ok=True)
    st = M.status_from_log(log)
    return (r, which, "feasible" if st == "optimal" else st)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, default=20)
    args = ap.parse_args()

    # ---- the single rank-4 cut (control), and the pinned point's q-vector (the test) ----
    tc = json.load(open(HERE / "triweight_q_constraint.json"))
    phi = [QQ(p[0]) / QQ(p[1]) for p in tc["phi"]]
    c = QQ(tc["c"][0]) / QQ(tc["c"][1])

    pin = json.load(open(HERE / "pinned_triweight.json"))
    qstar = [QQ(int(x)) for x in pin["q_vector"]]
    assert len(qstar) == 8, "expected 8 q-values, got %d" % len(qstar)
    # soundness: the pinned point must lie on the rank-4 cut hyperplane
    lhs = sum(phi[j] * qstar[j] for j in range(8))
    assert lhs == c, "pinned point violates rank-4 cut phi.q=c: %s != %s" % (lhs, c)

    family = build_split_affine_family()
    menu = parse_menu()
    minrow = load_minword_row()
    base_rows = M.constraint_rows(family, menu, minrow)
    print("menu rows (current MENU.md 'Survives.'): %d ; tau: %d"
          % (len(menu), family.num_tau), flush=True)
    # MENU.md is now 47 surviving rows (was 48 when the original retest was written).
    assert len(menu) in (47, 48), "expected 47/48 surviving rows, got %d" % len(menu)

    # Diagnostic: which q-indices actually couple into the menu LP (have nonzero
    # coefficient in any global_w_t constraint).  Pinning a q that appears nowhere
    # is vacuous for feasibility -- report this honestly.
    q_used = sorted({v for (_, co, _, _) in base_rows for v in co if v.startswith("q")})
    print("q-indices that COUPLE into the menu LP: %s" % q_used, flush=True)

    # ---- rank-4 cut row (control) ----
    co = {f"q{j}": phi[j] for j in range(8) if phi[j] != 0}
    cut_row = _scale_eq("triweight_cut", co, c)
    print("rank-4 cut (cuts B_D %d->%d): %s = %d"
          % (tc["rank_homo_BD"], tc["rank_F_BD"],
             " + ".join("%d %s" % (v, k) for k, v in cut_row[1].items()), cut_row[3]),
          flush=True)
    rows_cut = base_rows + [cut_row]

    # ---- full 8-q pin rows (the genus-3 0-dim point) ----
    pin_rows = []
    for j in range(8):
        pin_rows.append(_scale_eq(f"qpin_{j}", {f"q{j}": QQ(1)}, qstar[j]))
    print("full pin: 8 equalities  q_j = %s" % [str(v) for v in qstar], flush=True)
    rows_pin = base_rows + pin_rows

    # ---- global continuous sanity per configuration (should stay feasible) ----
    for tag, rws in (("base", base_rows), ("cut", rows_cut), ("pin", rows_pin)):
        cont_lp = Path(f"/tmp/twrtp_cont_{tag}.lp")
        M.write_lp(cont_lp, rws, len(menu), family.num_tau)
        _, log = M.run_glpsol(cont_lp, exact=True, time_limit=300)
        print("global continuous [%s]: %s" % (tag, M.status_from_log(log)), flush=True)
        cont_lp.unlink(missing_ok=True)

    ml, nt = len(menu), family.num_tau
    jobs = ([(base_rows, "base", r) for r in range(ml)]
            + [(rows_cut, "cut", r) for r in range(ml)]
            + [(rows_pin, "pin", r) for r in range(ml)])
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(_probe, rows, w, r, ml, nt) for (rows, w, r) in jobs]
        results = [f.result() for f in futs]
    base = {r: s for (r, w, s) in results if w == "base"}
    cut = {r: s for (r, w, s) in results if w == "cut"}
    pinr = {r: s for (r, w, s) in results if w == "pin"}

    base_infeas = []
    cut_flips = []
    pin_flips = []
    per_row = []
    for r, (k, a, b) in enumerate(menu):
        per_row.append({"index": r, "k": k, "a": a, "b": b,
                        "base": base[r], "cut": cut[r], "pin": pinr[r]})
        if base[r] != "feasible":
            base_infeas.append((r, k, a, b, base[r]))
        if base[r] == "feasible" and cut[r] != "feasible":
            cut_flips.append((k, a, b, cut[r]))
        if base[r] == "feasible" and pinr[r] != "feasible":
            pin_flips.append((k, a, b, pinr[r]))

    nb = sum(1 for r in base if base[r] == "feasible")
    nc = sum(1 for r in cut if cut[r] == "feasible")
    np_ = sum(1 for r in pinr if pinr[r] == "feasible")
    print("\nbaseline      : %d/%d feasible (control; expect all)" % (nb, len(menu)), flush=True)
    if base_infeas:
        print("  baseline NOT feasible (unexpected):", base_infeas)
    print("rank-4 cut    : %d/%d feasible  (control; expect saturate => 0 cuts)" % (nc, len(menu)))
    print("FULL 8-q pin  : %d/%d feasible" % (np_, len(menu)))

    print("\n=== rank-4-cut control: %d rows cut ===" % len(cut_flips), flush=True)
    for k, a, b, st in cut_flips:
        print("  (k=%d, a=%d, b=%d): feasible -> %s" % (k, a, b, st))
    print("\n=== FULL 8-q PIN: %d menu rows CUT ===" % len(pin_flips), flush=True)
    for k, a, b, st in pin_flips:
        print("  (k=%d, a=%d, b=%d): feasible -> %s" % (k, a, b, st))
    if not pin_flips:
        print("  (none -- the tau split slack absorbs even the 0-dim pin)")

    out = {
        "menu_rows": len(menu),
        "tau": family.num_tau,
        "q_indices_coupling_into_menu_LP": q_used,
        "q_point": [str(v) for v in qstar],
        "phi_q_equals_c": True,
        "baseline_all_feasible": not base_infeas,
        "baseline_feasible_count": nb,
        "cut_feasible_count": nc,
        "pin_feasible_count": np_,
        "rank4_cut_saturates": (len(cut_flips) == 0),
        "rows_cut_by_rank4_cut": [{"k": k, "a": a, "b": b, "status": st} for k, a, b, st in cut_flips],
        "rows_cut_by_full_pin": [{"k": k, "a": a, "b": b, "status": st} for k, a, b, st in pin_flips],
        "per_row": per_row,
    }
    json.dump(out, open(HERE / "menu_retest_pinned_verdict.json", "w"), indent=1)
    print("\nwrote", HERE / "menu_retest_pinned_verdict.json", flush=True)


if __name__ == "__main__":
    main()
