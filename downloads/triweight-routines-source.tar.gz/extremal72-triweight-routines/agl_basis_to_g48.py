#!/usr/bin/env python3
"""Convert an AGL(3,2) self-equation nullbasis (matrices/agl_n{n}_p{p}.nullbasis.json.gz,
col_reps = AGL orbit reps, nullbasis = D_3(n) vectors) into the order-48 basis
json format that span72_eval_rank/marginal_shortcircuit understand
(matrices/n{n}_basis_p{p}.json.gz with GROUP48 orbit_reps).

Each AGL orbit splits into GROUP48 sub-orbits; an AGL-invariant polynomial is
constant across the whole AGL orbit, so every GROUP48 sub-orbit rep inherits the
same coefficient.  No coefficient collisions (distinct AGL orbits are disjoint).
"""
import argparse
import gzip
import json

import numpy as np

import triweight_orbits as TO            # GROUP48 canon (canon_array)
import bench_agl_parallel as B           # AGL_PERMS (1344, 8)

POW = (128 ** np.arange(8)).astype(np.int64)


def convert(n, p, out_dir="matrices"):
    src = "%s/agl_n%d_p%d.nullbasis.json.gz" % (out_dir, n, p)
    with gzip.open(src, "rt") as fh:
        d = json.load(fh)
    col_reps = [tuple(int(x) for x in r) for r in d["col_reps"]]
    nullbasis = d["nullbasis"]
    assert len(nullbasis) == d["nullity"], (len(nullbasis), d["nullity"])

    # for each AGL column, the set of GROUP48 sub-orbit canonical reps
    col_g48 = []
    g48_index = {}
    for rep in col_reps:
        e = np.array(rep, dtype=np.int64)
        imgs = e[B.AGL_PERMS]                       # (1344, 8) all AGL images
        canon = TO.canon_array(imgs)               # GROUP48-canonical of each
        keys = (canon.astype(np.int64) * POW[None, :]).sum(axis=1)
        ukeys = np.unique(keys)
        subreps = []
        for kk in ukeys.tolist():
            r = tuple(int((kk // int(POW[i])) % 128) for i in range(8))
            subreps.append(r)
            if r not in g48_index:
                g48_index[r] = len(g48_index)
        col_g48.append(subreps)

    reps_list = [None] * len(g48_index)
    for r, i in g48_index.items():
        reps_list[i] = list(r)

    new_basis = []
    for vec in nullbasis:
        nv = [0] * len(g48_index)
        for j, v in enumerate(vec):
            v %= p
            if not v:
                continue
            for r in col_g48[j]:
                nv[g48_index[r]] = v
        new_basis.append(nv)

    payload = {
        "format": "agl_to_g48_v1",
        "n": int(n),
        "p": int(p),
        "orbit_reps": reps_list,
        "basis": new_basis,
        "nullity": len(new_basis),
        "agl_cols": len(col_reps),
    }
    out = "%s/n%d_basis_p%d.json.gz" % (out_dir, n, p)
    with gzip.open(out, "wt") as fh:
        json.dump(payload, fh, separators=(",", ":"))
    print("wrote %s : g48_orbits=%d  basis=%d  (from %d AGL cols)" %
          (out, len(g48_index), len(new_basis), len(col_reps)), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("n", type=int)
    ap.add_argument("--primes", default="13,17")
    ap.add_argument("--out-dir", default="matrices")
    args = ap.parse_args()
    for p in [int(x) for x in args.primes.split(",") if x.strip()]:
        convert(args.n, p, args.out_dir)


if __name__ == "__main__":
    main()
