#!/usr/bin/env sage
"""
Validate + benchmark the AGL(3,2)/GL(3,2) reduction of the genus-3 self-equation
nullspace vs. the proven order-48 build in selfeq_nullspace.sage.  numpy-
vectorized canonicalization (the pure-Python 1344-perm canon is far too slow).

  COLUMNS: AGL(3,2)-orbits (1344) instead of order-48.  ONE A* eval per AGL
           orbit (A*(P(M)f)=P(M^-T)A*(f), so a single A*(rep) spread over the
           168 GL perms reconstructs A*(orbit-sum)).
  ROWS:    GL(3,2)-orbits (168).  A*(AGL-orbit-sum) is GL(3,2)-invariant -> rows
           in a GL-orbit are identical (lossless).  Support-only rows (the
           validated Priority-4 restriction; support is GL-invariant).
Both keep the EXACT equation, so nullity stays D_3(n).

Run:  sage bench_agl.sage 8 16 24 32
"""
import os, sys, time, subprocess, tempfile
import numpy as np
from itertools import permutations, product as iproduct

os.environ['SELFEQ_NOMAIN'] = '1'
load('selfeq_nullspace.sage')          # support, canon, GROUP, orbit_column, FH, D3

def load_support(n):
    """Genus-3 support 8-tuples via the C++ enumerate_support (fast); falls back
    to the pure-Python support() if the binary is absent."""
    exe = './support_transform'
    if os.path.exists(exe):
        fd, path = tempfile.mkstemp(suffix='.txt'); os.close(fd)
        try:
            subprocess.run([exe, 'dump-support', str(int(n)), path],
                           check=True, stderr=subprocess.DEVNULL)
            rows = []
            with open(path) as fh:
                for line in fh:
                    if line.strip():
                        rows.append(tuple(int(x) for x in line.split()))
            return rows
        finally:
            try: os.remove(path)
            except OSError: pass
    return support(n)

POW = (np.int64(73) ** np.arange(8)).astype(np.int64)   # monomial-key base (entries<=72<73)

def _vec(p):  return ((p >> 0) & 1, (p >> 1) & 1, (p >> 2) & 1)
def _idx(v):  return (v[0] & 1) + 2 * (v[1] & 1) + 4 * (v[2] & 1)
def _matvec(M, v): return tuple(sum(M[i][j]*v[j] for j in range(3)) % 2 for i in range(3))
def _det3_f2(M):
    A = [row[:] for row in M]
    for c in range(3):
        piv = next((r for r in range(c, 3) if A[r][c] & 1), None)
        if piv is None: return 0
        A[c], A[piv] = A[piv], A[c]
        for r in range(3):
            if r != c and (A[r][c] & 1):
                A[r] = [(A[r][j]+A[c][j]) % 2 for j in range(3)]
    return 1

GL3 = [[list(b[0:3]), list(b[3:6]), list(b[6:9])]
       for b in iproduct([0,1], repeat=9) if _det3_f2([list(b[0:3]),list(b[3:6]),list(b[6:9])])]
GL_PERMS = np.array([[_idx(_matvec(M,_vec(p))) for p in range(8)] for M in GL3], dtype=np.int64)
AGL_PERMS = np.array(sorted({tuple(_idx(tuple((_matvec(M,_vec(p))[i]+f[i])%2 for i in range(3)))
                                   for p in range(8))
                             for M in GL3 for f in iproduct([0,1],repeat=3)}), dtype=np.int64)
assert GL_PERMS.shape == (168,8) and AGL_PERMS.shape == (1344,8)
GROUP48 = np.array([list(g) for g in GROUP], dtype=np.int64)   # from loaded module (48)

def canon_keys(arr, perms):
    best = None
    for perm in perms:
        k = (arr[:, perm] * POW).sum(1)
        best = k if best is None else np.minimum(best, k)
    return best

def orbit_size_and_canon(arr, perms):
    """Per row: (#distinct images, canonical key). Chunked; vectorized distinct."""
    N = arr.shape[0]
    can = np.empty(N, dtype=np.int64); osz = np.empty(N, dtype=np.int64)
    CH = 20000
    for s in range(0, N, CH):
        a = arr[s:s+CH]
        keys = np.stack([(a[:, perm]*POW).sum(1) for perm in perms], axis=1)  # (c,G)
        can[s:s+CH] = keys.min(1)
        ks = np.sort(keys, axis=1)
        osz[s:s+CH] = 1 + (np.diff(ks, axis=1) != 0).sum(1)                   # distinct per row
    return osz, can

# ---------------------------------------------------------------------------
def nullity_orig(n, p, supp_arr):
    """Proven order-48 build (orbit_column), numpy grouping, FULL rows."""
    t0 = time.time()
    a48 = canon_keys(supp_arr, GROUP48)
    orbits = {}
    for i, kk in enumerate(a48.tolist()):
        orbits.setdefault(kk, []).append(i)
    ncol = len(orbits)
    row_id = {}; entries = {}
    for o, (_, idxs) in enumerate(orbits.items()):
        members = [tuple(int(x) for x in supp_arr[i]) for i in idxs]
        rep = canon(members[0])
        col = orbit_column(rep, members, n, p)
        for mu, v in col.items():
            if v % p == 0: continue
            r = row_id.setdefault(mu, len(row_id))
            entries[(r, o)] = v % p
    M = matrix(GF(p), len(row_id), ncol, entries, sparse=True)
    return ncol - M.rank(), ncol, len(row_id), len(entries), time.time()-t0

def nullity_agl(n, p, supp_arr):
    """AGL columns (one A* eval each) + GL-collapsed support-only rows."""
    t0 = time.time()
    pp = int(p)
    scale = pow(2, 3*n//2, pp); inv1344 = pow(1344, pp-2, pp); eight = 8 % pp
    # precompute GL-canon + GL-orbit-size for every support monomial
    gosz, gcan = orbit_size_and_canon(supp_arr, GL_PERMS)
    skeys = (supp_arr * POW).sum(1)
    key2gl = dict(zip(skeys.tolist(), gcan.tolist()))     # support monomial key -> GL-canon key
    key2osz = dict(zip(gcan.tolist(), gosz.tolist()))     # GL-canon key -> GL-orbit size
    row_id = {}                                           # GL-canon key -> row index
    # AGL orbits (columns)
    acan = canon_keys(supp_arr, AGL_PERMS)
    orbits = {}
    for i, kk in enumerate(acan.tolist()):
        orbits.setdefault(kk, []).append(i)
    ncol = len(orbits); entries = {}
    for o, (_, idxs) in enumerate(orbits.items()):
        rep = tuple(int(x) for x in supp_arr[idxs[0]])
        rep = canon(rep) if False else rep                # any orbit member works as rep
        base = FH.apply_A_star_translation_even({rep: 1}, mod=pp)    # one A* eval
        factor = (len(idxs) * inv1344) % pp
        gl_sum = {}
        for mu, v in base.items():
            mk = sum(int(mu[j]) * int(POW[j]) for j in range(8))
            c = key2gl.get(mk)
            if c is None:                                 # off-support row: drop (support-only)
                continue
            gl_sum[c] = (gl_sum.get(c, 0) + v) % pp
        col = {}
        for c, s in gl_sum.items():
            osz = key2osz[c]
            val = factor * eight % pp * ((168 // osz) % pp) % pp * (s % pp) % pp
            if val: col[c] = (col.get(c, 0) + val) % pp
        seen = set()
        for i in idxs:                                    # RHS: -scale once per GL-row
            c = key2gl[int(skeys[i])]
            if c in seen: continue
            seen.add(c); col[c] = (col.get(c, 0) - scale) % pp
        for c, v in col.items():
            if v % pp == 0: continue
            r = row_id.setdefault(c, len(row_id))
            entries[(r, o)] = v % pp
    M = matrix(GF(p), len(row_id), ncol, entries, sparse=True)
    return ncol - M.rank(), ncol, len(row_id), len(entries), time.time()-t0

# ---------------------------------------------------------------------------
ns = [int(a) for a in sys.argv[1:] if a.isdigit()] or [8, 16, 24, 32]
p = int(os.environ.get("P", "13"))
ORIG_MAX = int(os.environ.get("ORIG_MAX", "16"))   # run slow pure-Python baseline only up to this n
log = open("bench_agl_results.txt", "w")
def out(s):
    print(s, flush=True); log.write(s+"\n"); log.flush()
out("prime p=%d   GL3=%d AGL=%d   (orig baseline run for n<=%d)" % (p, len(GL3), len(AGL_PERMS), ORIG_MAX))
out("%-4s %8s %7s %7s %7s | %-22s | %-22s | %s"
    % ("n","|supp|","col48","colAGL","rowGL","ORDER-48 build (full)","AGL/GL build","check"))
rows = []
for n in ns:
    supp = load_support(n); supp_arr = np.array(supp, dtype=np.int64); nsupp = len(supp)
    col48 = len(set(canon_keys(supp_arr, GROUP48).tolist()))
    colAGL = len(set(canon_keys(supp_arr, AGL_PERMS).tolist()))
    rowGL = len(set(canon_keys(supp_arr, GL_PERMS).tolist()))
    na, ca, ra, nza, ta = nullity_agl(n, p, supp_arr)
    exp = D3.get(n, '?'); okA = (na == exp)
    if n <= ORIG_MAX:
        no, co, ro, nzo, to = nullity_orig(n, p, supp_arr)
        origs = "%5dx%-7d %6.1fs" % (co, ro, to)
        okO = (no == exp); spd = "%.1fx" % (to/ta if ta>0 else 0)
    else:
        origs = "(skipped: ~%dx%d)" % (col48, nsupp); okO = True; spd = "n/a"
    out("%-4d %8d %7d %7d %7d | %-22s | %5dx%-7d %6.1fs | %s nul=%s spd=%s"
        % (n, nsupp, col48, colAGL, rowGL, origs, ca, ra, ta,
           ("OK" if (okA and okO) else "MISMATCH(na=%s exp=%s)" % (na, exp)), na, spd))
    rows.append((n, nsupp, col48, colAGL, rowGL, ta))
out("\ndimension reduction (independent of implementation; drives memory/rank cost):")
for (n, nsupp, col48, colAGL, rowGL, ta) in rows:
    out("  n=%-3d cols %6d->%-5d (%4.1fx)  rows %7d->%-6d (%5.1fx)  cells %.2e->%.2e (%5.0fx)"
        % (n, col48, colAGL, col48/colAGL, nsupp, rowGL, nsupp/rowGL,
           float(col48)*nsupp, float(colAGL)*rowGL, (float(col48)*nsupp)/(float(colAGL)*rowGL)))
log.close()
