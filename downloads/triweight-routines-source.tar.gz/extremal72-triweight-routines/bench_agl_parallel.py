#!/usr/bin/env python3
"""Parallel AGL(3,2)/GL(3,2) self-equation nullity (pure Python, multiprocessing).

Replicates nullity_agl() from bench_agl.sage exactly, but distributes the
per-AGL-orbit A* evaluation (the bottleneck) across W workers.  Rank over GF(p)
is done with a numpy column-outer Gauss-Jordan (the matrix is tiny:
colAGL x rowGL, e.g. 364 x 1700 at n=40).

Usage:
  /usr/bin/python3 bench_agl_parallel.py <n> [--p 13] [--workers 16] [--out corr/...]
Validate first:  bench_agl_parallel.py 8 ; 16 ; 24 ; 32   (nullity 1,2,5,9)
"""
import argparse
import gzip
import json
import os
import subprocess
import sys
import tempfile
import time
from itertools import product as iproduct
from multiprocessing import Pool

import numpy as np

import factored_hadamard as FH

D3 = {8: 1, 16: 2, 24: 5, 32: 9, 40: 16, 48: 31, 56: 53, 64: 89, 72: 152}
POW = (np.int64(73) ** np.arange(8)).astype(np.int64)   # entries <= 72 < 73


def _tup73(k):
    return tuple(int((k // int(POW[i])) % 73) for i in range(8))


# ---- group construction (identical to bench_agl.sage) ----
def _vec(p):  return ((p >> 0) & 1, (p >> 1) & 1, (p >> 2) & 1)
def _idx(v):  return (v[0] & 1) + 2 * (v[1] & 1) + 4 * (v[2] & 1)
def _matvec(M, v): return tuple(sum(M[i][j] * v[j] for j in range(3)) % 2 for i in range(3))


def _det3_f2(M):
    A = [row[:] for row in M]
    for c in range(3):
        piv = next((r for r in range(c, 3) if A[r][c] & 1), None)
        if piv is None:
            return 0
        A[c], A[piv] = A[piv], A[c]
        for r in range(3):
            if r != c and (A[r][c] & 1):
                A[r] = [(A[r][j] + A[c][j]) % 2 for j in range(3)]
    return 1


GL3 = [[list(b[0:3]), list(b[3:6]), list(b[6:9])]
       for b in iproduct([0, 1], repeat=9)
       if _det3_f2([list(b[0:3]), list(b[3:6]), list(b[6:9])])]
GL_PERMS = np.array([[_idx(_matvec(M, _vec(p))) for p in range(8)] for M in GL3], dtype=np.int64)
AGL_PERMS = np.array(sorted({tuple(_idx(tuple((_matvec(M, _vec(p))[i] + f[i]) % 2 for i in range(3))
                                          ) for p in range(8))
                             for M in GL3 for f in iproduct([0, 1], repeat=3)}), dtype=np.int64)
assert GL_PERMS.shape == (168, 8) and AGL_PERMS.shape == (1344, 8)


def load_support(n):
    exe = './support_transform'
    if os.path.exists(exe):
        fd, path = tempfile.mkstemp(suffix='.txt'); os.close(fd)
        try:
            subprocess.run([exe, 'dump-support', str(int(n)), path],
                           check=True, stderr=subprocess.DEVNULL)
            rows = []
            with open(path) as fh:
                for line in fh:
                    if line.strip():
                        rows.append(tuple(int(x) for x in line.split()))
            return rows
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
    raise RuntimeError("support_transform binary missing; build it first")


def canon_keys(arr, perms):
    best = None
    for perm in perms:
        k = (arr[:, perm] * POW).sum(1)
        best = k if best is None else np.minimum(best, k)
    return best


def orbit_size_and_canon(arr, perms):
    N = arr.shape[0]
    can = np.empty(N, dtype=np.int64); osz = np.empty(N, dtype=np.int64)
    CH = 20000
    for s in range(0, N, CH):
        a = arr[s:s + CH]
        keys = np.stack([(a[:, perm] * POW).sum(1) for perm in perms], axis=1)
        can[s:s + CH] = keys.min(1)
        ks = np.sort(keys, axis=1)
        osz[s:s + CH] = 1 + (np.diff(ks, axis=1) != 0).sum(1)
    return osz, can


def orbit_cost(e):
    """Cheap proxy for the factored-Hadamard A* cost of monomial x^e (and its
    peak memory), WITHOUT running A*: product over the 3 single-bit axes of the
    per-pair expansion sizes (x_lo^a x_hi^b -> (a+b+1) terms).  Balanced reps
    like (6,6,6,6,6,6,6,6) score astronomically higher than concentrated ones
    like (48,0,...).  Used only to order tasks heaviest-first (LPT)."""
    cost = 1
    for axis in range(3):
        bit = 1 << axis
        prod = 1
        for lo in range(8):
            if not (lo & bit):
                prod *= (int(e[lo]) + int(e[lo | bit]) + 1)
        cost *= prod
    return cost


def _col_path(col_dir, aglkey):
    return os.path.join(col_dir, "col_%d.tsv" % aglkey)


def _write_col_atomic(col_dir, aglkey, entries):
    """entries: list of (glkey, val).  Atomic write so a crash never leaves a
    partial .tsv (salvageable per-column checkpoint)."""
    final = _col_path(col_dir, aglkey)
    tmp = os.path.join(col_dir, ".col_%d.tmp" % aglkey)
    with open(tmp, "w") as fh:
        for glk, v in entries:
            fh.write("%d\t%d\n" % (glk, v))
    os.replace(tmp, final)


def _read_col(col_dir, aglkey):
    out = []
    with open(_col_path(col_dir, aglkey)) as fh:
        for line in fh:
            if line.strip():
                a, b = line.split()
                out.append((int(a), int(b)))
    return out


# ---- worker globals (set once per worker via initializer; read-only) ----
_W = {}


def _init(supp_arr, key2gl, key2osz, skeys, pp, scale, inv1344, eight, col_dir):
    _W.update(supp=supp_arr, key2gl=key2gl, key2osz=key2osz, skeys=skeys,
              pp=pp, scale=scale, inv1344=inv1344, eight=eight, col_dir=col_dir)


def _compute_col(members):
    """Compute one AGL-orbit column: list of (glkey, val)."""
    pp = _W['pp']; key2gl = _W['key2gl']; key2osz = _W['key2osz']
    skeys = _W['skeys']; supp = _W['supp']
    inv1344 = _W['inv1344']; eight = _W['eight']; scale = _W['scale']
    rep = tuple(int(x) for x in supp[members[0]])
    base = FH.apply_A_star_translation_even({rep: 1}, mod=pp)      # the one A* eval
    factor = (len(members) * inv1344) % pp
    gl_sum = {}
    for mu, v in base.items():
        mk = sum(int(mu[j]) * int(POW[j]) for j in range(8))
        c = key2gl.get(mk)
        if c is None:                                             # off-support row: drop
            continue
        gl_sum[c] = (gl_sum.get(c, 0) + v) % pp
    col = {}
    for c, s in gl_sum.items():
        osz = key2osz[c]
        val = factor * eight % pp * ((168 // osz) % pp) % pp * (s % pp) % pp
        if val:
            col[c] = (col.get(c, 0) + val) % pp
    seen = set()
    for i in members:                                            # RHS: -scale once per GL-row
        c = key2gl[int(skeys[i])]
        if c in seen:
            continue
        seen.add(c); col[c] = (col.get(c, 0) - scale) % pp
    return [(c, v % pp) for c, v in col.items() if v % pp]


def _col_for_orbit(task):
    """task = (col_index, aglkey, members).  Computes the column, checkpoints it
    to col_dir (atomic) if set, and returns (col_index, entries, elapsed, nnz)."""
    o, aglkey, members = task
    t0 = time.time()
    entries = _compute_col(members)
    if _W['col_dir']:
        _write_col_atomic(_W['col_dir'], aglkey, entries)
    return (o, entries, time.time() - t0, len(entries))


def _rref(A, p):
    """Reduced row-echelon form over GF(p). Returns (rank, pivot_cols, R)."""
    M = (A % p).astype(np.int64)
    nr, nc = M.shape
    row = 0
    pivots = []
    for col in range(nc):
        sub = M[row:, col] % p
        nz = np.nonzero(sub)[0]
        if nz.size == 0:
            continue
        piv = row + int(nz[0])
        if piv != row:
            M[[row, piv]] = M[[piv, row]]
        inv = pow(int(M[row, col]), p - 2, p)
        M[row] = (M[row] * inv) % p
        factor = M[:, col].copy(); factor[row] = 0
        if factor.any():
            M = (M - np.outer(factor, M[row])) % p
        pivots.append(col)
        row += 1
        if row == nr:
            break
    return row, pivots, M


def gfp_rank_fast(A, p):
    if A.shape[0] == 0 or A.shape[1] == 0:
        return 0
    return _rref(A, p)[0]


def gfp_nullspace(A, p):
    """Basis of the right null space {x : A x = 0} over GF(p), as a list of
    length-ncols vectors.  ncols - rank vectors."""
    nr, nc = A.shape
    rank, pivots, R = _rref(A, p)
    pivset = set(pivots)
    free = [c for c in range(nc) if c not in pivset]
    basis = []
    for f in free:
        x = np.zeros(nc, dtype=np.int64)
        x[f] = 1
        for i, pc in enumerate(pivots):
            x[pc] = (-int(R[i, f])) % p
        basis.append(x)
    return basis


def run(n, p, workers, out_path=None, save_dir=None, col_dir=None, progress_every=25):
    t0 = time.time()
    supp = load_support(n)
    supp_arr = np.array(supp, dtype=np.int64)
    nsupp = len(supp)
    pp = int(p)
    scale = pow(2, 3 * n // 2, pp)
    inv1344 = pow(1344, pp - 2, pp)
    eight = 8 % pp

    gosz, gcan = orbit_size_and_canon(supp_arr, GL_PERMS)
    skeys = (supp_arr * POW).sum(1)
    key2gl = dict(zip(skeys.tolist(), gcan.tolist()))
    key2osz = dict(zip(gcan.tolist(), gosz.tolist()))

    colAGL = len(set(canon_keys(supp_arr, AGL_PERMS).tolist()))
    rowGL = len(set(canon_keys(supp_arr, GL_PERMS).tolist()))

    acan = canon_keys(supp_arr, AGL_PERMS)
    orbits = {}
    for i, kk in enumerate(acan.tolist()):
        orbits.setdefault(kk, []).append(i)
    # deterministic column order = sorted by AGL canon key (independent of the
    # dispatch order, so col_<aglkey>.tsv files are stable across restarts)
    orbit_items = sorted(orbits.items())                  # [(aglkey, members), ...]
    ncol = len(orbit_items)
    col_reps = [tuple(int(x) for x in supp_arr[m[0]]) for _, m in orbit_items]

    if col_dir:
        os.makedirs(col_dir, exist_ok=True)

    # which columns are already checkpointed (salvage / resume)?
    done = {}
    tasks = []
    for o, (aglkey, members) in enumerate(orbit_items):
        if col_dir and os.path.exists(_col_path(col_dir, aglkey)):
            done[o] = aglkey
        else:
            tasks.append((o, aglkey, members))
    # heaviest-first (LPT): keeps all cores busy to the end; worker count is sized
    # so workers x peak-orbit-RSS <= RAM budget, so this does NOT blow up memory.
    tasks.sort(key=lambda t: orbit_cost(col_reps[t[0]]), reverse=True)
    t_setup = time.time() - t0
    print("[n=%d p=%d] columns=%d  already done=%d  to compute=%d  workers=%d  [setup %.1fs]"
          % (n, pp, ncol, len(done), len(tasks), workers, t_setup), flush=True)

    computed = {}                                         # col_index -> entries
    if tasks:
        with Pool(workers, initializer=_init,
                  initargs=(supp_arr, key2gl, key2osz, skeys, pp, scale, inv1344, eight, col_dir)) as pool:
            n_done = 0
            slowest = (0.0, -1)
            for (o, entries_o, dt, nnz) in pool.imap_unordered(_col_for_orbit, tasks, chunksize=1):
                computed[o] = entries_o
                n_done += 1
                if dt > slowest[0]:
                    slowest = (dt, o)
                if progress_every and (n_done % progress_every == 0 or n_done == len(tasks)):
                    print("[n=%d p=%d]  %d/%d cols  (last nnz=%d, slowest %.0fs)  [%.0fs]"
                          % (n, pp, n_done, len(tasks), nnz, slowest[0], time.time() - t0), flush=True)
    t_build = time.time() - t0

    # ---- assemble matrix from computed columns + checkpoint files (salvage) ----
    row_id = {}
    entries = []
    for o, (aglkey, members) in enumerate(orbit_items):
        col = computed.get(o)
        if col is None:
            col = _read_col(col_dir, aglkey)              # resumed-from-checkpoint column
        for c, v in col:
            r = row_id.setdefault(c, len(row_id))
            entries.append((r, o, v % pp))
    A = np.zeros((len(row_id), ncol), dtype=np.int64)
    for r, o, v in entries:
        A[r, o] = v
    rank, _, _ = _rref(A, pp)
    nullity = ncol - rank
    nullbasis = gfp_nullspace(A, pp)
    t_total = time.time() - t0

    # col_reps already computed above (from sorted orbit_items); row reps:
    inv_row = {r: k for k, r in row_id.items()}     # row index -> GL-canon key
    row_reps = [_tup73(inv_row[r]) for r in range(len(row_id))]

    exp = D3.get(n, '?')
    status = "OK" if nullity == exp else "MISMATCH(exp=%s)" % exp
    line = ("n=%d p=%d  |supp|=%d  colAGL=%d  rowGL=%d  rank=%d  nullity=%d  (expect %s)  %s  "
            "[setup %.1fs build %.1fs total %.1fs, %d workers]"
            % (n, pp, nsupp, colAGL, rowGL, rank, nullity, exp, status,
               t_setup, t_build, t_total, workers))
    print(line, flush=True)

    # ---- self-check: every null vector annihilates the matrix ----
    # Reduce each product mod p BEFORE summing -- the dense A.dot(Nv) overflows
    # int64 at large p (sums ncol products of size ~p^2).  Per-row sum of reduced
    # terms stays < ncol*p < 2^63 for p < 3e9.
    if nullbasis:
        for v in np.array(nullbasis, dtype=np.int64):         # each (ncol,)
            chk = ((A * v) % pp).sum(axis=1) % pp
            assert not chk.any(), "null basis does not annihilate matrix!"

    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
        base = os.path.join(save_dir, "agl_n%d_p%d" % (n, pp))
        with open(base + ".tsv", "w") as fh:
            for (r, o, v) in sorted(entries):
                fh.write("%d\t%d\t%d\n" % (r, o, v))
        meta = {"format": "triweight genus-3 self-equation matrix (AGL cols / GL rows; sparse triplets row col val in .tsv)",
                "n": int(n), "p": int(pp), "method": "agl",
                "nrows": len(row_id), "ncols": ncol, "nnz": len(entries),
                "nullity": int(nullity), "D3_expected": (int(exp) if exp != '?' else None),
                "colAGL": colAGL, "rowGL": rowGL,
                "col_reps": [[int(x) for x in t] for t in col_reps],
                "row_reps": [[int(x) for x in t] for t in row_reps]}
        with gzip.open(base + ".meta.json.gz", "wt") as fh:
            json.dump(meta, fh, separators=(",", ":"))
        nb = {"n": int(n), "p": int(pp), "method": "agl", "group": "AGL(3,2)/1344",
              "ncols": ncol, "nullity": int(nullity),
              "note": "invariant_i = sum_o nullbasis[i][o] * (AGL(3,2)-orbit-sum of col_reps[o])",
              "col_reps": [[int(x) for x in t] for t in col_reps],
              "nullbasis": [[int(x % pp) for x in vec] for vec in nullbasis]}
        with gzip.open(base + ".nullbasis.json.gz", "wt") as fh:
            json.dump(nb, fh, separators=(",", ":"))
        print("saved -> %s.{tsv,meta.json.gz,nullbasis.json.gz}" % base, flush=True)

    if out_path:
        with open(out_path, "w") as fh:
            fh.write(line + "\n")
            fh.write("colAGL=%d rowGL=%d nnz=%d nullity=%d\n" % (colAGL, rowGL, len(entries), nullity))
        print("saved -> %s" % out_path, flush=True)
    return nullity, colAGL, rowGL


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("n", type=int)
    ap.add_argument("--p", type=int, default=13)
    ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--out", default=None)
    ap.add_argument("--save-dir", default="matrices",
                    help="folder to save matrix .tsv + .meta + .nullbasis (default: matrices/)")
    ap.add_argument("--col-dir", default=None,
                    help="per-column checkpoint dir; each col_<aglkey>.tsv is written "
                         "atomically as it completes, so a crash/preemption is salvageable "
                         "and a re-run resumes the missing columns only")
    ap.add_argument("--progress-every", type=int, default=25)
    args = ap.parse_args()
    run(args.n, args.p, args.workers, args.out, save_dir=args.save_dir,
        col_dir=args.col_dir, progress_every=args.progress_every)


if __name__ == "__main__":
    main()
