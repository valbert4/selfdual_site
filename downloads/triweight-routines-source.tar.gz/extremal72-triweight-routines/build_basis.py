#!/usr/bin/env python3
"""
Assemble a spanning set for the degree-72 genus-3 invariant ring from the genus-3
enumerators of explicit Type II "generator" codes and their direct-sum products
(SCOPE.md A1), and report the rank degree-by-degree against the Hilbert table

    D_3(n) = 1, 2, 5, 9, 16, 31, 53, 89, 152   for n = 8, 16, ..., 72.

A genus-3 enumerator of a length-n code is homogeneous of degree n; direct sum of
codes multiplies enumerators (enum_product), so products of generators whose
lengths sum to n span (a subspace of) the degree-n graded piece.  We build, by
dynamic programming over degree, all products of the available atoms with total
length n, and rank them in the order-48 orbit coordinates of triweight_orbits.py.

ATOMS currently available locally (no length-72 brute force needed):
  - d_n^+ for n = 8,16,24,...  via the Fujii-Oura closed form (dnplus.py);
  - the Golay [24,12,8] enumerator (golay_genus3.json).

The d_n^+ subring alone caps at dim <= p(9)=30 at degree 72 (SCOPE 2.2); Golay
adds the first non-d_n^+ direction.  Whatever rank this set reaches, the
degree-by-degree shortfall vs the Hilbert table names exactly how many more
generators (and at what length) are still needed -- those are the codes to supply
from the literature (the 9 Type II [24,12] codes, neighbors of d_n^+, etc.).

Usage:
  python3 build_basis.py            # atoms up to whatever DMAX is feasible
  python3 build_basis.py 56         # cap d_n^+ atoms at length 56 (faster)
"""
import sys
import time

import numpy as np

import triweight_lib as L
import dnplus as D
import triweight_orbits as O

HILBERT = {8: 1, 16: 2, 24: 5, 32: 9, 40: 16, 48: 31, 56: 53, 64: 89, 72: 152}
P = 1000003           # rank prime (matches dim_check / selfeq_nullity)


import json
import os

CACHE = "dnplus_modp_cache"


def cached_dnplus_modp(n):
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, "d%d_p%d.json" % (n, P))
    if os.path.exists(path):
        return {tuple(k): v for k, v in json.load(open(path))}
    en = D.dnplus_genus3_modp(n, P)
    json.dump([[list(k), v] for k, v in en.items()], open(path, "w"))
    return en


def load_atoms(dmax):
    """{name: (length, enum_dict)} for every generator code we can build locally,
    with coefficients reduced mod P (rank is computed over GF(P), so the fast
    mod-P closed form dnplus_genus3_modp suffices and scales to n=72)."""
    atoms = {}
    for n in range(8, dmax + 1, 8):
        t = time.time()
        atoms["d%d+" % n] = (n, cached_dnplus_modp(n))
        print("  atom d_%d^+:  %d monomials  (%.1fs)" % (n, len(atoms["d%d+" % n][1]), time.time() - t), flush=True)
    # non-d_n^+ length-24 generators from cached JSON, reduced mod P
    for fname, label in [("golay_genus3.json", "golay24"),
                         ("c1_d12sq_genus3.json", "C1=d12^2")]:
        try:
            g = json.load(open(fname))
        except FileNotFoundError:
            continue
        atoms[label] = (g["n"], {tuple(k): v % P for k, v in g["enumerator"]})
        print("  atom %s: %d monomials (cached)" % (label, len(atoms[label][1])))
    return atoms


def products_to_degree(atoms, target):
    """All distinct products of atoms with total length == target, as enum dicts.
    DP over degree; dedup of identical product dicts only (rank handles the rest)."""
    # group atom lengths
    by_len = {}
    for name, (ln, en) in atoms.items():
        by_len.setdefault(ln, []).append((name, en))
    # dp[d] = list of (name_tuple, enum) products of total length d
    unit = ((), {(0,) * 8: 1})
    dp = {0: [unit]}
    for d in range(8, target + 1, 8):
        out = []
        seen = set()
        for ln, lst in by_len.items():
            if ln > d:
                continue
            for (aname, aen) in lst:
                for (names, pen) in dp.get(d - ln, []):
                    # enforce sorted multiset to avoid permutation duplicates
                    if names and aname > names[0]:
                        continue
                    new_names = (aname,) + names
                    if new_names in seen:
                        continue
                    seen.add(new_names)
                    prod = {k: v % P for k, v in L.enum_product(aen, pen).items()}
                    out.append((new_names, prod))
        dp[d] = out
    return dp


def orbit_columns(enums, index):
    """Stack a list of enumerator dicts into an integer (n_orbits, n_enums) matrix
    in orbit coordinates. Canonicalizes every monomial in one vectorized batch
    (works at any degree; the enumerators are all G-invariant so this is exact)."""
    # one global pool of distinct raw monomials across all enumerators
    pool = {}
    cols_raw = []
    for en in enums:
        col = {}
        for e, c in en.items():
            mi = pool.get(e)
            if mi is None:
                mi = pool[e] = len(pool)
            col[mi] = c % P
        cols_raw.append(col)
    mons = np.array(list(pool.keys()), dtype=np.int64)         # (Npool, 8)
    canon = O.canon_array(mons)                                # vectorized canon
    # map each canon rep to a row
    repset = {}
    row_of_mon = np.empty(mons.shape[0], dtype=np.int64)
    for mi in range(mons.shape[0]):
        r = tuple(int(x) for x in canon[mi])
        j = repset.get(r)
        if j is None:
            j = repset[r] = len(repset)
        row_of_mon[mi] = j
    A = np.zeros((len(repset), len(cols_raw)), dtype=np.int64)
    for jcol, col in enumerate(cols_raw):
        for mi, c in col.items():
            A[row_of_mon[mi], jcol] = (A[row_of_mon[mi], jcol] + c) % P
    return A


def rank_modp(A):
    from selfeq_nullity import gfp_rank
    return gfp_rank(A, P)


def main():
    dmax = int(sys.argv[1]) if len(sys.argv) > 1 else 72
    print("Building generator atoms up to length %d ..." % dmax)
    atoms = load_atoms(dmax)
    rank_to = min(dmax, 72)
    print("\nForming products by degree and ranking in orbit coordinates (up to n=%d):" % rank_to)
    dp = products_to_degree(atoms, rank_to)
    index = None
    try:
        index, _sizes, _reps = O.load_table()
        print("  (loaded length-72 orbit table: %d orbits)" % len(index))
    except FileNotFoundError:
        print("  (orbit table not built; canonicalizing on the fly -- rank unaffected)")

    print("\n  %-5s %-8s %-8s %-8s %s" % ("n", "#prods", "rank", "D_3(n)", "status"))
    for n in range(8, rank_to + 1, 8):
        prods = [en for (_names, en) in dp.get(n, [])]
        if not prods:
            continue
        t = time.time()
        A = orbit_columns(prods, index)
        r = rank_modp(A)
        target = HILBERT[n]
        status = "FULL" if r == target else "short by %d" % (target - r)
        print("  %-5d %-8d %-8d %-8d %s   (%.0fs)" % (n, len(prods), r, target, status, time.time() - t),
              flush=True)
        if n == 72:
            print("\n  => degree-72 span = %d / 152." % r)
            if r < 152:
                print("     Need %d more independent generator(s). The shortfall first" % (152 - r))
                print("     appears at the lowest n above where rank < D_3(n): supply")
                print("     non-d_n^+ Type II codes (Golay neighbors, [24,12] codes, ...)")
                print("     at that length and re-run.")
            else:
                print("     Basis complete: the [72,36,16] triweight is a combination of")
                print("     these columns; proceed to marginals.py + solve_and_test.py.")


if __name__ == "__main__":
    main()
