#!/usr/bin/env python3
"""Compute the genus-3 enumerator of C_1 = d_12^2 (Type II [24,12,4]), the 5th
generator of Chakraborty's degree-24 genus-3 basis and the one direction not
reachable from products of d_n^+ and Golay.  Same cost class as Golay
(M=4096 codewords, ~2.7 h via the parallel enumerator).  Validates the result
and writes c1_d12sq_genus3.json (genus-2/1 marginals printed as a cross-check)."""
import json
import time

import triweight_lib as L
import codes as K


def main():
    C = K.d12sq()
    M, n = C.shape
    print("C_1 = d_12^2 [24,12,4]: %d codewords, computing genus-3 enumerator (parallel)..." % M, flush=True)
    t = time.time()
    enum = L.genus3_enum_parallel(C, verbose=True)
    dt = time.time() - t
    tot = sum(enum.values())
    print("  done in %.1fs; monomials=%d, total=%d = |C|^3=%d ? %s"
          % (dt, len(enum), tot, M ** 3, tot == M ** 3), flush=True)

    ok_se, info = L.check_self_equation(enum, n, trials=4)
    print("  self-equation 2^{3n/2} T(x)=T(H^3 x):", ok_se, "" if ok_se else info, flush=True)
    ok_g, info = L.check_G_invariance(enum)
    print("  order-48 G-invariance:", ok_g, "" if ok_g else info, flush=True)

    g1 = L.genus1_marginal(enum, M)
    print("  genus-1 marginal (must match d12^2 Hamming distn {0:1,4:30,8:639,12:2756,...}):",
          sorted(g1.items()), flush=True)
    g2 = L.genus2_marginal(enum, M)
    print("  genus-2 marginal monomials:", len(g2), flush=True)

    out = {"code": "d12^2 (C_1) [24,12,4]", "n": n, "code_size": M,
           "self_equation": ok_se, "G_invariant": ok_g,
           "n_monomials": len(enum),
           "enumerator": [[list(k), v] for k, v in sorted(enum.items())]}
    with open("c1_d12sq_genus3.json", "w") as fh:
        json.dump(out, fh)
    print("  wrote c1_d12sq_genus3.json", flush=True)


if __name__ == "__main__":
    main()
