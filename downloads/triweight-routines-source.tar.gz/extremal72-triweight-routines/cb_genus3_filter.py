#!/usr/bin/env python3
"""
Genus-3 (triweight) feasibility filter for the forced n=56 residual C_B = [56,21]
of the [72,36,16] recursion (RECURSIVE.md).  Reuses the optimized, symmetrizing
genus-3 machinery in this folder:

  - factored_hadamard.apply_A_star : the genus-3 MacWilliams transform A*, with
    A*(T_C) = |C|^3 T_{C^perp}  (validated non-self-dual -- exactly the C_B<->C_B^perp
    coupling, since C_B is self-orthogonal but NOT self-dual).
  - triweight_orbits.canon         : the order-48 symmetrizer S_3 |x (Z/2)^3
    (length-agnostic; works at n=56).
  - triweight_lib.genus1/2_marginal: forced weight / biweight marginals.

WHY genus 3 (see RECURSIVE.md / the scoping notes):
  The recursion bottoms out at the rigid [24,1,24].  Shortening an n=40 child at a
  min word is AUTOMATIC at the enumerator level (its weight set {16,20,24,40}
  blocks every disjoint configuration).  At n=56 it is NOT automatic: C_B has the
  middle weights {28,32,36}, so disjoint configurations exist, and [24,1,24]
  forbids three pairwise-disjoint min words -- a genus-3 (triple) statement, i.e.
  a forced-zero triweight coefficient.  The full anchored genus-2 SPLIT is
  intractable (~67M vars); the GLOBAL genus-3 triweight is ~10^2-10^3 orbits.

This module (stage 1): build the n=56 genus-3 orbit support and report the LP size.
"""
import numpy as np
from itertools import permutations, product

from triweight_orbits import canon

# Forced weight set of C_B and (computed) of C_B^perp.
W_CB = [0, 16, 20, 24, 28, 32, 36, 40, 56]
N = 56

# 8x8 sign table  sign[p,S] = (-1)^popcount(p & S)
SIGN = np.empty((8, 8), dtype=np.int64)
for _p in range(8):
    for _S in range(8):
        SIGN[_p, _S] = -1 if bin(_p & _S).count("1") % 2 else 1

# pairwise inner products <u,v>,<u,w>,<v,w> even  (self-orthogonal C_B)
PAIRS = [(3, 7), (5, 7), (6, 7)]


def build_support(weights=W_CB, n=N):
    """All genus-3 cells (n_0..n_7), sum=n, with every nonzero combo-weight in
    `weights`, n_p >= 0, and pairwise-even (self-orthogonal).  Mirrors
    count_orbits.py's inverse-Hadamard construction, at length n.

    Returns an (M,8) int array of cells."""
    W = np.array(sorted(set(weights)), dtype=np.int64)
    out = []
    for wu, wv in product(list(W), list(W)):
        # the 5 remaining combo weights: w, u+v, u+w, v+w, u+v+w
        g = np.array(np.meshgrid(W, W, W, W, W, indexing="ij")).reshape(5, -1).T
        M = g.shape[0]
        h = np.empty((M, 8), dtype=np.int64)
        h[:, 0] = n                       # combo 0 (zero word), weight 0
        h[:, 1] = n - 2 * wu              # combo u
        h[:, 2] = n - 2 * wv              # combo v
        for k in range(5):                # combos w, u+v, u+w, v+w, u+v+w
            h[:, 3 + k] = n - 2 * g[:, k]
        cells = h @ SIGN.T                # 8 * n_p
        ok = np.all(cells % 8 == 0, axis=1)
        c8 = cells // 8
        ok &= np.all(c8 >= 0, axis=1)
        for (i, j) in PAIRS:
            ok &= ((c8[:, i] + c8[:, j]) % 2 == 0)
        if ok.any():
            out.append(c8[ok])
    if not out:
        return np.zeros((0, 8), dtype=np.int64)
    return np.unique(np.concatenate(out, axis=0), axis=0)


def orbit_table(cells):
    """Map cells to G-orbits via canon().  Returns (reps, rep_of, orbit_of_row)."""
    rep_of = {}
    reps = []
    orbit_of_row = np.empty(cells.shape[0], dtype=np.int64)
    for r in range(cells.shape[0]):
        c = canon(tuple(int(x) for x in cells[r]))
        oid = rep_of.get(c)
        if oid is None:
            oid = len(reps)
            rep_of[c] = oid
            reps.append(c)
        orbit_of_row[r] = oid
    return reps, rep_of, orbit_of_row


if __name__ == "__main__":
    print(f"Building genus-3 support for C_B = [{N},21], weights {W_CB}")
    cells = build_support()
    print(f"  raw genus-3 cells (in support): {cells.shape[0]}")
    reps, rep_of, orow = orbit_table(cells)
    print(f"  G-orbits (order-48 S_3 |x (Z/2)^3): {len(reps)}  <- LP variable count")

    # sanity: the all-zero-triple corner cell (u=v=w=0) is n_000=56, rest 0.
    corner = (N, 0, 0, 0, 0, 0, 0, 0)
    print(f"  corner cell {corner} present: {corner in set(map(tuple, cells.tolist()))}")
    # the [24,1,24] cell: three pairwise-disjoint weight-16 words
    #   n_000=8, n_u=n_v=n_w=16 (p=1,2,4), rest 0
    cell_3disj = (8, 16, 16, 0, 16, 0, 0, 0)
    in_supp = cell_3disj in set(map(tuple, cells.tolist()))
    print(f"  3-pairwise-disjoint-minword cell {cell_3disj} in support: {in_supp}"
          f"  (its orbit must be forced to 0 by [24,1,24])")
