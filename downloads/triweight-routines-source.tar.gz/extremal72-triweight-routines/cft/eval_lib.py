#!/usr/bin/env python3
r"""
Shared evaluation engine for the genus-3 CFT-degeneration constraints (#6/#7).

Factored out of ``exact_split.py``.  The core primitive is EXACT evaluation of the
genus-3 enumerator rows (R_0 and the five freedoms F_1..F_5) at a point
``x in GF(p)^8`` via orbit sums over the mindist support:

    S_j(x) = sum_{m in orbit j}  prod_p x_p^{m_p}        (4228 AGL orbits)
    row(x) = sum_j  N[row][j] * S_j(x)   (mod p)

Public API (used by ``factor_split.py`` and ``fourier_jacobi.py``):
    PRIMES                         three large primes (never trust one)
    load_V()        -> V           exact integer V (R_0 + F_1..F_5) + support
    eval_rows_at_points(V, rows, pts, p)   exact GF(p) evaluation
    load_j8()       -> [(exp,c)]   degree-16 ker-Theta generator
    j8_eval(j8,x,p)                evaluate j_8 at a point
    load_forced_genus2()           the forced genus-2 biweight enumerator W2
    rank_modp(M, p)                rank + left null space over GF(p)
    rational_reconstruct(a, p)     a/p  ->  (num, den) in Q

Everything is exact over GF(p).  Floating-point theta (theta_split.py) is for
validation only -- it is precision-limited on the degree-72 dynamic range.
"""
import os
import sys
import gzip
import json

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TRI = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(TRI, "support_pruned"))
sys.path.insert(0, TRI)

from target_support import Target  # noqa: E402

# Three large primes.  Single-prime ranks are untrustworthy (small-prime rank
# inflation bit V_play); always cross-check all three and reconstruct to Q.
PRIMES = [2899999957, 2899999931, 2899999903]


class V:
    """Container for the exact genus-3 enumerator data + mindist support layout.

    Attributes
    ----------
    N            : list of 6 exact integer rows (length 4228 = #AGL orbits)
    R0_int       : N[genuine_row]   (the forced part, carries the marginals)
    freedom_int  : the five freedom rows F_1..F_5
    den          : common denominator (64); enumerator = N / den
    raw_g        : (M,8) support exponents, grouped contiguously by orbit
    seg_id       : (M,) orbit index of each support monomial (in raw_g order)
    seg_starts   : (norb,) start offset of each orbit segment in raw_g
    thirdwt      : (M,) third-coordinate weight n_4+n_5+n_6+n_7 of each monomial
                   (= the Fourier-Jacobi grading; bit 2 of the column pattern)
    """

    def __init__(self):
        t = Target.load(72, "mindist")
        raw = np.ascontiguousarray(t.raw, dtype=np.int64)
        order = np.concatenate([np.asarray(mem, dtype=np.int64)
                                for _, mem in t.orbit_items])
        seg_sizes = np.array([len(mem) for _, mem in t.orbit_items], dtype=np.int64)
        self.seg_starts = np.concatenate([[0], np.cumsum(seg_sizes)[:-1]])
        self.raw_g = np.ascontiguousarray(raw[order])
        self.M = self.raw_g.shape[0]
        self.norb = len(seg_sizes)
        self.seg_id = np.repeat(np.arange(self.norb, dtype=np.int64), seg_sizes)
        # Fourier-Jacobi grading: the third codeword is the top bit (bit 2) of the
        # 3-bit column pattern p (SCOPE eq:factorizationX: x_i ~ a_{i>>2} b_{i&3}),
        # so columns p in {4,5,6,7} carry the third coordinate.
        self.thirdwt = self.raw_g[:, 4:8].sum(1).astype(np.int64)
        self.target = t

        d = json.load(gzip.open(os.path.join(TRI, "V_play", "exact_V.json.gz")))
        assert d["verified"] and d["den"] == 64
        self.N = d["N"]
        self.den = d["den"]
        self.genuine_row = int(d["genuine_row"])
        free_idx = [k for k in range(len(self.N)) if k != self.genuine_row]
        self.R0_int = self.N[self.genuine_row]
        self.freedom_int = [self.N[k] for k in free_idx]
        assert len(self.freedom_int) == 5
        assert len(self.R0_int) == self.norb


def load_V():
    return V()


def _point_monomial_values(Vv, x, p):
    """prod_p x_p^{m_p} mod p for every support monomial, in raw_g order."""
    pw = np.empty((8, 73), dtype=np.int64)
    for pp in range(8):
        row = np.empty(73, dtype=np.int64)
        row[0] = 1
        xp = int(x[pp]) % p
        for k in range(1, 73):
            row[k] = row[k - 1] * xp % p
        pw[pp] = row
    vals = np.ones(Vv.M, dtype=np.int64)
    for pp in range(8):
        vals = vals * pw[pp][Vv.raw_g[:, pp]] % p
    return vals


def eval_rows_at_points(Vv, rows, pts, p):
    """Exact GF(p) evaluation of integer enumerator rows at GF(p)^8 points.

    rows : iterable of length-4228 integer coefficient vectors (orbit coords).
    pts  : list of 8-tuples.
    Returns (len(rows), len(pts)) ndarray mod p.
    """
    rowmod = np.array([[c % p for c in r] for r in rows], dtype=np.int64)
    out = np.empty((rowmod.shape[0], len(pts)), dtype=np.int64)
    for jx, x in enumerate(pts):
        vals = _point_monomial_values(Vv, x, p)
        S = np.add.reduceat(vals, Vv.seg_starts) % p          # (norb,)
        # reduce mod p per element BEFORE summing: p^2 < 2^63 but 4228*p^2 is not.
        out[:, jx] = ((rowmod * S[None, :]) % p).sum(1) % p
    return out


# Fourier-Jacobi indices present in the support (third-coordinate weights).
FJ_INDICES = [16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56]
FJ_ALL_WEIGHTS = [0] + FJ_INDICES + [72]


def fj_slice_values(Vv, rows, pts, p):
    """Fourier-Jacobi slices of the genus-3 enumerator, exact over GF(p).

    Tagging the third coordinate by t (x_p -> x_p * t^{bit2(p)}) gives
        row(x; t) = sum_w  phi_w(row)(x) * t^w,
    so the q^w (=t^w) coefficient phi_w(row)(x) is the orbit value summed over
    only those support monomials whose third-coordinate weight equals w.

    Returns dict  w -> (len(rows), len(pts)) ndarray  for every w in
    FJ_ALL_WEIGHTS, where entry [r,k] = phi_w(rows[r]) evaluated at pts[k].
    """
    rowmod = np.array([[c % p for c in r] for r in rows], dtype=np.int64)
    nr = rowmod.shape[0]
    widx_of = {w: i for i, w in enumerate(FJ_ALL_WEIGHTS)}
    nW = len(FJ_ALL_WEIGHTS)
    # per-monomial bucket = orbit * nW + (third-weight index)
    wbucket = np.array([widx_of[int(w)] for w in Vv.thirdwt], dtype=np.int64)
    key = Vv.seg_id * nW + wbucket
    nkey = Vv.norb * nW
    out = {w: np.empty((nr, len(pts)), dtype=np.int64) for w in FJ_ALL_WEIGHTS}
    for jx, x in enumerate(pts):
        vals = _point_monomial_values(Vv, x, p)
        # exact: each (orbit,w) cell sums <=1344 values each < p < 2.9e9, so the
        # partial sum < 3.9e12 < 2^53 -> float64 bincount is exact.
        S = np.bincount(key, weights=vals.astype(np.float64),
                        minlength=nkey).astype(np.int64) % p
        S = S.reshape(Vv.norb, nW)                            # (norb, nW)
        for w in FJ_ALL_WEIGHTS:
            col = S[:, widx_of[w]]
            out[w][:, jx] = ((rowmod * col[None, :]) % p).sum(1) % p
    return out


def load_j8():
    j8 = json.load(open(os.path.join(HERE, "_j8_deg16.json")))
    return [(tuple(int(a) for a in e), int(c)) for e, c in j8]


def j8_eval(j8, x, p):
    s = 0
    for e, c in j8:
        term = c % p
        for pp in range(8):
            if e[pp]:
                term = term * pow(int(x[pp]) % p, e[pp], p) % p
        s = (s + term) % p
    return s


def load_forced_genus2():
    """The forced genus-2 biweight enumerator W2 = M2(R_0)/|C|.

    Returns dict { (wu,wv,t) : integer coeff } over its 1177-state support, which
    is exactly the third-coordinate-weight-0 slice of the genus-3 enumerator.
    """
    B = json.load(gzip.open(os.path.join(TRI, "V_play", "full_forced_B.json.gz")))
    out = {}
    for k, v in B["B"].items():
        wu, wv, t = (int(z) for z in k.split(","))
        out[(wu, wv, t)] = int(v)
    return out


def rank_modp(Mat, p):
    """rank of an integer matrix mod p; also return its LEFT null space basis
    (combos c with c . Mat == 0 mod p), each as a length-#rows vector."""
    A = [[int(v) % p for v in row] for row in (Mat.tolist() if hasattr(Mat, "tolist") else Mat)]
    nr = len(A)
    nc = len(A[0]) if nr else 0
    aug = [A[i] + [1 if j == i else 0 for j in range(nr)] for i in range(nr)]
    r = 0
    for c in range(nc):
        piv = None
        for i in range(r, nr):
            if aug[i][c] % p:
                piv = i
                break
        if piv is None:
            continue
        aug[r], aug[piv] = aug[piv], aug[r]
        inv = pow(aug[r][c], p - 2, p)
        aug[r] = [(v * inv) % p for v in aug[r]]
        for i in range(nr):
            if i != r and aug[i][c] % p:
                f = aug[i][c]
                aug[i] = [(aug[i][k] - f * aug[r][k]) % p for k in range(len(aug[i]))]
        r += 1
        if r == nr:
            break
    nulls = []
    for i in range(nr):
        if all(aug[i][k] % p == 0 for k in range(nc)):
            nulls.append([aug[i][nc + j] % p for j in range(nr)])
    return r, nulls


def rational_reconstruct(a, p, bound=None):
    """Reconstruct a rational num/den == a (mod p) with |num|,den <= bound.
    Returns (num, den) or None.  Standard half-GCD bound sqrt(p/2)."""
    a %= p
    if a == 0:
        return (0, 1)
    if bound is None:
        bound = int((p // 2) ** 0.5)
    r0, r1 = p, a
    s0, s1 = 0, 1
    while r1 > bound:
        q = r0 // r1
        r0, r1 = r1, r0 - q * r1
        s0, s1 = s1, s0 - q * s1
    num, den = r1, s1
    if den < 0:
        num, den = -num, -den
    if den == 0 or abs(num) > bound or den > bound:
        return None
    from math import gcd
    g = gcd(abs(num), den)
    return (num // g, den // g)
