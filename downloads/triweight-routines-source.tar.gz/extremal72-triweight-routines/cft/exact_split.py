#!/usr/bin/env python3
r"""
EXACT splitting computation over GF(p) -- definitive replacement for the
float64 theta evaluation (which lost precision on the degree-72 dynamic range).

Theta is a RING homomorphism with Theta(j_8)=0, so for F in R_3:
        Theta(F) = 0   <=>   j_8 | F   <=>   F vanishes on the hypersurface {j_8=0}.
Hence rank over GF(p) of  [ F_i(x_j) ]  at points x_j ON {j_8=0}  equals the
number of Theta-VISIBLE freedom directions; 5 - rank = dim(ker Theta among the
5 freedoms) = directions invisible to factorization / Fourier-Jacobi (#6/#7).

Points on {j_8=0} are built exactly: fix random (x_1..x_7), solve the univariate
j_8(x_0)=0 mod p (degree <=16) for x_0.  No theta, no precision, no R_3[56] basis.
Cross-checked at two large primes.
"""
import sys, os, gzip, json, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'support_pruned'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np
from sympy import Poly, symbols, GF
from target_support import Target

HERE = os.path.dirname(os.path.abspath(__file__))
TRI = os.path.join(HERE, '..')
XS = symbols('x')

# ---------------------------------------------------------------- ingredients
print("loading Target + exact_V + j_8 ...", flush=True)
t = Target.load(72, 'mindist')
raw = np.ascontiguousarray(t.raw, dtype=np.int64)
order = np.concatenate([np.asarray(mem, dtype=np.int64) for _, mem in t.orbit_items])
seg_sizes = np.array([len(mem) for _, mem in t.orbit_items], dtype=np.int64)
seg_starts = np.concatenate([[0], np.cumsum(seg_sizes)[:-1]])
raw_g = np.ascontiguousarray(raw[order])
M = raw_g.shape[0]
d = json.load(gzip.open(os.path.join(TRI, 'V_play', 'exact_V.json.gz')))
N = d['N']
freedom_int = [N[k] for k in range(1, 6)]                 # exact integer rows F_1..F_5
R0_int = N[0]
j8 = json.load(open(os.path.join(HERE, '_j8_deg16.json')))  # [[exptuple,coeff],...]
j8 = [(tuple(int(a) for a in e), int(c)) for e, c in j8]
print(f"  M={M} monomials, {len(seg_sizes)} orbits, j_8 has {len(j8)} terms", flush=True)


def eval_freedoms_modp(points, p):
    """points: list of 8-tuples (mod p).  Returns (5,len(points)) freedom values
    and (len(points),) R_0 values, all mod p, via orbit sums over the support."""
    Fmod = np.array([[v % p for v in f] for f in freedom_int], dtype=np.int64)   # (5,4228)
    R0mod = np.array([v % p for v in R0_int], dtype=np.int64)
    out = np.empty((5, len(points)), dtype=np.int64)
    r0 = np.empty(len(points), dtype=np.int64)
    for jx, x in enumerate(points):
        pw = np.empty((8, 73), dtype=np.int64)
        for pp in range(8):
            row = np.empty(73, dtype=np.int64); row[0] = 1
            xp = x[pp] % p
            for k in range(1, 73):
                row[k] = row[k - 1] * xp % p
            pw[pp] = row
        vals = np.ones(M, dtype=np.int64)
        for pp in range(8):
            vals = vals * pw[pp][raw_g[:, pp]] % p
        S = np.add.reduceat(vals, seg_starts) % p           # (4228,)
        for i in range(5):
            out[i, jx] = int(((Fmod[i] * S) % p).sum() % p)
        r0[jx] = int(((R0mod * S) % p).sum() % p)
    return out, r0


def j8_eval(x, p):
    s = 0
    for e, c in j8:
        term = c % p
        for pp in range(8):
            if e[pp]:
                term = term * pow(x[pp] % p, e[pp], p) % p
        s = (s + term) % p
    return s


def points_on_j8(p, want, seed):
    """generate `want` points x in GF(p)^8 with j_8(x)=0, by solving j_8(x_0)=0."""
    rng = np.random.default_rng(seed)
    pts = []
    tries = 0
    while len(pts) < want and tries < want * 6:
        tries += 1
        r = [int(rng.integers(1, p)) for _ in range(8)]      # r[0] is dummy (solved for)
        # univariate coeffs in x_0
        cf = [0] * 17
        for e, c in j8:
            d0 = e[0]
            prodrest = c % p
            for pp in range(1, 8):
                if e[pp]:
                    prodrest = prodrest * pow(r[pp], e[pp], p) % p
            cf[d0] = (cf[d0] + prodrest) % p
        # trim leading (highest-degree) zeros, then reverse to sympy's
        # highest-degree-first coefficient order
        while len(cf) > 1 and cf[-1] % p == 0:
            cf.pop()
        if len(cf) <= 1:
            continue
        roots = Poly(cf[::-1], XS, domain=GF(p)).ground_roots()
        for root in roots:
            x = [int(root)] + r[1:]
            if j8_eval(x, p) == 0:
                pts.append(tuple(x))
            if len(pts) >= want:
                break
    return pts


def rank_modp(Mat, p):
    """rank of integer matrix mod p via Gaussian elimination; also return left
    null space basis (combos c with c.M = 0 mod p)."""
    A = [[v % p for v in row] for row in Mat.tolist()]
    nr = len(A); nc = len(A[0]) if nr else 0
    # track row ops to recover left null space: augment with identity
    aug = [A[i] + [1 if j == i else 0 for j in range(nr)] for i in range(nr)]
    piv_cols = []
    r = 0
    for c in range(nc):
        piv = None
        for i in range(r, nr):
            if aug[i][c] % p:
                piv = i; break
        if piv is None:
            continue
        aug[r], aug[piv] = aug[piv], aug[r]
        inv = pow(aug[r][c], p - 2, p)
        aug[r] = [(v * inv) % p for v in aug[r]]
        for i in range(nr):
            if i != r and aug[i][c] % p:
                f = aug[i][c]
                aug[i] = [(aug[i][k] - f * aug[r][k]) % p for k in range(len(aug[i]))]
        piv_cols.append(c); r += 1
        if r == nr:
            break
    rank = r
    # left null space: rows of aug (the identity part) for which the A-part is all zero
    nulls = []
    for i in range(nr):
        if all(aug[i][k] % p == 0 for k in range(nc)):
            nulls.append([aug[i][nc + j] % p for j in range(nr)])
    return rank, nulls


# ---------------------------------------------------------------- run
PRIMES = [2899999957, 2899999931]
KPTS = 200
results = {}
for p in PRIMES:
    print(f"\n=== prime p = {p} ===", flush=True)
    t0 = time.time()
    pts = points_on_j8(p, KPTS, seed=1234)
    print(f"  generated {len(pts)} points on {{j_8=0}} in {time.time()-t0:.1f}s", flush=True)
    Fvals, r0vals = eval_freedoms_modp(pts, p)
    # sanity: all constructed points satisfy j_8=0
    assert all(j8_eval(x, p) == 0 for x in pts[:20])
    rank, nulls = rank_modp(Fvals, p)
    r0_nonzero = int(np.sum(r0vals % p != 0))
    print(f"  evaluated freedoms; R_0 nonzero at {r0_nonzero}/{len(pts)} points "
          f"(R_0 must be VISIBLE)")
    print(f"  rank over GF(p) of [F_i(x_j)] on {{j_8=0}} = {rank}")
    print(f"  => VISIBLE dim = {rank}, ker(Theta) among freedoms = {5 - rank}")
    if nulls:
        print(f"  kernel combos (c.[F1..F5] in ker Theta), {len(nulls)} of them:")
        for c in nulls:
            print("     ", c)
    results[str(p)] = {"n_points": len(pts), "rank_visible": rank,
                       "kernel_dim": 5 - rank, "R0_nonzero_points": r0_nonzero,
                       "kernel_combos": nulls}

# consistency across primes
vis = set(results[str(p)]["rank_visible"] for p in PRIMES)
print("\n=== CONSISTENCY ===")
print("  visible dim across primes:", {str(p): results[str(p)]["rank_visible"] for p in PRIMES})
print("  consistent:", len(vis) == 1)
json.dump({"primes": PRIMES, "K_points": KPTS, "results": results,
           "consistent": len(vis) == 1},
          open(os.path.join(HERE, 'exact_split_verdict.json'), 'w'), indent=2)
print("  wrote cft/exact_split_verdict.json")
