#!/usr/bin/env python3
r"""
Constraint #7 -- Fourier-Jacobi boundary membership (SCOPE.md section 3).

A candidate genus-3 enumerator is  v = R_0 + sum_{i=1}^5 a_i F_i.  Constraint #7
asks that, in the 1-step separating degeneration of the genus-3 period matrix

    Omega = [[Omega', z],[z^T, tau]],   q = e^{2 pi i tau},
    Theta(v)(Omega) = sum_{m>=0} phi_m(Omega', z) q^m,

every Fourier-Jacobi coefficient phi_m of the PARTITION FUNCTION Z = Theta(v) is a
genus-2 Jacobi form of weight 18 and index m, compatible with the lower-genus
Type II data (CFT.md #7).  This is strictly finer than factorization (#6, the
leading boundary term).

The code-side route (SCOPE 3.1).  The q-grading is the THIRD-codeword weight:
tagging the top bit of the column pattern by t  (x_p -> x_p t^{bit2(p)})  makes

    v(x; t) = sum_w phi_w(v)(x) t^w ,

so the enumerator-level Fourier-Jacobi coefficient phi_w(v) is just the slice of v
over support monomials of third-coordinate weight w (eval_lib.fj_slice_values).
The indices present are w in {0, 16, 20, ..., 56, 72}.  The genus-2 Jacobi FORM
phi_m(Theta(v)) is the genus-2 (Jacobi) theta image of this slice; m = w.

Why #7 sees at most sigma (SPLIT_RESULT.md).  Theta is a ring homomorphism with
ker Theta = <j_8>, and on the freedoms

    Theta(F_i) = lambda_i Theta(F_1),  lambda = (1, 921/34, 42/17, 32/17, 128/17),

so Theta(v) = Theta(R_0) + sigma * Theta(F_1) with

    sigma = a_1 + (921/34) a_2 + (42/17) a_3 + (32/17) a_4 + (128/17) a_5.

Fourier-Jacobi extraction from Theta is linear, hence phi_m(Theta(v)) =
phi_m^(0) + sigma phi_m^(1) for EVERY m: #7 can pin at most the single scalar sigma
(NOT the raw enumerator slices, which are honestly rank-5 -- the collapse is a
property of the theta image, ker Theta = <j_8>).

What this script certifies (exact, GF(p), three primes):
  (1) Phi-consistency / m=0 (SCOPE 3.3.1): phi_0(R_0) = W2 (the forced genus-2
      enumerator) and phi_0(F_i) = 0 -- the m=0 coefficient is sigma-independent.
  (2) the sigma-collapse of the partition function (SCOPE 3.3 bullet 3, at the
      correct -- theta -- level): the four exact kernel combos
          34 F_2 - 921 F_1,  17 F_3 - 42 F_1,  17 F_4 - 32 F_1,  17 F_5 - 128 F_1
      vanish on {j_8 = 0} (=> in ker Theta) while F_1 does not, so every
      phi_m(Theta(v)) depends on the freedoms only through sigma.
  (3) empirical Type II Jacobi membership at the minimal index m=16 (the one index
      with a precomputed genus-2 Jacobi family): a_freedom stays 5 -- VACUOUS.

Verdict (SCOPE 3.4 / decision tree 5).  phi_m(Theta(v)) is the m-th
Fourier-Jacobi coefficient of the genuine Siegel modular form Theta(v) =
Theta(R_0) + sigma Theta(F_1) (a C-combination of theta images of actual
enumerators), so it is AUTOMATICALLY a genus-2 Jacobi form of weight 18, index m,
for every sigma and every m -- confirmed empirically at m=16.  Hence #7 imposes no
condition on sigma: it is VACUOUS, sigma stays free, and the CFT-side
(degeneration) constraints are EXHAUSTED.  The remaining freedom is a code-side /
SDP problem (anchored Terwilliger section 19).
"""
import os
import sys
import json

import numpy as np

import eval_lib as E

HERE = os.path.dirname(os.path.abspath(__file__))
TRI = os.path.abspath(os.path.join(HERE, ".."))
ROOT = os.path.abspath(os.path.join(TRI, ".."))
AJ = os.path.join(ROOT, "anchored_jacobi")
sys.path.insert(0, os.path.join(TRI, "support_pruned"))
sys.path.insert(0, TRI)
sys.path.insert(0, AJ)

# the four exact ker-Theta generators (SPLIT_RESULT.md), as integer combos of the
# freedom rows F_1..F_5  (coefficients in the order F_1,F_2,F_3,F_4,F_5):
KERNEL_COMBOS = [
    ("34 F_2 - 921 F_1", [-921, 34, 0, 0, 0]),
    ("17 F_3 -  42 F_1", [-42, 0, 17, 0, 0]),
    ("17 F_4 -  32 F_1", [-32, 0, 0, 17, 0]),
    ("17 F_5 - 128 F_1", [-128, 0, 0, 0, 17]),
]
SIGMA = "a_1 + (921/34) a_2 + (42/17) a_3 + (32/17) a_4 + (128/17) a_5"


# --------------------------------------------------------------- j_8 = 0 points
def points_on_j8(j8, p, want, seed):
    """`want` exact points x in GF(p)^8 with j_8(x)=0, solving j_8(x_0)=0."""
    from sympy import Poly, symbols, GF
    XS = symbols("x")
    rng = np.random.default_rng(seed)
    pts, tries = [], 0
    while len(pts) < want and tries < want * 6:
        tries += 1
        r = [int(rng.integers(1, p)) for _ in range(8)]
        cf = [0] * 17
        for e, c in j8:
            prodrest = c % p
            for pp in range(1, 8):
                if e[pp]:
                    prodrest = prodrest * pow(r[pp], e[pp], p) % p
            cf[e[0]] = (cf[e[0]] + prodrest) % p
        while len(cf) > 1 and cf[-1] % p == 0:
            cf.pop()
        if len(cf) <= 1:
            continue
        for root in Poly(cf[::-1], XS, domain=GF(p)).ground_roots():
            x = tuple([int(root)] + r[1:])
            if E.j8_eval(j8, x, p) == 0:
                pts.append(x)
            if len(pts) >= want:
                break
    return pts


# --------------------------------------------------------------- (1) m=0 / Phi
def check_phi0(Vv, primes):
    """phi_0(R_0) = W2 (forced genus-2 enumerator) and phi_0(F_i)=0, all sigma."""
    W2 = E.load_forced_genus2()
    states = []
    for (wu, wv, t), c in W2.items():
        n3, n1, n2 = t, wu - t, wv - t
        n0 = 72 - n1 - n2 - n3
        states.append((n0, n1, n2, n3, c))

    def W2val(x, p):
        s = 0
        for n0, n1, n2, n3, c in states:
            if min(n0, n1, n2, n3) < 0:
                continue
            term = c % p
            for e, xv in zip((n0, n1, n2, n3), x[:4]):
                term = term * pow(int(xv) % p, e, p) % p
            s = (s + term) % p
        return s % p

    ok_R0 = ok_free = True
    for p in primes:
        rng = np.random.default_rng(101)
        pts = [tuple(int(rng.integers(1, p)) for _ in range(8)) for _ in range(6)]
        rows = [Vv.R0_int] + Vv.freedom_int
        fj = E.fj_slice_values(Vv, rows, pts, p)   # dict: w -> (nrows, npts)
        # phi_0(R_0) = phi_0(R0_int)/den  must equal W2  (row 0 is R_0)
        for k, x in enumerate(pts):
            if int(fj[0][0, k]) != (Vv.den * W2val(x, p)) % p:
                ok_R0 = False
        # phi_0 and phi_72 of every freedom must vanish (zero genus-2 marginal)
        for w in (0, 72):
            if (fj[w][1:6] % p != 0).any():
                ok_free = False
    return {"phi0_R0_equals_W2": ok_R0,
            "phi0_phi72_freedoms_vanish": ok_free,
            "den": Vv.den, "W2_states": len(W2)}


# ------------------------------------------------ (2) sigma-collapse via ker Theta
def check_sigma_collapse(Vv, primes, want=60):
    """Certify the four kernel combos vanish on {j_8=0} (=> in ker Theta) while
    F_1 does not.  This is the partition-function sigma-collapse: Theta(v), and
    hence every Fourier-Jacobi coefficient phi_m(Theta(v)), depends on the
    freedoms only through sigma."""
    j8 = E.load_j8()
    combo_rows = [c for _, c in KERNEL_COMBOS]
    # express each combo as a length-4228 integer enumerator row
    F = Vv.freedom_int
    combo_int = [[sum(c[i] * F[i][j] for i in range(5)) for j in range(Vv.norb)]
                 for c in combo_rows]
    per_prime = {}
    all_ok = True
    for p in primes:
        pts = points_on_j8(j8, p, want, seed=2024)
        assert all(E.j8_eval(j8, x, p) == 0 for x in pts[:10])
        rows = combo_int + [F[0]]                  # combos..., then F_1
        vals = E.eval_rows_at_points(Vv, rows, pts, p) % p
        combo_zero = [bool((vals[i] == 0).all()) for i in range(len(combo_rows))]
        f1_nonzero = int((vals[-1] != 0).sum())
        ok = all(combo_zero) and f1_nonzero > 0
        all_ok = all_ok and ok
        per_prime[str(p)] = {"n_points": len(pts),
                             "combos_vanish_on_j8": combo_zero,
                             "F1_nonzero_points": f1_nonzero}
    return {"all_combos_in_kerTheta": all_ok, "sigma": SIGMA,
            "kernel_combos": [name for name, _ in KERNEL_COMBOS],
            "per_prime": per_prime}


# ------------------------------------------ (3) empirical Jacobi membership, m=16
def membership_m16(Vv):
    """Reproduce the anchored genus-2 Jacobi membership test at the minimal index
    m=16, using the precomputed Type II Jacobi family
    (anchored_jacobi/anchored_genus2_family.json).  a_freedom < 5 would pin sigma;
    a_freedom == 5 means VACUOUS at m=16."""
    from reconstruct_charzero import build_structure
    import build_genus2_system as g2

    def gf_rank(rows, p):
        M = [[int(x) % p for x in row] for row in rows]
        nr = len(M); nc = len(M[0]) if M else 0
        r = 0
        for c in range(nc):
            piv = next((i for i in range(r, nr) if M[i][c] % p), None)
            if piv is None:
                continue
            M[r], M[piv] = M[piv], M[r]
            inv = pow(M[r][c], p - 2, p)
            M[r] = [(x * inv) % p for x in M[r]]
            for i in range(nr):
                if i != r and M[i][c]:
                    f = M[i][c]
                    M[i] = [(M[i][k] - f * M[r][k]) % p for k in range(nc)]
            r += 1
            if r == nr:
                break
        return r

    valid, orbits, orbit_of = g2.build_support_and_orbits()
    norb = len(orbits)
    with open(os.path.join(AJ, "anchored_genus2_family.json")) as fh:
        fam = json.load(fh)
    assert fam["norb"] == norb, (fam["norb"], norb)
    x_p = [int(z) for z in fam["x_p"]]
    homo = [[int(z) for z in row] for row in fam["homo"]]        # 8 x norb
    A16 = 249849

    t = Vv.target
    struct = build_structure(t)
    mono2col = struct[0]
    POW73 = (73 ** np.arange(8)).astype(object)
    keys = (t.raw.astype(object) * POW73).sum(1)
    key2orb = {int(keys[i]): int(mono2col[i]) for i in range(t.raw.shape[0])}

    Ng = Vv.R0_int
    Nf = Vv.freedom_int
    R0s = [0] * norb
    Fs = [[0] * norb for _ in range(5)]
    for o in range(norb):
        b, r = orbits[o][0]
        mono = (r[0], r[1], r[2], r[3], b[0], b[1], b[2], b[3])
        k = sum(int(mono[pp]) * (73 ** pp) for pp in range(8))
        idx = key2orb.get(k)
        if idx is not None:
            R0s[o] = int(Ng[idx])
            for i in range(5):
                Fs[i][o] = int(Nf[i][idx])

    p = 2_000_000_011
    rk_homo = gf_rank(homo, p)
    Fmat = [[Fs[i][o] for i in range(5)] for o in range(norb)]
    homoT = [[homo[i][o] for i in range(len(homo))] for o in range(norb)]
    FplusH = [Fmat[o] + homoT[o] for o in range(norb)]
    rk_FH = gf_rank(FplusH, p)
    a_freedom = 5 - (rk_FH - rk_homo)
    rhs = [(64 * A16 * x_p[o] - R0s[o]) for o in range(norb)]
    H_rhs = [homoT[o] + [rhs[o]] for o in range(norb)]
    rk_Hrhs = gf_rank(H_rhs, p)
    consistent = (rk_Hrhs == rk_homo)
    return {"index_m": 16, "anchored_orbits": norb,
            "rank_homo": rk_homo, "rank_F_homo": rk_FH,
            "a_freedom": int(a_freedom), "genuine_consistent": bool(consistent),
            "vacuous": a_freedom == 5}


def main():
    print("loading exact V (R_0 + F_1..F_5) + mindist support ...", flush=True)
    Vv = E.load_V()
    print("  M=%d monomials, %d orbits; FJ indices present: %s"
          % (Vv.M, Vv.norb, E.FJ_INDICES), flush=True)

    print("\n[1] m=0 / Phi-consistency (SCOPE 3.3.1) ...", flush=True)
    r1 = check_phi0(Vv, E.PRIMES)
    print("    phi_0(R_0) == W2 (forced genus-2):", r1["phi0_R0_equals_W2"])
    print("    phi_0, phi_72 of all freedoms vanish:", r1["phi0_phi72_freedoms_vanish"])

    print("\n[2] partition-function sigma-collapse via ker Theta "
          "(SCOPE 3.3 bullet 3) ...", flush=True)
    r2 = check_sigma_collapse(Vv, E.PRIMES)
    for p, d in r2["per_prime"].items():
        print("    p=%s: %d pts on {j_8=0}; combos vanish %s; F_1 nonzero at %d"
              % (p, d["n_points"], d["combos_vanish_on_j8"], d["F1_nonzero_points"]))
    print("    => all four kernel combos in ker Theta:", r2["all_combos_in_kerTheta"])
    print("    => Theta(v), hence every phi_m(Theta(v)), depends only on sigma =")
    print("       %s" % SIGMA)

    print("\n[3] empirical Type II Jacobi membership at minimal index m=16 ...", flush=True)
    r3 = membership_m16(Vv)
    print("    anchored orbits=%d  rank(homo)=%d  rank[F|homo]=%d"
          % (r3["anchored_orbits"], r3["rank_homo"], r3["rank_F_homo"]))
    print("    a_freedom = %d  (genuine slice consistent: %s)"
          % (r3["a_freedom"], r3["genuine_consistent"]))
    print("    m=16 membership VACUOUS:", r3["vacuous"])

    # ---- verdict (SCOPE 3.4 / decision tree 5) ----
    unit_tests_ok = (r1["phi0_R0_equals_W2"] and r1["phi0_phi72_freedoms_vanish"]
                     and r2["all_combos_in_kerTheta"] and r3["genuine_consistent"])
    vacuous = r3["vacuous"]
    print("\n================ VERDICT (constraint #7) ================")
    if not unit_tests_ok:
        verdict = "UNIT TESTS FAILED -- implementation error, do not trust"
    elif vacuous:
        verdict = ("#7 VACUOUS: phi_m(Theta(v)) is the m-th Fourier-Jacobi "
                   "coefficient of the genuine Siegel modular form Theta(v) = "
                   "Theta(R_0) + sigma*Theta(F_1), hence automatically a genus-2 "
                   "Jacobi form of weight 18 / index m for EVERY sigma (confirmed "
                   "empirically at m=16). #7 imposes no condition: sigma stays free. "
                   "CFT-side (degeneration) constraints are EXHAUSTED; the remaining "
                   "freedom is a code-side / SDP problem (anchored Terwilliger 19).")
    else:
        verdict = ("#7 PINS sigma: the empirical membership at m=16 reduced the "
                   "freedom (a_freedom < 5) -- sigma is fixed, freedom 5 -> 4.")
    print(verdict)

    out = {"unit_tests_ok": unit_tests_ok, "vacuous": vacuous,
           "phi0": r1, "sigma_collapse": r2, "membership_m16": r3,
           "sigma": SIGMA, "verdict": verdict, "primes": E.PRIMES}
    with open(os.path.join(HERE, "fourier_jacobi_verdict.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    print("\nwrote cft/fourier_jacobi_verdict.json")


if __name__ == "__main__":
    main()
