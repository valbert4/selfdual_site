#!/usr/bin/env python3
"""
Theta-visibility splitting of the 5-dim triweight freedom (CFT.md follow-up).

Question
--------
The CFT degeneration constraints -- separating factorization (CFT.md #6) and the
Fourier-Jacobi boundary membership (#7) -- both factor through the genus-3
PARTITION FUNCTION  Z = Theta(W).  The theta map  Theta : R_3 -> M_3  is
surjective with kernel the principal ideal <j_8> (Runge; HKM eq. M_3 = R_3/<j_8>,
j_8 a degree-16 = weight-8 polynomial).  Any freedom direction lying in ker Theta
is INVISIBLE to #6/#7 -- two enumerators differing by a multiple of j_8 have the
same Z.  So the maximum cut #6+#7 can ever deliver on the 5-dim freedom is
   rank( Theta restricted to span(F_1..F_5) ),
and the complementary  5 - rank  directions can only be pinned code-side
(positivity / 5-design integrality / anchored SDP).

Method (exact, char p, large prime -- avoids the small-prime rank inflation)
----------------------------------------------------------------------------
ker Theta cut out by the single hypersurface  {j_8 = 0}  (Runge: j_8 is the ONLY
relation among the 8 genus-3 theta constants).  Evaluate each freedom F_i at
random GF(p)-points x ON {j_8 = 0}:
  * F_i in ker Theta  =>  F_i = j_8 * g  =>  F_i(x) = 0  for every such x.
  * F_i not in ker    =>  F_i(x) != 0 generically (j_8 does not divide F_i).
So  visible_dim = rank_GF(p) [ F_i(x_j) ]_{i=1..5, j}  and  kernel_dim = 5 - that.

j_8 is built directly from the two Type II [16,8] codes
  j_8 = enum^(3)(e8(+)e8) - enum^(3)(d16+)        (HKM: these share genus-3 Z).

Points on {j_8=0} are produced by intersecting random lines a+lambda*b with the
degree-16 hypersurface and root-finding the univariate restriction over GF(p)
(Cantor-Zassenhaus).  Run at two of the V_play large primes for confirmation.
"""
import gzip
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "support_pruned"))

import triweight_lib as L          # noqa: E402
import codes as K                  # noqa: E402
from target_support import Target  # noqa: E402

PRIMES = [2899999957, 2899999931]   # two V_play large primes
NPTS = 28                            # points per prime on {j_8=0}
SEED = 12345

# ---------------------------------------------------------------------------
# GF(p) univariate polynomial arithmetic (coeffs low->high, Python ints)
# ---------------------------------------------------------------------------
def pnorm(a, p):
    a = [c % p for c in a]
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a

def pmul(a, b, p):
    r = [0] * (len(a) + len(b) - 1)
    for i, ai in enumerate(a):
        if ai:
            for j, bj in enumerate(b):
                r[i + j] = (r[i + j] + ai * bj) % p
    return pnorm(r, p)

def pdivmod(a, b, p):
    a = pnorm(a[:], p); b = pnorm(b, p)
    inv = pow(b[-1], p - 2, p)
    q = [0] * max(1, len(a) - len(b) + 1)
    while len(a) >= len(b) and not (len(a) == 1 and a[0] == 0):
        d = len(a) - len(b)
        c = (a[-1] * inv) % p
        q[d] = c
        for i, bi in enumerate(b):
            a[i + d] = (a[i + d] - c * bi) % p
        a = pnorm(a, p)
        if len(a) == 1 and a[0] == 0:
            break
    return pnorm(q, p), pnorm(a, p)

def pgcd(a, b, p):
    a = pnorm(a, p); b = pnorm(b, p)
    while not (len(b) == 1 and b[0] == 0):
        a, b = b, pdivmod(a, b, p)[1]
    return pnorm([c * pow(a[-1], p - 2, p) for c in a], p)  # monic

def ppowmod(base, e, mod, p):
    r = [1]; base = pdivmod(base, mod, p)[1]
    while e:
        if e & 1:
            r = pdivmod(pmul(r, base, p), mod, p)[1]
        base = pdivmod(pmul(base, base, p), mod, p)[1]
        e >>= 1
    return pnorm(r, p)

def roots_of(phi, p, rng):
    """All GF(p) roots of phi (deg<=16)."""
    phi = pnorm(phi, p)
    if len(phi) <= 1:
        return []
    # g = product of (x - r) over distinct roots r in GF(p)
    xp = ppowmod([0, 1], p, phi, p)          # x^p mod phi
    g = pgcd(psub_x(xp, p), phi, p)          # gcd(x^p - x, phi)
    out = []
    def split(h):
        h = pnorm(h, p)
        if len(h) <= 1:
            return
        if len(h) == 2:               # linear: c0 + c1 x
            out.append(((-h[0]) * pow(h[1], p - 2, p)) % p)
            return
        while True:
            a = rng.randrange(p)
            t = ppowmod([a, 1], (p - 1) // 2, h, p)
            t = pnorm([(t[0] - 1) % p] + t[1:], p) if t else [(-1) % p]
            d = pgcd(t, h, p)
            if 0 < len(d) - 1 < len(h) - 1:
                split(d)
                split(pdivmod(h, d, p)[0])
                return
    split(g)
    return out

def psub_x(xp, p):
    """xp(x) - x  as a normalized poly."""
    r = xp[:] if xp else [0]
    while len(r) < 2:
        r.append(0)
    r[1] = (r[1] - 1) % p
    return pnorm(r, p)

# ---------------------------------------------------------------------------
# j_8 as an enumerator dict {exptuple: coeff}
# ---------------------------------------------------------------------------
# Genuine INDECOMPOSABLE d16+ generator-half A (8x8 over F2): code = [I8 | A].
# NOTE: codes.d16plus() in the repo is buggy -- its RM-based greedy construction
# decomposes into 8+8 (= e8(+)e8, so enum3 agrees with e8(+)e8 and j_8 vanishes).
# This A gives a Type II [16,8,4] code that is indecomposable (weight-4 graph is a
# single 16-vertex component) and inequivalent to e8(+)e8, so j_8 != 0.
_D16PLUS_A = np.array([
    [0, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 0, 1, 1, 1, 1],
    [1, 0, 0, 1, 0, 0, 1, 0],
    [1, 1, 0, 1, 0, 0, 0, 0],
    [1, 0, 0, 1, 1, 0, 0, 0],
    [1, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 0, 1, 0, 1, 0, 0],
    [1, 0, 1, 1, 0, 0, 0, 0]], dtype=np.int8)

def _true_d16plus():
    G = np.concatenate([np.eye(8, dtype=np.int8), _D16PLUS_A], axis=1)
    assert ((G @ G.T) % 2 == 0).all(), "d16+ generator not self-orthogonal"
    return L.codewords_from_generators(G)

def build_j8():
    e8e8 = L.direct_sum(L.e8(), L.e8())
    d16 = _true_d16plus()
    # both are Type II [16,8,4]
    for nm, C in [("e8+e8", e8e8), ("d16+", d16)]:
        w = C.sum(1)
        assert C.shape == (256, 16) and int(w[w > 0].min()) == 4 and (w % 4 == 0).all(), nm
    En = L.genus3_enum_fast(e8e8)
    Dn = L.genus3_enum_fast(d16)
    for nm, en, C in [("e8+e8", En, e8e8), ("d16+", Dn, d16)]:
        ok, info = L.check_self_equation(en, C.shape[1], trials=4)
        assert ok and sum(en.values()) == C.shape[0] ** 3, "%s bad enum: %s" % (nm, info)
    # j_8 = difference of the two genus-3 enumerators
    j8 = {}
    for k in set(En) | set(Dn):
        c = En.get(k, 0) - Dn.get(k, 0)
        if c:
            j8[k] = c
    assert j8 and all(sum(k) == 16 for k in j8), "j_8 empty or not degree 16"
    # HKM: the two codes AGREE at genus 1 and genus 2 -> j_8's lower-genus
    # marginals must vanish (necessary for j_8 in ker Theta, since Theta is
    # injective at g<=2).  Strong independent check on the kernel claim.
    assert L.genus1_marginal(En, 256) == L.genus1_marginal(Dn, 256), "genus-1 differs!"
    assert L.genus2_marginal(En, 256) == L.genus2_marginal(Dn, 256), "genus-2 differs!"
    print("  validated: e8+e8 & d16+ agree at genus 1 AND 2, differ at genus 3"
          " (=> j_8 in ker Theta)")
    return j8

def jval(j8, x, p):
    """Evaluate j_8 at point x in GF(p)^8."""
    s = 0
    for m, c in j8.items():
        t = c % p
        for q in range(8):
            e = m[q]
            if e:
                t = (t * pow(x[q], e, p)) % p
        s = (s + t) % p
    return s

def line_poly(j8, a, b, p):
    """Coefficients (low->high) of phi(lambda) = j_8(a + lambda*b) via Lagrange
    interpolation through lambda = 0..16."""
    xs = list(range(17))
    ys = []
    for t in xs:
        pt = [(a[q] + t * b[q]) % p for q in range(8)]
        ys.append(jval(j8, pt, p))
    # Lagrange -> coefficient form mod p
    acc = [0]
    for i in range(17):
        num = [1]
        den = 1
        for j in range(17):
            if j == i:
                continue
            num = pmul(num, [(-xs[j]) % p, 1], p)
            den = (den * (xs[i] - xs[j])) % p
        scale = (ys[i] * pow(den % p, p - 2, p)) % p
        term = [(c * scale) % p for c in num]
        acc = pnorm([ (acc[k] if k < len(acc) else 0) + (term[k] if k < len(term) else 0)
                      for k in range(max(len(acc), len(term))) ], p)
    return acc

def gen_points(j8, p, npts, rng):
    """npts random GF(p)-points on {j_8 = 0}, each verified."""
    pts = []
    tries = 0
    while len(pts) < npts and tries < npts * 40:
        tries += 1
        a = [rng.randrange(p) for _ in range(8)]
        b = [rng.randrange(p) for _ in range(8)]
        phi = line_poly(j8, a, b, p)
        for r in roots_of(phi, p, rng):
            pt = [(a[q] + r * b[q]) % p for q in range(8)]
            assert jval(j8, pt, p) == 0, "root check failed"
            pts.append(pt)
            if len(pts) >= npts:
                break
    return pts

# ---------------------------------------------------------------------------
# Evaluate the 6 saved rows (R_0, F_1..F_5) at a GF(p) point
# ---------------------------------------------------------------------------
def eval_rows(Nmod, raw, col_of_row, x, p, ncol):
    """Return [row(x) mod p] for every row, row = sum_j N[j]*sum_{m in col j} x^m."""
    # power table (8, 73): xpow[q,k] = x[q]^k mod p
    xpow = np.empty((8, 73), dtype=np.int64)
    for q in range(8):
        v = 1
        xq = int(x[q]) % p
        for k in range(73):
            xpow[q, k] = v
            v = (v * xq) % p
    # monomial values over all support rows
    g = xpow[np.arange(8)[None, :], raw]        # (M,8)
    mono = np.ones(raw.shape[0], dtype=np.int64)
    for q in range(8):
        mono = (mono * g[:, q]) % p
    # orbit sums (members per column <= 1344, value < p ~ 2.9e9 -> fits int64)
    orb = np.zeros(ncol, dtype=np.int64)
    np.add.at(orb, col_of_row, mono)
    orb %= p
    orbl = orb.tolist()
    out = []
    for row in Nmod:
        s = 0
        for j, nij in row:                       # row is sparse [(col, Nmod)]
            s += nij * orbl[j]
        out.append(s % p)
    return out

def gfp_rank(M, p):
    M = [[c % p for c in r] for r in M]
    rows = len(M); cols = len(M[0]) if rows else 0
    r = 0
    for c in range(cols):
        piv = None
        for i in range(r, rows):
            if M[i][c] % p:
                piv = i; break
        if piv is None:
            continue
        M[r], M[piv] = M[piv], M[r]
        inv = pow(M[r][c], p - 2, p)
        M[r] = [(v * inv) % p for v in M[r]]
        for i in range(rows):
            if i != r and M[i][c] % p:
                f = M[i][c]
                M[i] = [(M[i][k] - f * M[r][k]) % p for k in range(cols)]
        r += 1
        if r == rows:
            break
    return r

# ---------------------------------------------------------------------------
def main():
    import random
    print("Loading exact char-0 V (6 primes, den 64, verified) ...")
    V = json.load(gzip.open(os.path.join(ROOT, "V_play", "exact_V.json.gz")))
    N = V["N"]                                   # 6 x 4228 exact integer numerators
    assert V["verified"] and V["den"] == 64
    nrows = len(N); ncol = len(N[0])
    print("  rows=%d (R_0 + F_1..F_5), cols=%d" % (nrows, ncol))

    print("Loading mindist Target (raw support + 4228-orbit partition) ...")
    t = Target.load(72, "mindist")
    raw = np.ascontiguousarray(t.raw, dtype=np.int64)
    M = raw.shape[0]
    assert len(t.orbit_items) == ncol, (len(t.orbit_items), ncol)
    col_of_row = np.empty(M, dtype=np.int64)
    for j, (_key, members) in enumerate(t.orbit_items):
        col_of_row[np.asarray(members, dtype=np.int64)] = j
    print("  support monomials M=%d, columns=%d" % (M, ncol))

    print("Building j_8 = enum3(e8+e8) - enum3(d16+) ...")
    j8 = build_j8()
    print("  j_8: %d monomials, degree 16, self-equation-invariant, A_0=0" % len(j8))

    rng0 = random.Random(SEED)
    labels = ["R_0(genuine)", "F_1", "F_2", "F_3", "F_4", "F_5"]
    summary = {}
    for p in PRIMES:
        print("\n=== prime p = %d ===" % p)
        Nmod = [[(j, c % p) for j, c in enumerate(row) if c % p] for row in N]
        rng = random.Random(rng0.randrange(1 << 60))
        # sanity: a GENERIC point (off {j_8=0}) -> j_8 != 0 and rows nonzero
        gp = [rng.randrange(p) for _ in range(8)]
        assert jval(j8, gp, p) != 0, "generic point accidentally on {j_8=0}"
        gen_vals = eval_rows(Nmod, raw, col_of_row, gp, p, ncol)
        print("  off-surface sanity: j_8!=0 OK; rows nonzero:",
              [v != 0 for v in gen_vals])

        pts = gen_points(j8, p, NPTS, rng)
        print("  generated %d verified points on {j_8=0}" % len(pts))
        cols = [eval_rows(Nmod, raw, col_of_row, x, p, ncol) for x in pts]
        Mrows = list(zip(*cols))                 # 6 rows x npts
        R0row = [Mrows[0]]
        Frows = [list(Mrows[i]) for i in range(1, 6)]

        r0_nonzero = sum(1 for v in Mrows[0] if v)
        print("  R_0 nonzero at %d/%d surface points (expect ~all: Theta(R_0)!=0)"
              % (r0_nonzero, len(pts)))
        Fzero = [sum(1 for v in Mrows[i] if v == 0) for i in range(1, 6)]
        print("  per-freedom #points where F_i==0 (out of %d):" % len(pts),
              dict(zip(labels[1:], Fzero)))

        vis = gfp_rank(Frows, p)
        rank_with_R0 = gfp_rank(Frows + R0row, p)
        print("  >> visible_dim = rank[F_i on {j_8=0}] = %d" % vis)
        print("     kernel_dim (invisible to #6/#7) = %d" % (5 - vis))
        print("     rank[F_1..5, R_0] = %d" % rank_with_R0)
        summary[p] = (vis, 5 - vis, r0_nonzero, Fzero)

    print("\n================ VERDICT ================")
    vis_set = set(s[0] for s in summary.values())
    if len(vis_set) == 1:
        vis = vis_set.pop()
        print("Both primes agree:  visible_dim = %d,  kernel_dim = %d" % (vis, 5 - vis))
        print("=> #6 (factorization) + #7 (Fourier-Jacobi) can pin at most %d of the" % vis)
        print("   5 freedom directions; the remaining %d lie in ker(Theta)=<j_8> and" % (5 - vis))
        print("   are reachable ONLY code-side (positivity / integrality / anchored SDP).")
    else:
        print("Primes disagree:", summary, " -- investigate.")

if __name__ == "__main__":
    main()
