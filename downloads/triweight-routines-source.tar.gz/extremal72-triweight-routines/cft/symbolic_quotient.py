#!/usr/bin/env python3
r"""
Symbolic quotient certificate for the theta-kernel directions in SPLIT_RESULT.md.

This script proves the four exact kernel relations by multivariate division over
ZZ, not by sampling the hypersurface {j_8=0}.  It writes

    symbolic_quotient_certificate.json.gz
    symbolic_quotient_summary.json

The certificate stores the primitive divisor J = j_8 / 1344 and, for each kernel
combo K, a packed sparse quotient Q such that

    K = J * Q

where K is the corresponding integer combination of the exact V freedom rows.
Exponent vectors are packed in base 73:

    code = e_0 + 73 e_1 + ... + 73^7 e_7.

The monomial order is weighted lex with positive weights below; under this order
J has leading coefficient -1, so exact integer division is fast and denominator
free.
"""

import argparse
import gzip
import hashlib
import json
import math
import os
import sys
import time
from typing import Dict, Iterable, List, Tuple

import heapq
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TRI = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(TRI, "support_pruned"))

from target_support import Target  # noqa: E402

BASE = 73
POW = [BASE**i for i in range(8)]
BASE8 = BASE**8
ORDER_WEIGHTS = (1, 5, 4, 1, 1, 5, 5, 4)

RELATIONS = [
    ("34*F_2-921*F_1", [-921, 34, 0, 0, 0]),
    ("17*F_3-42*F_1", [-42, 0, 17, 0, 0]),
    ("17*F_4-32*F_1", [-32, 0, 0, 17, 0]),
    ("17*F_5-128*F_1", [-128, 0, 0, 0, 17]),
]


def encode_exp(exp: Iterable[int]) -> int:
    return sum(int(a) * POW[i] for i, a in enumerate(exp))


def decode_exp(code: int) -> Tuple[int, ...]:
    return tuple((code // POW[i]) % BASE for i in range(8))


def order_key(code: int) -> int:
    weighted = 0
    for i, weight in enumerate(ORDER_WEIGHTS):
        weighted += weight * ((code // POW[i]) % BASE)
    return weighted * BASE8 + code


def term_hash(items: List[Tuple[int, int]]) -> str:
    h = hashlib.sha256()
    for code, coeff in items:
        h.update(str(code).encode("ascii"))
        h.update(b":")
        h.update(str(coeff).encode("ascii"))
        h.update(b"\n")
    return h.hexdigest()


def term_stats(items: List[Tuple[int, int]]) -> Dict[str, int | str]:
    max_bits = max((abs(c).bit_length() for _, c in items), default=0)
    return {
        "term_count": len(items),
        "max_abs_coeff_bits": max_bits,
        "sha256_packed_terms": term_hash(items),
    }


def load_divisor() -> Tuple[int, List[Tuple[int, int]], int, Tuple[int, ...], int]:
    raw = json.load(open(os.path.join(HERE, "_j8_deg16.json")))
    gcd = 0
    for _, coeff in raw:
        gcd = math.gcd(gcd, abs(int(coeff)))
    terms = [(encode_exp(exp), int(coeff) // gcd) for exp, coeff in raw if coeff]
    lead_code, lead_coeff = max(terms, key=lambda term: order_key(term[0]))
    lead_exp = decode_exp(lead_code)
    if lead_coeff not in (1, -1):
        raise RuntimeError(
            f"chosen monomial order has non-unit leading coefficient {lead_coeff}"
        )
    return gcd, terms, lead_code, lead_exp, lead_coeff


def load_target_codes() -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    target = Target.load(72, "mindist")
    raw = np.asarray(target.raw, dtype=np.int64)
    order = np.concatenate(
        [np.asarray(members, dtype=np.int64) for _, members in target.orbit_items]
    )
    seg_sizes = np.array([len(members) for _, members in target.orbit_items], dtype=np.int64)
    seg_starts = np.concatenate([[0], np.cumsum(seg_sizes)[:-1]])
    raw_grouped = raw[order]
    powers = np.array(POW, dtype=np.int64)
    packed = (raw_grouped * powers).sum(axis=1)
    return packed, seg_starts, seg_sizes


def load_freedom_rows() -> List[List[int]]:
    with gzip.open(os.path.join(TRI, "V_play", "exact_V.json.gz"), "rt") as fh:
        data = json.load(fh)
    if not data.get("verified"):
        raise RuntimeError("exact_V.json.gz is not marked verified")
    return [[int(x) for x in data["N"][i]] for i in range(1, 6)]


def build_dividend(
    combo: List[int],
    freedom_rows: List[List[int]],
    packed_monomials: np.ndarray,
    seg_starts: np.ndarray,
    seg_sizes: np.ndarray,
) -> Dict[int, int]:
    orbit_coeffs = [
        sum(combo[i] * freedom_rows[i][j] for i in range(5))
        for j in range(len(freedom_rows[0]))
    ]
    dividend: Dict[int, int] = {}
    for j, coeff in enumerate(orbit_coeffs):
        if coeff == 0:
            continue
        start = int(seg_starts[j])
        stop = start + int(seg_sizes[j])
        for code in packed_monomials[start:stop].tolist():
            dividend[int(code)] = int(coeff)
    return dividend


def divide_exact(
    dividend: Dict[int, int],
    divisor_terms: List[Tuple[int, int]],
    lead_code: int,
    lead_exp: Tuple[int, ...],
    lead_coeff: int,
    progress_label: str,
) -> Dict[int, int]:
    lead_digits = [(i, v) for i, v in enumerate(lead_exp) if v]
    active = dict(dividend)
    heap = [(-order_key(code), code) for code in active]
    heapq.heapify(heap)
    queued = set(active)
    quotient: Dict[int, int] = {}
    steps = 0
    t0 = time.time()

    while heap:
        _, code = heapq.heappop(heap)
        queued.discard(code)
        coeff = active.get(code)
        if not coeff:
            continue

        for i, exponent in lead_digits:
            if ((code // POW[i]) % BASE) < exponent:
                raise RuntimeError(
                    f"{progress_label}: leading remainder monomial {decode_exp(code)} "
                    f"is not divisible by LT(J)={lead_exp}; coeff={coeff}"
                )

        q_code = code - lead_code
        q_coeff = coeff // lead_coeff
        if q_coeff * lead_coeff != coeff:
            raise RuntimeError(
                f"{progress_label}: non-integral quotient coefficient {coeff}/{lead_coeff}"
            )

        quotient[q_code] = quotient.get(q_code, 0) + q_coeff
        for d_code, d_coeff in divisor_terms:
            new_code = q_code + d_code
            new_coeff = active.get(new_code, 0) - q_coeff * d_coeff
            if new_coeff:
                active[new_code] = new_coeff
                if new_code not in queued:
                    heapq.heappush(heap, (-order_key(new_code), new_code))
                    queued.add(new_code)
            else:
                active.pop(new_code, None)

        steps += 1
        if steps % 100000 == 0:
            print(
                f"  {progress_label}: steps={steps} active={len(active)} "
                f"quotient={len(quotient)} elapsed={time.time() - t0:.1f}s",
                flush=True,
            )

    if active:
        raise RuntimeError(f"{progress_label}: nonzero remainder with {len(active)} terms")
    return {code: coeff for code, coeff in quotient.items() if coeff}


def write_terms(fh, items: List[Tuple[int, int]]) -> None:
    fh.write("[")
    for idx, (code, coeff) in enumerate(items):
        if idx:
            fh.write(",")
        fh.write(f"[{code},{coeff}]")
    fh.write("]")


def generate(force: bool = False) -> None:
    cert_path = os.path.join(HERE, "symbolic_quotient_certificate.json.gz")
    summary_path = os.path.join(HERE, "symbolic_quotient_summary.json")
    if os.path.exists(cert_path) and not force:
        raise SystemExit(f"{cert_path} already exists; pass --force to overwrite")

    print("loading divisor, target support, and exact V freedoms ...", flush=True)
    divisor_gcd, divisor_terms, lead_code, lead_exp, lead_coeff = load_divisor()
    divisor_items = sorted(divisor_terms)
    divisor_summary = {
        "name": "J = j_8 / 1344",
        "j8_content": divisor_gcd,
        "term_count": len(divisor_items),
        "leading_exp": list(lead_exp),
        "leading_coeff": lead_coeff,
        "sha256_packed_terms": term_hash(divisor_items),
    }
    packed_monomials, seg_starts, seg_sizes = load_target_codes()
    freedom_rows = load_freedom_rows()

    summary = {
        "format": "packed sparse integer polynomial certificate",
        "pack_base": BASE,
        "variables": [f"x_{i:03b}" for i in range(8)],
        "monomial_order": {
            "type": "weighted lex",
            "weights": list(ORDER_WEIGHTS),
            "key": "sum_i weights[i]*e_i, then lex by packed exponent",
        },
        "divisor": divisor_summary,
        "relations": [],
    }

    with gzip.open(cert_path, "wt") as fh:
        fh.write("{")
        fh.write(json.dumps({k: summary[k] for k in ["format", "pack_base", "variables"]})[1:-1])
        fh.write(',"monomial_order":')
        fh.write(json.dumps(summary["monomial_order"]))
        fh.write(',"divisor":')
        divisor_obj = dict(divisor_summary)
        divisor_obj["terms"] = divisor_items
        fh.write(json.dumps(divisor_obj, separators=(",", ":")))
        fh.write(',"relations":[')

        for rel_idx, (name, combo) in enumerate(RELATIONS):
            print(f"\n=== {name} ===", flush=True)
            dividend = build_dividend(combo, freedom_rows, packed_monomials, seg_starts, seg_sizes)
            dividend_items = sorted(dividend.items())
            print(f"  dividend terms={len(dividend_items)}", flush=True)
            quotient = divide_exact(
                dividend,
                divisor_terms,
                lead_code,
                lead_exp,
                lead_coeff,
                name,
            )
            quotient_items = sorted(quotient.items())
            rel_summary = {
                "name": name,
                "combo_on_F1_to_F5": combo,
                "identity": f"{name} = (j_8/1344) * quotient",
                "dividend": term_stats(dividend_items),
                "quotient": term_stats(quotient_items),
                "remainder_terms": 0,
            }
            summary["relations"].append(rel_summary)
            print(
                f"  quotient terms={len(quotient_items)} "
                f"max_bits={rel_summary['quotient']['max_abs_coeff_bits']} "
                f"remainder=0",
                flush=True,
            )

            if rel_idx:
                fh.write(",")
            fh.write("{")
            fh.write(json.dumps({k: rel_summary[k] for k in ["name", "combo_on_F1_to_F5", "identity", "dividend", "quotient", "remainder_terms"]}, separators=(",", ":"))[1:-1])
            fh.write(',"quotient_terms":')
            write_terms(fh, quotient_items)
            fh.write("}")
            fh.flush()

        fh.write("]}")

    with open(summary_path, "w") as fh:
        json.dump(summary, fh, indent=2)
        fh.write("\n")

    print(f"\nwrote {cert_path}", flush=True)
    print(f"wrote {summary_path}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true", help="overwrite existing certificate")
    args = parser.parse_args()
    generate(force=args.force)


if __name__ == "__main__":
    main()
