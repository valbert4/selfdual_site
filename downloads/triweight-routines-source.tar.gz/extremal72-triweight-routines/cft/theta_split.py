#!/usr/bin/env python3
r"""
SPLITTING COMPUTATION (CFT.md constraints #6/#7 reachability).

Question: of the 5-dimensional genus-3 freedom space (V_play), how many directions
are VISIBLE under the genus-3 theta map Theta (= the CFT partition function side),
and how many lie in ker Theta = <j_8> (invisible to factorization / Fourier-Jacobi,
since those constraints factor through Z = Theta(W))?

Method (over C, so no finite-prime rank issues): evaluate each freedom F_i at many
generic genus-3 theta points  x_p = T_p(Omega) = theta[p/2;0](0, 2 Omega).
A combination sum c_i F_i lies in ker Theta  iff  sum c_i F_i(T(Omega)) = 0 for all
generic Omega.  So rank_C [ F_i(T(Omega_j)) ]_{5 x K} = visible dim;  kernel dim = 5 - rank.

Validation that the T_p are genuine theta points (on the theta locus Z):
  - j_8 (a known nonzero degree-16 element of ker Theta) must evaluate to ~0;
  - e8^2 and d16+ (differing by j_8) must evaluate EQUAL and nonzero;
  - exact all-ones check R_0(1..1)=|C|^3=2^108, F_i(1..1)=0 (orbit machinery).

Precision: each freedom is rescaled to O(1) coefficients so complex128 resolves the
cancellation cleanly (kernel ~1e-10 vs visible ~1e3+); a high-precision mpmath
recheck confirms the gap.
"""
import sys, os, gzip, json, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'support_pruned'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np
from target_support import Target

HERE = os.path.dirname(os.path.abspath(__file__))
TRI = os.path.join(HERE, '..')

# ---------------------------------------------------------------- ingredients
print("loading Target(72,'mindist') + exact_V + j_8 ...", flush=True)
t = Target.load(72, 'mindist')
raw = np.ascontiguousarray(t.raw, dtype=np.int64)          # (M,8) support monomials
M = raw.shape[0]
d = json.load(gzip.open(os.path.join(TRI, 'V_play', 'exact_V.json.gz')))
N = d['N']; DEN = d['den']                                  # 6 x 4228 integer rows, /DEN
freedom = [np.array(N[k], dtype=object) for k in range(1, 6)]   # F_1..F_5
R0 = np.array(N[0], dtype=object)                               # genuine row
j8 = json.load(open(os.path.join(HERE, '_j8_deg16.json')))     # [[exptuple,coeff],...] deg16

# group raw by orbit -> contiguous segments for reduceat
order = np.concatenate([np.asarray(mem, dtype=np.int64) for _, mem in t.orbit_items])
seg_sizes = np.array([len(mem) for _, mem in t.orbit_items], dtype=np.int64)
seg_starts = np.concatenate([[0], np.cumsum(seg_sizes)[:-1]])
raw_g = np.ascontiguousarray(raw[order])                    # (M,8) grouped by orbit
n_orbits = len(seg_sizes)
assert n_orbits == 4228 and raw_g.shape[0] == M
print(f"  M={M} monomials, {n_orbits} orbits", flush=True)

# rescale freedom rows to O(1) floats (rank is scale-invariant; this lets float64
# resolve the kernel cancellation)
def scaled(vec):
    mx = max(abs(int(v)) for v in vec) or 1
    return np.array([float(int(v)) / mx for v in vec], dtype=np.float64)
F_sc = np.array([scaled(f) for f in freedom])               # (5,4228) float
R0_sc = scaled(R0)

# ---------------------------------------------------------------- theta map
def theta_consts(Omega, Nmax=6):
    """8 second-order theta constants T_p = sum_n exp(2pi i (n+v_p)^T Omega (n+v_p)),
    v_p = ((p&1)/2,((p>>1)&1)/2,((p>>2)&1)/2).  Returns complex (8,)."""
    rng = np.arange(-Nmax, Nmax + 1)
    n1, n2, n3 = np.meshgrid(rng, rng, rng, indexing='ij')
    n = np.stack([n1.ravel(), n2.ravel(), n3.ravel()], axis=1).astype(np.float64)  # (L,3)
    T = np.empty(8, dtype=np.complex128)
    twopii = 2j * np.pi
    for p in range(8):
        v = np.array([(p >> b) & 1 for b in range(3)], dtype=np.float64) / 2.0
        nv = n + v                                          # (L,3)
        # quadratic form (n+v)^T Omega (n+v)
        Q = np.einsum('li,ij,lj->l', nv, Omega, nv)
        T[p] = np.sum(np.exp(twopii * Q))
    return T

def eval_deg16(terms, T):
    """evaluate a degree-16 polynomial given as [[exptuple,coeff],...] at point T."""
    logT = np.log(T)
    s = 0j
    for e, c in terms:
        s += c * np.exp(np.dot(np.array(e, dtype=np.float64), logT))
    return s

def orbit_sums(T):
    """S_j = sum_{m in orbit j} prod_p T_p^{m_p}, for all 4228 orbits.
    T is normalized (max|T_p|=1) so every monomial is O(1): F_i is homogeneous of
    degree 72, so T -> T/max scales each column by max^72 (rank-preserving)."""
    logT = np.log(T)                                        # (8,) complex
    logvals = raw_g.astype(np.float64) @ logT               # (M,) complex
    vals = np.exp(logvals)                                  # (M,) complex (negligible monos -> 0)
    S = np.add.reduceat(vals, seg_starts)                   # (4228,) complex
    return S

# ---------------------------------------------------------------- random Omega
def random_omega(rng, eig_lo=0.75, eig_hi=1.05):
    """Omega = X + iY with Y SPD whose eigenvalues are bounded in [eig_lo,eig_hi]
    (guarantees theta convergence at Nmax=6 and O(1) theta constants)."""
    X = rng.uniform(-0.5, 0.5, size=(3, 3)); X = (X + X.T) / 2
    Z = rng.standard_normal((3, 3))
    Q, _ = np.linalg.qr(Z)                                  # random orthogonal
    eigs = rng.uniform(eig_lo, eig_hi, size=3)
    Y = Q @ np.diag(eigs) @ Q.T
    return X + 1j * Y

def good_theta(rng):
    """draw Omega until the theta point passes the ker-Theta validation
    (j_8(T) ~ 0): rejects any non-converged / off-locus point. Returns normalized T."""
    for _ in range(200):
        Om = random_omega(rng)
        T = theta_consts(Om)
        if np.min(np.abs(T)) < 1e-12:
            continue
        vj = eval_deg16([[e, c] for e, c in j8], T) / scale16_g
        if abs(vj) < 1e-9:
            return T / np.max(np.abs(T)), abs(vj)          # homogeneity-normalized
    raise RuntimeError("could not draw a well-conditioned theta point")

# j_8 term-scale (for the normalized vanishing test)
scale16_g = sum(abs(c) for _, c in j8)

# ---------------------------------------------------------------- validation
print("\n=== validation ===", flush=True)
rng = np.random.default_rng(20260614)
T0, vj0 = good_theta(rng)
print("  |T_p| (normalized):", np.round(np.abs(T0), 4))
import dnplus as D, triweight_lib as L
W8 = D.dnplus_genus3(8); e8sq = L.enum_product(W8, W8); d16 = D.dnplus_genus3(16)
val_j8 = eval_deg16([[list(k), v] for k, v in {tuple(e): c for e, c in j8}.items()], T0)
val_e8 = eval_deg16([[list(k), v] for k, v in e8sq.items()], T0)
val_d16 = eval_deg16([[list(k), v] for k, v in d16.items()], T0)
print(f"  j_8(T)/scale = {abs(val_j8)/scale16_g:.2e}   (should be ~0)")
print(f"  e8^2(T) = {val_e8:.6e}   d16+(T) = {val_d16:.6e}")
print(f"  |e8^2 - d16+|(T) (=|j_8|, should be ~0): {abs(val_e8-val_d16):.3e}")
THETA_OK = abs(val_j8) / scale16_g < 1e-9 and abs(val_e8) > 1e-9
print("  THETA NORMALIZATION VALID:", THETA_OK)

# ---------------------------------------------------------------- main: rank
print("\n=== evaluating Theta on the 5 freedoms at K well-conditioned points ===", flush=True)
K = 24
Mmat = np.empty((5, K), dtype=np.complex128)
r0row = np.empty(K, dtype=np.complex128)
j8row = np.empty(K, dtype=np.float64)
for jx in range(K):
    T, vj = good_theta(rng)
    S = orbit_sums(T)
    for i in range(5):
        Mmat[i, jx] = F_sc[i] @ S
    r0row[jx] = R0_sc @ S
    j8row[jx] = vj
    if jx % 6 == 0:
        print(f"   point {jx+1}/{K}  (j_8/scale={vj:.1e})", flush=True)
# normalize each column to unit max|F_i| (homogeneity already applied; this just
# equalizes columns for a clean SVD readout -- column scaling preserves rank)
colnorm = np.max(np.abs(Mmat), axis=0); colnorm[colnorm == 0] = 1
Mmat_n = Mmat / colnorm

# rank of the column-normalized 5 x K freedom matrix
U, sv, Vh = np.linalg.svd(Mmat_n)
tol = 1e-7 * sv[0]
visible = int(np.sum(sv > tol))
print("\n=== RESULT ===")
print("  singular values of column-normalized [F_i(T(Omega_j))] (5 x %d):" % K)
for r, s in enumerate(sv):
    print(f"     sigma_{r+1} = {s:.6e}   {'(VISIBLE)' if s > tol else '(kernel ~0)'}")
print(f"  gap sigma_visible/sigma_kernel = "
      f"{sv[visible-1]/sv[visible]:.2e}" if 0 < visible < 5 else "  (no split or full)")
print(f"  |j_8(T)/scale| over points (must be ~0): max {np.max(j8row):.3e}")
print(f"  |R_0(T)| over points (R_0 must be visible/nonzero): "
      f"min {np.min(np.abs(r0row)):.3e}")
print(f"\n  VISIBLE dim (rank over C) = {visible}")
print(f"  ker(Theta) dim among the 5 freedoms = {5 - visible}")
# left null space (kernel combinations among F_1..F_5)
if visible < 5:
    ker_combos = U[:, visible:]                            # columns = kernel directions in F-space
    print("\n  kernel combinations (coeffs on [F1..F5], each should give Theta=0):")
    for cc in range(ker_combos.shape[1]):
        v = ker_combos[:, cc].real
        v = v / np.max(np.abs(v))
        print("     ", np.round(v, 4))

verdict = {
    "M_monomials": int(M), "n_orbits": int(n_orbits), "K_points": K,
    "theta_normalization_valid": bool(THETA_OK),
    "j8_over_scale_max": float(np.max(j8row)),
    "R0_abs_min": float(np.min(np.abs(r0row))),
    "singular_values": [float(s) for s in sv],
    "visible_dim": visible,
    "kernel_dim_among_freedoms": 5 - visible,
}
json.dump(verdict, open(os.path.join(HERE, 'theta_split_verdict.json'), 'w'), indent=2)
print("\n  wrote cft/theta_split_verdict.json")
