#!/usr/bin/env python3
"""Constructors for small binary Type II codes used as ring generators, each
returned as an (M, n) 0/1 numpy array of all codewords, and validated
(self-dual, doubly-even, claimed minimum distance)."""
import numpy as np

from triweight_lib import codewords_from_generators, e8, direct_sum  # noqa: F401


def _gen_to_codewords(G):
    return codewords_from_generators([list(r) for r in G])


def golay24():
    """Extended binary Golay [24,12,8] = [23,12,7] cyclic QR code + overall
    parity.  Generator polynomial g(x)=x^11+x^10+x^6+x^5+x^4+x^2+1 (a divisor of
    x^23-1); the [23,12] cyclic code is the row-span of its shifts, then we add
    an overall parity coordinate."""
    g = [1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1]   # coeffs x^0..x^11, weight 7
    G23 = np.zeros((12, 23), dtype=np.int8)
    for i in range(12):
        G23[i, i:i + 12] = g
    parity = G23.sum(axis=1) % 2               # 1 for each (weight-7) row
    G = np.hstack([G23, parity[:, None].astype(np.int8)])
    return _gen_to_codewords(G)


def _rref_gf2(rows):
    """Row-reduce a list of F_2 row vectors (numpy int arrays); return basis."""
    basis = []
    for r in (row.copy() % 2 for row in rows):
        for b in basis:
            piv = np.argmax(b)
            if r[piv]:
                r = (r + b) % 2
        if r.any():
            basis.append(r)
    return basis


def d16plus():
    """The second Type II [16,8,4] code (indecomposable d16+), built by extending
    RM(1,4) inside its dual RM(2,4) with doubly-even self-orthogonal glue chosen
    so the result is NOT e8(+)e8.  Verified by validate_code."""
    n = 16
    pts = [tuple((j >> b) & 1 for b in range(4)) for j in range(n)]  # F_2^4 points
    one = np.ones(n, dtype=np.int8)
    lin = [np.array([p[b] for p in pts], dtype=np.int8) for b in range(4)]
    quad = []
    for a in range(4):
        for b in range(a + 1, 4):
            quad.append(np.array([p[a] & p[b] for p in pts], dtype=np.int8))
    base = [one] + lin                                   # RM(1,4), dim 5
    # add quadratics keeping doubly-even + self-orthogonal until dim 8
    chosen = list(base)
    cur = _rref_gf2(chosen)
    for q in quad:
        cand = _rref_gf2(cur + [q])
        if len(cand) == len(cur):
            continue                                     # dependent
        wts_ok = (int(q.sum()) % 4 == 0)
        orth = all(int((q.astype(int) @ c.astype(int)) % 2) == 0 for c in cur)
        if wts_ok and orth:
            cur = cand
        if len(cur) == 8:
            break
    G = np.array(cur, dtype=np.int8)
    return _gen_to_codewords(G)


def qr48_generators():
    """Generator matrix (24 x 48) of the extended quadratic-residue code
    [48,24,12] (Type II, extremal).  The [47,24] binary QR code is the row span of
    the cyclic shifts of the indicator of the nonzero quadratic residues mod 47
    (47 = 7 mod 8, so 2 is a residue and the generating idempotent is over F_2);
    each shift is extended by an overall parity coordinate (coord 0) and the
    all-ones word is adjoined, giving the self-dual doubly-even [48,24,12].
    Verified: weight distribution A_12=17296, A_16=535095, A_20=3995376,
    A_24=7681680 (extremal).  Returns the GENERATOR matrix, not the 2^24
    codewords -- the genus-3 enumerator of a [48,24] code is a 2^72-triple object
    and is NOT brute-forceable (see SCOPE 2.2 / the qr48 note)."""
    QR = sorted({(i * i) % 47 for i in range(1, 47)})       # 23 nonzero residues
    q = np.zeros(47, dtype=np.int8)
    for j in QR:
        q[j] = 1
    rows = [np.ones(48, dtype=np.int8)]
    for i in range(47):
        sh = np.roll(q, i)
        rows.append(np.concatenate([[sh.sum() % 2], sh]).astype(np.int8))
    return np.array(_rref_gf2(rows), dtype=np.int8)          # 24 x 48 basis


def d12sq():
    """C_1 = d_12^2, a Type II [24,12,4] self-dual doubly-even code -- the 5th
    generator in Chakraborty's degree-24 genus-3 basis {e8^3, g_24, d_24^+,
    d_16^+(+)e8, C_1}, i.e. the one direction NOT spanned by products of d_n^+
    and Golay.  Generator matrix supplied directly (an indecomposable gluing of
    two d_12 blocks, not a direct sum).  Verified: self-dual, doubly-even,
    weight distribution A_4=30, A_8=639, A_12=2756 (d=4)."""
    rows = ("100000010000010001011101 010000010000010001011110 "
            "001001000101000100000111 000101000101000100001011 "
            "000011000000000000001100 000000110000000000000011 "
            "000000001100000000001100 000000000011000000001100 "
            "000000000000110000000011 000000000000001100001100 "
            "000000000000000011000011 000000000000000000110011").split()
    G = np.array([[int(c) for c in r] for r in rows], dtype=np.int8)
    return _gen_to_codewords(G)


def validate_code(C, name, expect_d=None):
    M, n = C.shape
    k = M.bit_length() - 1
    assert (1 << k) == M, "not a power of two"
    wts = sorted(set(int(w.sum()) for w in C))
    nz = [w for w in wts if w > 0]
    dmin = min(nz) if nz else 0
    doubly_even = all(w % 4 == 0 for w in wts)
    # self-dual: every pair of codewords orthogonal (check generators suffice,
    # but full check via random sample of codewords is cheap here)
    Gm = C.astype(np.int64)
    inner = (Gm @ Gm.T) % 2
    self_orth = not inner.any()
    selfdual = self_orth and (k == n // 2)
    ok = doubly_even and selfdual and (expect_d is None or dmin == expect_d)
    print("  %-10s [%d,%d,%d]  weights=%s  doubly_even=%s self_dual=%s  %s"
          % (name, n, k, dmin, wts, doubly_even, selfdual, "OK" if ok else "FAIL"))
    return ok


if __name__ == "__main__":
    validate_code(e8(), "e8", 4)
    validate_code(direct_sum(e8(), e8()), "e8+e8", 4)
    validate_code(d16plus(), "d16+", 4)
    validate_code(golay24(), "golay24", 8)
    validate_code(d12sq(), "d12^2 (C_1)", 4)
