#!/usr/bin/env python3
"""Convert an AGL(3,2) nullbasis (bench_agl_parallel output) into the order-48
orbit format that span72_eval_rank / marginal_shortcircuit consume
(`{n,p,orbit_reps,basis}`, expandable via GROUP48).

An AGL(3,2) orbit is a union of order-48 orbits, and a genus-3 invariant is
constant on AGL orbits, hence on the finer order-48 orbits.  So we expand each
AGL-orbit rep to its 1344 images, fold them to their order-48 canonical reps, and
assign each order-48 rep the coefficient of its containing AGL column.  Result
spans the SAME invariant space, in the coordinates the existing tools use.

  /usr/bin/python3 convert_agl_basis.py matrices/agl_n48_p13.nullbasis.json.gz n48_basis_p13.json.gz
"""
import gzip
import json
import sys

import triweight_lib as L            # GROUP48 (order-48)
import bench_agl_parallel as B       # AGL_PERMS (1344)

GROUP48 = [tuple(int(x) for x in g) for g in L.GROUP48]
AGL = [tuple(int(x) for x in g) for g in B.AGL_PERMS]


def o48_canon(e):
    return min(tuple(e[g[i]] for i in range(8)) for g in GROUP48)


def convert(path_in, path_out):
    with gzip.open(path_in, "rt") as fh:
        d = json.load(fh)
    n, p = int(d["n"]), int(d["p"])
    col_reps = [tuple(int(x) for x in r) for r in d["col_reps"]]
    nullbasis = d["nullbasis"]

    # order-48 rep -> index of the AGL column that contains it
    o48_to_col = {}
    for o, rep in enumerate(col_reps):
        imgs = {tuple(rep[g[i]] for i in range(8)) for g in AGL}   # AGL orbit (distinct)
        for m in imgs:
            r48 = o48_canon(m)
            if r48 not in o48_to_col:
                o48_to_col[r48] = o
    reps_list = sorted(o48_to_col)
    colof = [o48_to_col[r] for r in reps_list]

    basis_out = [[int(vec[colof[j]]) % p for j in range(len(reps_list))]
                 for vec in nullbasis]
    out = {"format": "order-48 orbit basis (converted from AGL nullbasis)",
           "n": n, "p": p,
           "orbit_reps": [list(r) for r in reps_list],
           "basis": basis_out}
    with gzip.open(path_out, "wt") as fh:
        json.dump(out, fh, separators=(",", ":"))
    print("converted %s -> %s : %d order-48 orbits, %d basis vectors (n=%d p=%d)"
          % (path_in, path_out, len(reps_list), len(basis_out), n, p))
    return out


if __name__ == "__main__":
    convert(sys.argv[1], sys.argv[2])
