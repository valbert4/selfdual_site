#!/usr/bin/env python3
"""
Exact genus-3 orbit count (= number of unknowns in the self-equation) under the
order-48 symmetry group G = S_3 |x (Z/2)^3 acting on coordinate patterns
(a,b,c) in {0,1}^3, i.e. as 48 permutations of the 8 monomial entries.
Also reports C(79,7), the naive number of degree-72 monomials in 8 variables
(= row count of the brute genus-2-style matrix), to show why that approach fails.
"""
import numpy as np
from math import comb
from itertools import permutations, product

# --- regenerate the 3.49M support monomials (same logic as count_support.py) ---
W = np.array([0, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 72], dtype=np.int64)
sign = np.empty((8, 8), dtype=np.int64)
for p in range(8):
    for S in range(8):
        sign[p, S] = -1 if bin(p & S).count('1') % 2 else 1
PAIRS = [(3, 7), (5, 7), (6, 7)]

mons = []
for wu, wv in product(list(W), list(W)):
    g = np.array(np.meshgrid(W, W, W, W, W, indexing='ij')).reshape(5, -1).T
    N = g.shape[0]
    h = np.empty((N, 8), dtype=np.int64)
    h[:, 0] = 72; h[:, 1] = 72 - 2 * wu; h[:, 2] = 72 - 2 * wv
    for k in range(5):
        h[:, 3 + k] = 72 - 2 * g[:, k]
    n = h @ sign.T
    ok = np.all(n % 8 == 0, axis=1)
    n8 = (n // 8)
    ok &= np.all(n8 >= 0, axis=1)
    for (i, j) in PAIRS:
        ok &= ((n8[:, i] + n8[:, j]) % 2 == 0)
    if ok.any():
        mons.append(n8[ok])
M = np.concatenate(mons, axis=0).astype(np.int64)
print("support monomials:", M.shape[0])

# --- group as 48 permutations of the 8 coordinate indices p = a + 2b + 4c ----
def idx(a, b, c): return a + 2 * b + 4 * c
perms = set()
for axis in permutations(range(3)):           # S_3 on (a,b,c)
    for flip in product([0, 1], repeat=3):     # (Z/2)^3 translations
        perm = [0] * 8
        for a, b, c in product([0, 1], repeat=2 + 1):
            v = (a, b, c)
            w = tuple(v[axis[k]] ^ flip[k] for k in range(3))
            perm[idx(*v)] = idx(*w)
        perms.add(tuple(perm))
perms = [list(p) for p in perms]
print("group order:", len(perms))

# --- canonical key = min over 48 permutations of the base-128 encoding -------
powv = (128 ** np.arange(8)).astype(np.int64)
best = None
for perm in perms:
    key = (M[:, perm] * powv).sum(axis=1)
    best = key if best is None else np.minimum(best, key)
n_orbits = np.unique(best).size
print("exact G-orbits (unknowns):", n_orbits)
print("naive degree-72 monomials in 8 vars  C(79,7) =", comb(79, 7))
print("  (genus-2 analogue C(75,3) =", comb(75, 3), ", matched the 67525 rows)")
