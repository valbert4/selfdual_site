#!/usr/bin/env python3
"""
Estimate the genus-3 (triweight) support size for the putative Type II
[72,36,16] code, to scope the MacWilliams self-equation computation.

A triweight monomial is an 8-tuple n_p, p=(a,b,c) in {0,1}^3, sum n_p = 72,
counting coordinates where (u,v,w) take pattern (a,b,c).  The Hadamard/MacWilliams
structure gives a BIJECTION between the 8 numbers (72 = n_total, and the 7
subset-weights w_S = wt(sum_{i in S} x_i) for nonempty S subset {u,v,w}) and the
8 values n_p:

    h_S := sum_p (-1)^{<p,S>} n_p = 72 - 2 w_S      (h_empty = 72)
    n_p  = (1/8) sum_S (-1)^{<p,S>} h_S.

So we enumerate the 13^7 = 62.7M choices of the 7 subset-weights w_S in the
Gleason weight set W, invert the Hadamard transform, and keep those giving
nonnegative integer n_p with even pairwise inner products (self-orthogonality).

This counts SUPPORT MONOMIALS (= columns/rows scale of the genus-3 system) and
also the number of G-orbits under the order-48 group (Z/2)^3 |x S_3, which is
what actually sets the solve size.
"""
import numpy as np
from itertools import product

W = np.array([0, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 72], dtype=np.int64)

# sign[p, S] = (-1)^popcount(p & S), p,S in 0..7  (bit0=u, bit1=v, bit2=w)
sign = np.empty((8, 8), dtype=np.int64)
for p in range(8):
    for S in range(8):
        sign[p, S] = -1 if bin(p & S).count('1') % 2 else 1

# pairwise-intersection coordinate masks (n_p with both bits set):
#  <u,v> = n_{110}+n_{111} : p with bits u,v set -> p in {3,7}
#  <u,w> = n_{101}+n_{111} : p in {5,7}
#  <v,w> = n_{011}+n_{111} : p in {6,7}
PAIR = {'uv': (3, 7), 'uw': (5, 7), 'vw': (6, 7)}

n_support = 0
# chunk over the first two subset-weights to keep memory bounded (13^2 chunks)
WS = list(W)
for wu, wv in product(WS, WS):
    # remaining 5 subset-weights vary; build their grid: 13^5 = 371293
    g = np.array(np.meshgrid(W, W, W, W, W, indexing='ij')).reshape(5, -1).T  # (N,5)
    N = g.shape[0]
    # subset order S=1..7 : u,v,w,uv,uw,vw,uvw
    # here S=1->wu (fixed), S=2->wv (fixed), S=3..7 -> g columns 0..4
    h = np.empty((N, 8), dtype=np.int64)
    h[:, 0] = 72
    h[:, 1] = 72 - 2 * wu
    h[:, 2] = 72 - 2 * wv
    for k in range(5):
        h[:, 3 + k] = 72 - 2 * g[:, k]
    # n_p = (1/8) sum_S sign[p,S] h_S
    n = (h @ sign.T)  # (N,8), still times 8
    ok = np.all(n % 8 == 0, axis=1)
    n8 = n // 8
    ok &= np.all(n8 >= 0, axis=1)
    # self-orthogonality: pairwise inner products even
    for (i, j) in PAIR.values():
        ok &= ((n8[:, i] + n8[:, j]) % 2 == 0)
    n_support += int(ok.sum())

print("genus-3 support monomials (8-tuples):", n_support)
print("approx G-orbits (order-48 group)     :", n_support // 48, "(lower bound; some orbits shorter)")
