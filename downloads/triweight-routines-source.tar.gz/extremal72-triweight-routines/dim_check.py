#!/usr/bin/env python3
"""Confirm D_3(n) by computing genus-3 enumerators of actual Type II codes and
ranking them.  Each enumerator is a vector over the union of support monomials;
the rank = dimension spanned, which must be <= D_3(n) and (with enough codes)
equal it."""
import sys
import numpy as np

import triweight_lib as L
import codes as K


def rank_of_enums(enums, p=1000003):
    cols = {}
    for e in enums:
        for mono in e:
            cols.setdefault(mono, len(cols))
    A = np.zeros((len(cols), len(enums)), dtype=np.int64)
    for j, e in enumerate(enums):
        for mono, c in e.items():
            A[cols[mono], j] = c % p
    from selfeq_nullity import gfp_rank
    return gfp_rank(A, p)


def get_enum(C):
    M = C.shape[0]
    fn = L.genus3_enum_fast if M <= 512 else L.genus3_enum_parallel
    return fn(C)


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 16
    if n == 16:
        codelist = [("e8^2", L.direct_sum(K.e8(), K.e8())),
                    ("d16+", K.d16plus())]
        expect = 2
    elif n == 24:
        e8 = K.e8()
        codelist = [("e8^3", L.direct_sum(L.direct_sum(e8, e8), e8)),
                    ("e8+d16+", L.direct_sum(e8, K.d16plus())),
                    ("golay24", K.golay24())]
        expect = 5
    else:
        print("n must be 16 or 24")
        return
    enums = []
    for name, C in codelist:
        e = get_enum(C)
        ok, _ = L.check_self_equation(e, n, trials=3)
        print("  %-10s monomials=%d  self-eqn=%s" % (name, len(e), ok))
        enums.append(e)
    r = rank_of_enums(enums)
    print("n=%d: %d codes span rank %d  (D_3(%d)=%d; spanned=%s)"
          % (n, len(enums), r, n, expect, "all" if r == expect else "partial"))


if __name__ == "__main__":
    main()
