#!/usr/bin/env python3
"""
Genus-3 weight enumerators of the codes d_n^+ via the closed form of
Fujii-Oura (2018), eq. (89):

    W_{d_n^+}^{(g)} = 2^{-g} sum_{beta,gamma in F_2^g}
                         ( sum_{alpha in F_2^g} (-1)^{alpha.beta} x_{alpha+gamma} x_alpha )^{n/2}.

For g=3 the 8 variables are indexed by alpha in {0,..,7} (bits = F_2^3); this is a
sum of 64 (=8*8) powers of an 8-term quadratic, computable directly for any n.
These W_{d_n^+}^{(3)} are the generators of the subring D^{(3)} (Thm 1); together
with the Golay enumerator (and a few more non-d_n^+ codes) they generate the full
genus-3 ring W^{(3)} whose degree-72 part is the 152-dimensional target space.
"""
from collections import defaultdict

import triweight_lib as L


def _sign(a, b):
    return -1 if bin(a & b).count('1') % 2 else 1


def Qform(beta, gamma):
    """The inner quadratic  sum_alpha (-1)^{alpha.beta} x_{alpha+gamma} x_alpha ."""
    Q = defaultdict(int)
    for alpha in range(8):
        e = [0] * 8
        e[alpha] += 1
        e[alpha ^ gamma] += 1
        Q[tuple(e)] += _sign(alpha, beta)
    return {k: v for k, v in Q.items() if v}


def poly_pow(P, k):
    """P**k for a polynomial dict, by exponentiation by squaring."""
    result = {(0,) * 8: 1}
    base = P
    while k:
        if k & 1:
            result = L.enum_product(result, base)
        k >>= 1
        if k:
            base = L.enum_product(base, base)
    return result


def dnplus_genus3(n):
    """W_{d_n^+}^{(3)} as { exptuple : integer coeff }."""
    assert n % 8 == 0
    half = n // 2
    total = defaultdict(int)
    for beta in range(8):
        for gamma in range(8):
            for e, c in poly_pow(Qform(beta, gamma), half).items():
                total[e] += c
    out = {}
    for e, c in total.items():
        assert c % 8 == 0, "W_{d_n^+} coeff not divisible by 2^g=8"
        if c:
            out[e] = c // 8
    return out


def dnplus_genus3_modp(n, p):
    """d_n^+ genus-3 enumerator with coefficients reduced mod p, as a dict
    {exptuple: coeff_mod_p}.  Fast numpy implementation for the rank check: each
    Q(beta,gamma)^{n/2} is built by LINEAR powering (multiply by the 8-term
    quadratic n/2 times), which keeps every intermediate product cheap, and all
    coefficients stay in int64 (no big-int blowup).  Validated against the exact
    dnplus_genus3 modulo p in the __main__ self-test."""
    import numpy as np
    assert n % 8 == 0
    m = n // 2
    POW = (128 ** np.arange(8)).astype(np.int64)   # base-128 exponent encoding

    def encode(d):
        keys = np.array([sum(e[i] * int(POW[i]) for i in range(8)) for e in d], dtype=np.int64)
        cf = np.array([c % p for c in d.values()], dtype=np.int64)
        return keys, cf

    def mul_by_quad(keys, cf, qk, qc):
        nk = (keys[:, None] + qk[None, :]).ravel()
        nc = (cf[:, None] * qc[None, :]).ravel() % p
        u, inv = np.unique(nk, return_inverse=True)
        agg = np.zeros(u.shape[0], dtype=np.int64)
        np.add.at(agg, inv, nc)
        agg %= p
        keep = agg != 0
        return u[keep], agg[keep]

    total = {}
    inv8 = pow(8, p - 2, p)                          # 2^{-3} = 1/8 mod p
    for beta in range(8):
        for gamma in range(8):
            qk, qc = encode(Qform(beta, gamma))
            keys = np.array([0], dtype=np.int64)
            cf = np.array([1], dtype=np.int64)
            for _ in range(m):
                keys, cf = mul_by_quad(keys, cf, qk, qc)
            for k, c in zip(keys.tolist(), cf.tolist()):
                total[k] = (total.get(k, 0) + c) % p
    out = {}
    for k, c in total.items():
        c = (c * inv8) % p
        if c:
            e = tuple((k // int(POW[i])) % 128 for i in range(8))
            out[e] = c
    return out


if __name__ == "__main__":
    import numpy as np
    import codes as K

    # n=8: d_8^+ = e8, so the formula must reproduce the e8 genus-3 enumerator.
    W8 = dnplus_genus3(8)
    e8enum = L.genus3_enum_fast(K.e8())
    print("d_8^+  vs e8 brute enumerator:", W8 == e8enum, " (%d monomials)" % len(W8))
    ok, _ = L.check_self_equation(W8, 8, trials=4)
    print("  self-equation:", ok, " total=%d=|C|^3=%d?" % (sum(W8.values()), 16 ** 3),
          sum(W8.values()) == 16 ** 3)

    # n=16: this is the *indecomposable* d_16^+; its genus-3 enumerator should
    # DIFFER from e8(+)e8 (the two together span D_3(16)=2).
    W16 = dnplus_genus3(16)
    e8sq = L.enum_product(e8enum, e8enum)
    ok16, _ = L.check_self_equation(W16, 16, trials=3)
    print("d_16^+ self-equation:", ok16, " monomials=%d  == e8^2 ? %s"
          % (len(W16), W16 == e8sq))

    # rank of {e8^2, d_16^+} should be 2 = D_3(16)
    from dim_check import rank_of_enums
    r = rank_of_enums([e8sq, W16])
    print("  rank{e8^2, d_16^+} =", r, "(expect D_3(16)=2)")
