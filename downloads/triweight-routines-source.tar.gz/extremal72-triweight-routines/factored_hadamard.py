#!/usr/bin/env python3
"""
Factored genus-3 Hadamard transform A* : T(x) -> T(Ax), (Ax)_p = sum_q (-1)^<p,q> x_q.

Instead of the dense 8-variable expansion A*(x^m) = prod_p (sum_q (-1)^<p,q> x_q)^{m_p}
(which blows up; see FACTORED_HADAMARD.md), we use  A = H_0 H_1 H_2  (Hadamard in
each of the 3 bit-slots) and apply three SINGLE-BIT passes.  Each pass substitutes,
within the 4 disjoint variable-pairs (lo, hi=lo+2^k),

    x_lo -> x_lo + x_hi ,   x_hi -> x_lo - x_hi ,

i.e.  x_lo^a x_hi^b -> (x_lo+x_hi)^a (x_lo-x_hi)^b , a product of four independent
2-variable expansions.  Composing the three passes gives the full transform far
more cheaply than the naive multinomial.

Genus-3 MacWilliams identity used for validation:
    A*( W_C^{(3)} ) = |C|^3 * W_{C^perp}^{(3)}.
For self-dual C this is the self-equation  A*(W) = 2^{3n/2} W.

Polynomials are dicts { exptuple(8) : coeff }.  Pass `mod` for arithmetic mod p
(coefficients stay bounded); default is exact ZZ.
"""
from collections import defaultdict
from functools import lru_cache
from math import comb


@lru_cache(maxsize=None)
def _pair_coeffs(a, b):
    """Coefficients of  (X+Y)^a (X-Y)^b  by Y-exponent s (X-exponent = a+b-s):
    pc[s] = sum_{j} C(a, s-j) C(b, j) (-1)^j ,  for s = 0..a+b."""
    pc = [0] * (a + b + 1)
    for i in range(a + 1):
        for j in range(b + 1):
            pc[i + j] += comb(a, i) * comb(b, j) * (-1 if (j & 1) else 1)
    return tuple(pc)


def single_bit_pass(poly, k, mod=0):
    """Apply H_k* (single-bit Hadamard substitution in bit-slot k) to poly."""
    bit = 1 << k
    pairs = [(p, p | bit) for p in range(8) if not (p & bit)]
    out = defaultdict(int)
    for e, c in poly.items():
        cur = {e: c}
        for (lo, hi) in pairs:
            nxt = defaultdict(int)
            for ee, cc in cur.items():
                a, b = ee[lo], ee[hi]
                if a == 0 and b == 0:
                    nxt[ee] += cc
                    continue
                pc = _pair_coeffs(a, b)
                base = list(ee)
                tot = a + b
                for s, w in enumerate(pc):
                    if not w:
                        continue
                    base[lo] = tot - s
                    base[hi] = s
                    v = cc * w
                    nxt[tuple(base)] += v
            if mod:
                cur = {kk: vv % mod for kk, vv in nxt.items() if vv % mod}
            else:
                cur = {kk: vv for kk, vv in nxt.items() if vv}
        for ee, cc in cur.items():
            out[ee] += cc
    if mod:
        return {kk: vv % mod for kk, vv in out.items() if vv % mod}
    return {kk: vv for kk, vv in out.items() if vv}


def apply_A_star(poly, mod=0):
    """A*(poly) = poly(Ax), via the three single-bit passes (slots 0,1,2)."""
    for k in range(3):
        poly = single_bit_pass(poly, k, mod=mod)
    return poly


_BIT_SUPPORTS = tuple(tuple(q for q in range(8) if q & (1 << k)) for k in range(3))


def _parity_on_bit(e, k):
    return sum(e[q] for q in _BIT_SUPPORTS[k]) & 1


def final_translation_even_pass(poly, k, mod=0):
    """Apply the last single-bit pass, returning only translation-even rows.

    Orbit columns in ``selfeq_nullspace.sage`` sum over the (Z/2)^3 translation
    part of the affine symmetry group.  That sum kills every output monomial
    whose three bit-parity sums are not all even.  If the final Hadamard pass is
    along bit ``k``, the parity sums for the other two bits are already fixed by
    the pair totals before the pass, so those doomed input terms can be skipped
    before the expensive final expansion.
    """
    bit = 1 << k
    pairs = [(p, p | bit) for p in range(8) if not (p & bit)]
    other_bits = [j for j in range(3) if j != k]
    out = defaultdict(int)
    for e, c in poly.items():
        if any(_parity_on_bit(e, j) for j in other_bits):
            continue
        cur = {e: c}
        for pair_idx, (lo, hi) in enumerate(pairs):
            last_pair = pair_idx == len(pairs) - 1
            nxt = defaultdict(int)
            for ee, cc in cur.items():
                a, b = ee[lo], ee[hi]
                need_hi_parity = None
                if last_pair:
                    need_hi_parity = sum(ee[q] for q in _BIT_SUPPORTS[k] if q != hi) & 1
                if a == 0 and b == 0:
                    if not last_pair or need_hi_parity == 0:
                        nxt[ee] += cc
                    continue
                pc = _pair_coeffs(a, b)
                base = list(ee)
                tot = a + b
                for s, w in enumerate(pc):
                    if last_pair and (s & 1) != need_hi_parity:
                        continue
                    if not w:
                        continue
                    base[lo] = tot - s
                    base[hi] = s
                    nxt[tuple(base)] += cc * w
            if mod:
                cur = {kk: vv % mod for kk, vv in nxt.items() if vv % mod}
            else:
                cur = {kk: vv for kk, vv in nxt.items() if vv}
        for ee, cc in cur.items():
            out[ee] += cc
    if mod:
        return {kk: vv % mod for kk, vv in out.items() if vv % mod}
    return {kk: vv for kk, vv in out.items() if vv}


def apply_A_star_translation_even(poly, mod=0, order=(0, 1, 2)):
    """A*(poly), restricted to rows surviving the translation orbit sum."""
    for k in order[:-1]:
        poly = single_bit_pass(poly, k, mod=mod)
    return final_translation_even_pass(poly, order[-1], mod=mod)


# ---------------------------------------------------------------------------
def _scale(poly, f, mod=0):
    if mod:
        return {k: (v * f) % mod for k, v in poly.items() if (v * f) % mod}
    return {k: v * f for k, v in poly.items()}


def _eq(p, q):
    p = {k: v for k, v in p.items() if v}
    q = {k: v for k, v in q.items() if v}
    return p == q


if __name__ == "__main__":
    import numpy as np
    import json
    import triweight_lib as L
    import codes as K

    # ---- self-dual fixed-point checks: A*(W) == 2^{3n/2} W ----
    e8 = K.e8()
    We8 = L.genus3_enum_fast(e8)
    lhs = apply_A_star(We8)
    rhs = _scale(We8, 2 ** (3 * 8 // 2))
    print("e8  [8,4]  : A*(W) == 2^{12} W ?", _eq(lhs, rhs))

    g = json.load(open("golay_genus3.json"))
    Wg = {tuple(k): v for k, v in g["enumerator"]}
    print("golay [24,12]: A*(W) == 2^{36} W ?",
          _eq(apply_A_star(Wg), _scale(Wg, 2 ** (3 * 24 // 2))))

    # ---- DISCRIMINATING non-self-dual check: A*(W_C) == |C|^3 W_{C^perp} ----
    # C = [4,1] repetition {0000,1111};  C^perp = [4,3] even-weight code.
    C = np.array([[0, 0, 0, 0], [1, 1, 1, 1]], dtype=np.int8)
    Cperp = np.array([[a, b, c, (a + b + c) % 2] for a in (0, 1) for b in (0, 1)
                      for c in (0, 1)], dtype=np.int8)   # even weight [4,3]
    WC = L.genus3_enum_brute(C)
    WCp = L.genus3_enum_brute(Cperp)
    lhs = apply_A_star(WC)
    rhs = _scale(WCp, len(C) ** 3)      # |C|=2 -> |C|^3 = 8
    print("[4,1] non-self-dual: A*(W_C) == |C|^3 W_{C^perp} ?", _eq(lhs, rhs),
          " (|C|^3=%d)" % (len(C) ** 3))

    # a second non-self-dual code: [6,2]
    C2 = L.codewords_from_generators([[1, 1, 1, 1, 0, 0], [0, 0, 1, 1, 1, 1]])
    # dual of C2 (length 6): brute-construct
    allv = np.array([[ (m >> i) & 1 for i in range(6)] for m in range(64)], dtype=np.int8)
    inC2perp = np.all((allv @ C2.T) % 2 == 0, axis=1)
    C2perp = allv[inC2perp]
    WC2 = L.genus3_enum_brute(C2)
    WC2p = L.genus3_enum_brute(C2perp)
    print("[6,2] non-self-dual: A*(W_C) == |C|^3 W_{C^perp} ?",
          _eq(apply_A_star(WC2), _scale(WC2p, len(C2) ** 3)),
          " (|C|=%d, |C^perp|=%d)" % (len(C2), len(C2perp)))

    # ---- mod-p path agrees with exact (mod p) ----
    P = 1009
    em = {k: v % P for k, v in We8.items()}
    a_exact = {k: v % P for k, v in apply_A_star(We8).items() if v % P}
    a_modp = apply_A_star(em, mod=P)
    print("mod-p engine == exact (mod %d) on e8 ?" % P, a_exact == a_modp)
