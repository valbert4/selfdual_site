#!/usr/bin/env python3
"""Priority 4 verification: the support-only rows are rigorous over Q.

Claim (Fischer/Bombieri orthogonality).  Let A be the 8x8 genus-3 Hadamard
matrix A[p,q] = (-1)^<p,q>.  Then A is symmetric and A^2 = 8 I, so Atil = A/sqrt8
is a real ORTHOGONAL involution.  On homogeneous degree-n forms in the 8
variables, the substitution operator (A* f)(x) = f(A x) equals scale*(f o Atil)
with scale = 2^(3n/2) = 8^(n/2), because f(A x) = f(sqrt8 * Atil x) =
8^(n/2) f(Atil x).  The Fischer inner product <x^a, x^b> = delta_ab * a!
(a! = prod_i a_i!) is invariant under orthogonal substitutions, hence

    <A* f, A* g>_Fischer = scale^2 <f, g>_Fischer,     i.e.  M^T G M = scale^2 G,

where M is the matrix of A* in the monomial basis and G = diag(a!).

Consequence (no fake support-only solutions over Q).  Let W = span of the
admissible support monomials (a COORDINATE subspace, so P_W is the Fischer-
orthogonal projection because distinct monomials are Fischer-orthogonal).  If
f in W solves the support-only equation P_W (A* f) = scale * f, write
A* f = scale f + w with w in W^perp.  Orthogonality gives
||A* f||^2 = scale^2 ||f||^2, while Pythagoras gives
||A* f||^2 = ||scale f||^2 + ||w||^2.  Hence ||w||^2 = 0, so w = 0 and
A* f = scale f: f is a genuine invariant.  So support-only kernel = invariants,
exactly, over characteristic 0.

This script verifies the linchpin identity M^T G M = scale^2 G (and M^2 =
scale^2 I) for small n by exact integer arithmetic.  Positive-definiteness of G
over Q is what kills w; over F_p it can fail (e.g. the n=8 p=17 nullity-3
artifact), which is exactly why cross-prime agreement is the modular certificate
that the rational kernel was recovered.
"""
from fractions import Fraction
from itertools import product as iproduct
from math import factorial

import numpy as np

# 8x8 genus-3 Hadamard A[p,q] = (-1)^<p,q>, <p,q> = parity of bitwise-AND.
A = np.array([[-1 if bin(p & q).count("1") & 1 else 1 for q in range(8)]
              for p in range(8)], dtype=np.int64)


def degree_monomials(n, nvars=8):
    """All exponent tuples of length nvars summing to n (lex order)."""
    out = []

    def rec(idx, left, cur):
        if idx == nvars - 1:
            out.append(tuple(cur + [left]))
            return
        for k in range(left + 1):
            rec(idx + 1, left - k, cur + [k])

    rec(0, n, [])
    return out


def astar_matrix(n):
    """Matrix M with M[b,a] = coeff of x^b in (A* x^a) = prod_i (A x)_i^{a_i}.

    (A x)_i = sum_j A[i,j] x_j, so (A* x^a) = prod_i (sum_j A[i,j] x_j)^{a_i}.
    Built by exact integer polynomial multiplication over the 8 variables.
    """
    monos = degree_monomials(n)
    index = {m: r for r, m in enumerate(monos)}

    # linear form L_i = sum_j A[i,j] x_j, as {exp-tuple: coeff}
    def lin(i):
        d = {}
        for j in range(8):
            e = [0] * 8
            e[j] = 1
            d[tuple(e)] = int(A[i, j])
        return d

    def mul(poly, lf):
        out = {}
        for e, c in poly.items():
            for ej, cj in lf.items():
                ne = tuple(e[k] + ej[k] for k in range(8))
                out[ne] = out.get(ne, 0) + c * cj
        return out

    M = np.zeros((len(monos), len(monos)), dtype=object)
    for a in monos:
        poly = {tuple([0] * 8): 1}
        for i in range(8):
            for _ in range(a[i]):
                poly = mul(poly, lin(i))
        ca = index[a]
        for e, c in poly.items():
            M[index[e], ca] = c
    return M, monos


def check(n):
    M, monos = astar_matrix(n)
    G = np.array([factorial_multi(m) for m in monos], dtype=object)  # diag of a!
    scale2 = 8 ** n  # (2^{3n/2})^2 = 8^n
    # M^T G M  (exact integer)
    MT = M.T
    GM = M * G[:, None]            # multiply row r by G[r]
    lhs = MT.dot(GM)              # = M^T diag(G) M
    rhs = np.zeros_like(lhs)
    for i in range(len(monos)):
        rhs[i, i] = scale2 * G[i]
    ortho_ok = np.array_equal(lhs, rhs)
    # involution M^2 = scale2 * I
    M2 = M.dot(M)
    invol_ok = all(M2[i, j] == (scale2 if i == j else 0)
                   for i in range(len(monos)) for j in range(len(monos)))
    print("n=%d : monomials=%d  scale^2=8^%d=%d" % (n, len(monos), n, scale2))
    print("   M^T G M == scale^2 G  (Fischer-orthogonal up to scale): %s" % ortho_ok)
    print("   M^2 == scale^2 I       (A*^2 = scale^2):                 %s" % invol_ok)
    return ortho_ok and invol_ok


def factorial_multi(m):
    f = 1
    for e in m:
        f *= factorial(e)
    return f


if __name__ == "__main__":
    sym = np.array_equal(A, A.T)
    a2 = A.dot(A)
    print("A symmetric: %s ;  A^2 == 8 I: %s" %
          (sym, np.array_equal(a2, 8 * np.eye(8, dtype=np.int64))))
    print()
    allok = True
    for n in (1, 2, 3, 4):
        allok &= check(n)
        print()
    print("ALL CHECKS PASS:" , allok)
