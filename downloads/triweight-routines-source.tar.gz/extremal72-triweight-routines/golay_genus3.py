#!/usr/bin/env python3
"""Compute the genus-3 enumerator of the extended Golay [24,12,8] code (the key
indecomposable Type II generator at length 24), validate it, and save it."""
import json
import time

import numpy as np

import triweight_lib as L
import codes as K


def main():
    C = K.golay24()
    M, n = C.shape
    print("Golay [24,12,8]: %d codewords, computing genus-3 enumerator (parallel)..." % M)
    t = time.time()
    enum = L.genus3_enum_parallel(C, verbose=True)
    dt = time.time() - t
    tot = sum(enum.values())
    print("  done in %.1fs; monomials=%d, total=%d = |C|^3=%d ? %s"
          % (dt, len(enum), tot, M ** 3, tot == M ** 3))

    ok_se, info = L.check_self_equation(enum, n, trials=4)
    print("  self-equation 2^{3n/2} T(x)=T(H^3 x):", ok_se, "" if ok_se else info)
    ok_g, info = L.check_G_invariance(enum)
    print("  order-48 G-invariance:", ok_g, "" if ok_g else info)

    g2 = L.genus2_marginal(enum, M)
    g1 = L.genus1_marginal(enum, M)
    print("  genus-2 marginal monomials:", len(g2), " genus-1 marginal:", sorted(g1.items()))

    # save (orbit-reduced JSON: list of [exptuple, coeff])
    out = {"code": "golay24 [24,12,8]", "n": n, "code_size": M,
           "self_equation": ok_se, "G_invariant": ok_g,
           "n_monomials": len(enum),
           "enumerator": [[list(k), v] for k, v in sorted(enum.items())]}
    with open("golay_genus3.json", "w") as fh:
        json.dump(out, fh)
    print("  wrote golay_genus3.json")


if __name__ == "__main__":
    main()
