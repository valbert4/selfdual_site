#!/usr/bin/env python3
"""
Genus-3 Gleason dimension D_3(n) for binary doubly-even self-dual codes, read
off from Runge's genus-3 Poincare series for the full modular group H_3
(= G_{3,1} in Bannai-Dougherty-Harada-Oura).

Reference: B. Runge, "On Siegel modular forms, Part II", Nagoya Math. J. 138
(1995) 179-197, Section 4 (in-repo:
../papers/on-siegel-modular-forms-part-ii/). The weight-graded series is

  Phi_{H_3}(lambda^{1/2}) = N_mod(lambda)*(1+lambda^2) / D(lambda),
  D(lambda) = (1-l^4)(1-l^8)(1-l^12)^2(1-l^14)(1-l^18)(1-l^20)(1-l^30),

with N_mod given explicitly below.  Here the exponent of lambda is the MODULAR
WEIGHT = (degree in the 8 theta variables)/2 = n/2 for a length-n code.

The binary doubly-even self-dual genus-3 enumerator ring is the invariant ring
of G^S_{3,1} = <H_3, eta_8>, i.e. the part of the H_3 ring in degrees divisible
by 8 (eta_8 scalar acts on degree d by eta_8^d).  For length n=72: degree 72,
weight 36, and 72 = 8*9 is divisible by 8, so the eta_8 restriction is automatic
and  D_3(72) = [lambda^36] Phi_{H_3}.
"""
NMAX = 60

def poly_mul(a, b, cap=NMAX):
    c = [0] * (cap + 1)
    for i, ai in enumerate(a):
        if ai == 0 or i > cap:
            continue
        for j, bj in enumerate(b):
            if i + j > cap:
                break
            c[i + j] += ai * bj
    return c

def as_list(terms, cap=NMAX):
    a = [0] * (cap + 1)
    for e, c in terms.items():
        if e <= cap:
            a[e] += c
    return a

# N_mod(lambda) transcribed verbatim from Runge Sec. 4 (line 168 of the .md).
N_mod = as_list({0: 1, 2: -1, 4: 1, 10: 1, 16: 3, 18: -1, 20: 3, 22: 2,
                 24: 2, 26: 3, 28: 4, 30: 2, 32: 7, 34: 3, 36: 7, 38: 5,
                 40: 9, 42: 6, 44: 10, 46: 8, 48: 10, 50: 9, 52: 12, 54: 7,
                 56: 14, 58: 7, 60: 12})  # capped at NMAX=60; enough for [l^36]

num = poly_mul(N_mod, as_list({0: 1, 2: 1}))

# denominator factors (1 - l^k)
den_factors = [4, 8, 12, 12, 14, 18, 20, 30]
den = [1] + [0] * NMAX
for k in den_factors:
    f = as_list({0: 1, k: -1})
    den = poly_mul(den, f)

# power series c = num/den via long division (den[0] = 1)
coeffs = [0] * (NMAX + 1)
for n in range(NMAX + 1):
    s = num[n] - sum(den[j] * coeffs[n - j] for j in range(1, n + 1))
    coeffs[n] = s  # den[0] = 1

# Verify against Runge's printed low-order terms:
#   Phi_{H_3} = 1 + l^4 + l^6 + 2 l^8 + 2 l^10 + 5 l^12 + 4 l^14 + ...
expected = {0: 1, 4: 1, 6: 1, 8: 2, 10: 2, 12: 5, 14: 4}
ok = all(coeffs[w] == v for w, v in expected.items())
print("low-order check vs Runge (1, l^4, l^6, 2 l^8, 2 l^10, 5 l^12, 4 l^14):", ok)
print()
print("weight-graded Phi_{H_3} coefficients (weight w  ->  dim, length n=2w):")
for w in range(0, NMAX + 1, 2):
    n = 2 * w
    star = "   <-- length 72" if n == 72 else ("  (8|n)" if n % 8 == 0 else "")
    print("  w=%2d  n=%2d : dim = %d%s" % (w, n, coeffs[w], star))
print()
print("=> D_3(72) = dim of genus-3 weight enumerators of length-72")
print("   doubly-even self-dual codes = [lambda^36] Phi_{H_3} =", coeffs[36])
