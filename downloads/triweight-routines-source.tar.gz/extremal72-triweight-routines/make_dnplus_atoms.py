#!/usr/bin/env python3
"""Emit closed-form d_n^+ genus-3 enumerators as single-atom basis json files,
in exactly the format span72_eval_rank.load_basis expects.

Each d_n^+ is ONE genus-3 invariant (a single atom).  Its coefficients are
constant on the order-48 group orbits (translations + S_3), so we group its
monomials into GROUP48 orbits, assert the coefficient is constant per orbit,
and write {orbit_reps, basis:[vec]} with one coefficient per orbit.

Run (needs numpy):
  /usr/bin/python3 make_dnplus_atoms.py --p 13 --ns 8,16,24,32,40,48,56,64,72
Writes  n{n}_dnplus_p{p}.json.gz  in the current directory.
"""
import argparse
import gzip
import json
import os

import triweight_lib as L
from dnplus import dnplus_genus3_modp

GROUP48 = L.GROUP48


def orbit_of(mono):
    """Set of GROUP48 images of a monomial exponent tuple (index permutation)."""
    return {tuple(mono[perm[i]] for i in range(8)) for perm in GROUP48}


def dnplus_atom_json(n, p):
    """Return the json payload for d_n^+ as a single-atom basis file."""
    enum = dnplus_genus3_modp(n, p)            # {exptuple: coeff_mod_p}
    seen = {}                                  # canonical rep -> coeff
    reps = []
    coeffs = []
    for mono, c in enum.items():
        orb = orbit_of(mono)
        rep = min(orb)
        if rep in seen:
            # constant-on-orbit certificate
            if seen[rep] != c % p:
                raise ValueError(
                    "d_%d^+ not constant on GROUP48 orbit: rep=%s saw %d and %d"
                    % (n, rep, seen[rep], c % p))
            continue
        # verify every image present in enum carries the same coeff
        for img in orb:
            ic = enum.get(img, 0) % p
            if ic != c % p:
                raise ValueError(
                    "d_%d^+ orbit member mismatch: rep=%s member=%s %d vs %d"
                    % (n, rep, img, ic, c % p))
        seen[rep] = c % p
        reps.append(list(rep))
        coeffs.append(c % p)
    return {
        "format": "dnplus_atom_v1",
        "n": int(n),
        "p": int(p),
        "support_rows": 0,
        "orbit_cols": len(reps),
        "nnz": int(sum(1 for c in coeffs if c)),
        "rank": 1,
        "nullity": 1,
        "orbit_reps": reps,
        "basis": [coeffs],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--p", type=int, default=13)
    ap.add_argument("--ns", default="8,16,24,32,40,48,56,64,72")
    ap.add_argument("--out-dir", default="matrices")
    args = ap.parse_args()
    ns = [int(x) for x in args.ns.split(",") if x.strip()]
    for n in ns:
        payload = dnplus_atom_json(n, args.p)
        path = os.path.join(args.out_dir, "n%d_dnplus_p%d.json.gz" % (n, args.p))
        with gzip.open(path, "wt") as fh:
            json.dump(payload, fh, separators=(",", ":"))
        total = sum(c for c in payload["basis"][0]) % args.p
        print("wrote %s : orbits=%d  (sum of orbit coeffs mod p = %d)"
              % (path, payload["orbit_cols"], total), flush=True)


if __name__ == "__main__":
    main()
