#!/usr/bin/env python3
"""Priority 2: marginal short-circuit on the cheap degree-72 product span S.

Question: does the one [72,36,16] triweight already live inside the cheap span
S = span of products of {self-eq bases n<=32, closed-form d_n^+} (rank 90 / 152)?

The binding constraints on the triweight T are (SCOPE sec 0):
  (inv)  T is a genus-3 self-dual invariant  -- automatic since T in S;
  (md)   minimum distance 16: every coefficient on a doubly-even orbit that is
         NOT in the min-distance-allowed table (triweight_orbits.npz, Gleason
         subset-weights) must vanish;
  (g1)   genus-1 marginal = the unique extremal Gleason enumerator;
  (g2)   genus-2 marginal = the unique biweight -- but the genus-2 self-dual
         invariant space at degree 72 is 1-dimensional, so (g2) is implied by
         (g1) for genuine invariants and adds nothing here;
  (pos)  N(n) >= 0 and integral.

STAGE A (this script, mod p, fast): compute, over GF(p),
  d_md    = dim { a in S : (md) holds }                      (homogeneous)
  d_final = dim { a in S : (md) and (g1) hold }              (affine; consistency)
reported for p = 13 and 17.  Interpretation:
  d_md = 0           -> S contains no min-distance-16 invariant: the triweight is
                        NOT in the cheap span; the short-circuit fails (need n=48).
  (g1) inconsistent  -> same conclusion.
  d_final >= 1       -> a candidate family of dim d_final lives in S; go to
                        Stage B (exact reconstruction + positivity LP).

It also caches the expanded basis (orbit-coordinate coefficient matrix, the
allowed/disallowed split, and the genus-1 marginal rows) to an .npz per prime so
Stage B can reconstruct exactly without re-expanding.
"""
import argparse
import os
import time

import numpy as np

import triweight_lib as L
import triweight_orbits as TO
from selfeq_nullity import gfp_rank
from span72_eval_rank import (load_basis, default_basis_path, product_multisets,
                              eval_atom, build_eval_matrix, random_points,
                              nonsquare_mod)

# Unique extremal Type II [72,36,16] genus-1 (Gleason) weight enumerator.
GLEASON = {
    0: 1, 16: 249849, 20: 18106704, 24: 462962955, 28: 4397342400,
    32: 16602715899, 36: 25756721120, 40: 16602715899, 44: 4397342400,
    48: 462962955, 52: 18106704, 56: 249849, 72: 1,
}
CODE_SIZE = 1 << 36
POW = (128 ** np.arange(8)).astype(np.int64)


def atom_arrays(atom, p):
    """Full monomial (keys, coeffs mod p) for one atom, expanding orbit reps to
    all 48 group images."""
    keys = []
    coeffs = []
    for c, imgs in atom["coeffs"]:
        c %= p
        if not c:
            continue
        for e in imgs:
            keys.append(sum(int(e[i]) * int(POW[i]) for i in range(8)))
            coeffs.append(c)
    return (np.array(keys, dtype=np.int64), np.array(coeffs, dtype=np.int64))


def _reduce(k, c, p):
    u, inv = np.unique(k, return_inverse=True)
    agg = np.zeros(u.shape[0], dtype=np.int64)
    np.add.at(agg, inv, c % p)
    agg %= p
    keep = agg != 0
    return u[keep], agg[keep]


def poly_mul(k1, c1, k2, c2, p, cap=40_000_000):
    """Multiply two sparse polys mod p, bounding the peak intermediate to ~cap
    cross-terms by chunking over the smaller operand (avoids OOM when both
    operands are large)."""
    if k1.size > k2.size:           # iterate over the smaller operand
        k1, c1, k2, c2 = k2, c2, k1, c1
    # now k1 is smaller; chunk k2 so that k1.size * chunk <= cap
    chunk = max(1, cap // max(1, k1.size))
    acc_k = np.empty(0, dtype=np.int64)
    acc_c = np.empty(0, dtype=np.int64)
    for s in range(0, k2.size, chunk):
        bk = k2[s:s + chunk]
        bc = c2[s:s + chunk]
        nk = (k1[:, None] + bk[None, :]).ravel()
        nc = (c1[:, None] * bc[None, :]).ravel() % p
        rk, rc = _reduce(nk, nc, p)
        acc_k = np.concatenate([acc_k, rk])
        acc_c = np.concatenate([acc_c, rc])
        acc_k, acc_c = _reduce(acc_k, acc_c, p)
    return acc_k, acc_c


def expand_product(prod, atom_arr, p):
    """Multiply the atom monomial arrays for a product (tuple of atom indices),
    smallest factors first to keep the running product compact."""
    order = sorted(prod, key=lambda i: atom_arr[i][0].size)
    k = np.array([0], dtype=np.int64)
    c = np.array([1], dtype=np.int64)
    for i in order:
        ak, ac = atom_arr[i]
        k, c = poly_mul(k, c, ak, ac, p)
    return k, c


def product_cost(prod, sizes, cap=3_500_000):
    """Heuristic expansion cost: sum of running*next pair counts, smallest factors
    first, running size capped by the degree-72 support.  Used to choose a
    minimum-cost basis of the span so dense x dense products are avoided."""
    s = sorted(sizes[i] for i in prod)
    run = s[0]
    tot = 0
    for x in s[1:]:
        tot += run * x
        run = min(run * x, cap)
    return tot


def decode(keys):
    """(M,) base-128 keys -> (M,8) exponent array."""
    M = keys.shape[0]
    e = np.empty((M, 8), dtype=np.int64)
    rem = keys.copy()
    for i in range(8):
        e[:, i] = rem % 128
        rem //= 128
    return e


def genus1_marginal_from_monos(keys, coeffs, p):
    """Genus-1 marginal {u-weight: coeff mod p} from full monomials.
    u-weight = sum of exponents on odd indices p=1,3,5,7 (a-bit set)."""
    e = decode(keys)
    w = e[:, 1] + e[:, 3] + e[:, 5] + e[:, 7]
    marg = np.zeros(73, dtype=np.int64)
    np.add.at(marg, w, coeffs % p)
    return marg % p


def fold_to_orbits(keys, coeffs, p):
    """Canon-fold full monomials to orbit coefficients: returns dict canonkey->coeff."""
    e = decode(keys)
    ce = TO.canon_array(e)
    ck = (ce.astype(np.int64) * POW[None, :]).sum(axis=1)
    u, inv = np.unique(ck, return_inverse=True)
    agg = np.zeros(u.shape[0], dtype=np.int64)
    np.add.at(agg, inv, coeffs % p)
    agg %= p
    return u, agg


def _eliminate_columns(M, p, ncoef):
    """Column-outer Gauss-Jordan over GF(p), vectorized over ALL rows.
    Reduces the first `ncoef` columns of M (which may carry extra RHS columns).
    Returns (rank, pivot_columns, reduced M)."""
    M = (M % p).astype(np.int64)
    nr, _ = M.shape
    row = 0
    pivots = []
    for col in range(ncoef):
        sub = M[row:, col] % p
        nz = np.nonzero(sub)[0]
        if nz.size == 0:
            continue
        piv = row + int(nz[0])
        if piv != row:
            M[[row, piv]] = M[[piv, row]]
        inv = pow(int(M[row, col]), p - 2, p)
        M[row] = (M[row] * inv) % p
        factor = M[:, col].copy()
        factor[row] = 0
        if factor.any():
            M = (M - np.outer(factor, M[row])) % p
        pivots.append(col)
        row += 1
        if row == nr:
            break
    return row, pivots, M


def gfp_rank_fast(A, p):
    if A.shape[0] == 0 or A.shape[1] == 0:
        return 0
    rank, _, _ = _eliminate_columns(A, p, A.shape[1])
    return rank


def gfp_solve(A, b, p):
    """Solve A a = b over GF(p).  Returns (consistent, rankA, soldim)."""
    m, n = A.shape
    M = np.concatenate([A % p, (b % p).reshape(m, 1)], axis=1)
    rank, _, R = _eliminate_columns(M, p, n)
    # consistency: a reduced row with zero coefficients but nonzero RHS
    zero_coef = ~(R[:, :n] % p).any(axis=1)
    consistent = not bool((zero_coef & (R[:, n] % p != 0)).any())
    soldim = (n - rank) if consistent else None
    return consistent, rank, soldim


def gfp_pivot_columns(A, p):
    """Pivot column indices of A over GF(p)."""
    _, pivots, _ = _eliminate_columns(A, p, A.shape[1])
    return pivots


def run(p, atom_specs, basis_dir, points, seed, cache=None):
    t0 = time.time()
    # ---- load atoms ----
    atoms = []
    for kind, val in atom_specs:
        if kind == "basis":
            path = default_basis_path(basis_dir, val, p)
            file_atoms = load_basis(path, p)
        else:
            fname = val % p if "%d" in val else val
            path = os.path.join(basis_dir, fname)
            file_atoms = load_basis(path, p)
        atoms.extend(file_atoms)
    atoms = [a for a in atoms if a["degree"] <= 9]
    print("[p=%d] atoms=%d  degrees=%s" %
          (p, len(atoms), {d: sum(1 for a in atoms if a["degree"] == d)
                           for d in sorted({a["degree"] for a in atoms})}), flush=True)

    products = product_multisets(atoms, 9)
    print("[p=%d] degree-72 products: %d" % (p, len(products)), flush=True)

    # ---- atom monomial arrays + sizes (for cost-aware selection) ----
    atom_arr = [atom_arrays(a, p) for a in atoms]
    sizes = [ak.size for ak, _ in atom_arr]

    # ---- evaluate all products cheaply, then pick a MINIMUM-COST basis ----
    nonsq = nonsquare_mod(p)
    pts = random_points(points, p, seed, 2)
    atom_vals = np.stack([eval_atom(a, pts, p, 2, nonsq) for a in atoms])
    E = build_eval_matrix(atom_vals, products, p, 2, nonsq) % p
    rankS = gfp_rank_fast(E, p)

    order = sorted(range(len(products)), key=lambda c: product_cost(products[c], sizes))
    basis = []          # list of (pivot_index, normalized reduced vector)
    pivcols = []
    for c in order:
        v = E[:, c].astype(np.int64) % p
        for piv, row in basis:
            if v[piv]:
                v = (v - v[piv] * row) % p
        nz = np.nonzero(v)[0]
        if nz.size == 0:
            continue
        piv = int(nz[0])
        v = (v * pow(int(v[piv]), p - 2, p)) % p
        basis.append((piv, v))
        pivcols.append(c)
        if len(pivcols) == rankS:
            break
    pivot_products = [products[c] for c in pivcols]
    maxcost = max(product_cost(pp, sizes) for pp in pivot_products)
    print("[p=%d] span rank = %d ; selected %d min-cost pivot products "
          "(max cost %.2e)  [%.1fs]" % (p, rankS, len(pivcols), maxcost, time.time() - t0),
          flush=True)

    # ---- expand pivots; fold to orbits; collect genus-1 marginals ----
    allowed_index, _, _ = TO.load_table()
    allowed_keys = set(int((np.array(r, dtype=np.int64) * POW).sum()) for r in allowed_index)

    col_dicts = []          # list of {canonkey: coeff}
    g1_rows = []            # genus-1 marginal vectors (73,)
    all_keys = set()
    for idx, prod in enumerate(pivot_products):
        k, c = expand_product(prod, atom_arr, p)
        g1_rows.append(genus1_marginal_from_monos(k, c, p))
        u, agg = fold_to_orbits(k, c, p)
        d = {int(uk): int(av) for uk, av in zip(u.tolist(), agg.tolist()) if av}
        col_dicts.append(d)
        all_keys.update(d.keys())
        if (idx + 1) % 10 == 0 or idx + 1 == len(pivot_products):
            print("[p=%d]  expanded %d/%d pivots  (orbit-keys so far %d)  [%.1fs]" %
                  (p, idx + 1, len(pivot_products), len(all_keys), time.time() - t0), flush=True)

    ncol = len(col_dicts)
    keylist = sorted(all_keys)
    kpos = {kk: i for i, kk in enumerate(keylist)}
    disallowed = [kk for kk in keylist if kk not in allowed_keys]
    print("[p=%d] orbit-keys used=%d  allowed=%d  disallowed=%d" %
          (p, len(keylist), len(keylist) - len(disallowed), len(disallowed)), flush=True)

    # ---- B matrix (orbits x ncol) ----
    B = np.zeros((len(keylist), ncol), dtype=np.int64)
    for j, d in enumerate(col_dicts):
        for kk, v in d.items():
            B[kpos[kk], j] = v % p

    # ---- (md) constraint: disallowed rows must vanish ----
    dis_idx = [kpos[kk] for kk in disallowed]
    D = B[dis_idx, :] if dis_idx else np.zeros((0, ncol), dtype=np.int64)
    rank_D = gfp_rank_fast(D, p) if D.shape[0] else 0
    d_md = ncol - rank_D
    print("[p=%d] (md) min-distance: disallowed-rows rank=%d  =>  d_md = %d" %
          (p, rank_D, d_md), flush=True)

    # ---- (g1) genus-1 marginal target ----
    G1 = np.stack(g1_rows, axis=1)          # (73, ncol)
    fac = pow(2, 72, p)                     # |C|^2 = 2^72
    target = np.zeros(73, dtype=np.int64)
    for w, a in GLEASON.items():
        target[w] = (fac * (a % p)) % p

    # combined system: [D ; G1] a = [0 ; target]
    A_full = np.concatenate([D, G1], axis=0)
    b_full = np.concatenate([np.zeros(D.shape[0], dtype=np.int64), target], axis=0)
    consistent, rank_full, soldim = gfp_solve(A_full, b_full, p)
    print("[p=%d] (md)+(g1): consistent=%s  rank=%d  d_final=%s  [%.1fs]" %
          (p, consistent, rank_full, soldim, time.time() - t0), flush=True)

    if cache:
        np.savez_compressed(cache, p=p, B=B, keylist=np.array(keylist, dtype=np.int64),
                            dis_idx=np.array(dis_idx, dtype=np.int64),
                            G1=G1, target=target,
                            pivot_products=np.array([list(pp) for pp in pivot_products], dtype=object))
        print("[p=%d] cached -> %s" % (p, cache), flush=True)

    return {"p": p, "rankS": rankS, "d_md": d_md, "g1_consistent": consistent,
            "d_final": soldim}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--primes", default="13,17")
    ap.add_argument("--points", type=int, default=400)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--basis-dir", default="matrices")
    ap.add_argument("--cache-prefix", default="msc_stageA")
    args = ap.parse_args()

    # atom set: deg-8 from exact d_8^+, self-eq bases 16/24/32, and d_n^+ 40..72
    atom_specs = [
        ("file", "n8_dnplus_p%d.json.gz"),
        ("basis", 16), ("basis", 24), ("basis", 32),
        ("file", "n40_dnplus_p%d.json.gz"),
        ("file", "n48_dnplus_p%d.json.gz"),
        ("file", "n56_dnplus_p%d.json.gz"),
        ("file", "n64_dnplus_p%d.json.gz"),
        ("file", "n72_dnplus_p%d.json.gz"),
    ]
    results = []
    for p in [int(x) for x in args.primes.split(",") if x.strip()]:
        cache = "%s_p%d.npz" % (args.cache_prefix, p)
        results.append(run(p, atom_specs, args.basis_dir, args.points, args.seed, cache=cache))
    print("\n==== SUMMARY (marginal short-circuit, Stage A) ====")
    for r in results:
        print("  p=%2d : span=%d  d_md=%d  g1_consistent=%s  d_final=%s" %
              (r["p"], r["rankS"], r["d_md"], r["g1_consistent"], r["d_final"]))
    dmds = {r["d_md"] for r in results}
    dfs = {str(r["d_final"]) for r in results}
    print("\nINTERPRETATION:")
    if dmds == {0}:
        print("  d_md = 0 on all primes: the cheap span contains NO min-distance-16")
        print("  invariant. The [72,36,16] triweight is NOT in the cheap product span;")
        print("  the marginal short-circuit fails here -- need higher generators (n=48).")
    elif all(r["d_final"] == 0 and r["g1_consistent"] for r in results):
        print("  Unique candidate triweight in the cheap span (d_final=0, g1 consistent).")
        print("  -> Stage B: reconstruct exactly and test integrality + nonnegativity.")
    elif any((r["d_final"] or 0) >= 1 for r in results):
        print("  A candidate family lives in the cheap span (d_final>=1).")
        print("  -> Stage B: positivity/integrality LP over the residual family.")
    else:
        print("  genus-1 marginal inconsistent in the span on at least one prime:")
        print("  the triweight is NOT in the cheap span (need higher generators).")


if __name__ == "__main__":
    main()
