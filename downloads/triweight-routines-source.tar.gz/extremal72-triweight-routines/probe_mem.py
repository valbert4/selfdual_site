#!/usr/bin/env python3
"""Measure per-worker peak RSS + time for the A* eval at a given degree, on the
HEAVIEST AGL orbits (worst case for memory), so we can size the worker pool to
stay under a RAM budget.

  /usr/bin/python3 probe_mem.py <n> [--p 13] [--sample 10]
Each sampled orbit runs in its own subprocess; we report max peak RSS + time.
"""
import argparse
import os
import resource
import subprocess
import sys
import time

import numpy as np

import bench_agl_parallel as B
import factored_hadamard as FH


def heaviest_reps(n, sample):
    supp = B.load_support(n)
    arr = np.array(supp, dtype=np.int64)
    acan = B.canon_keys(arr, B.AGL_PERMS)
    seen = {}
    for i, k in enumerate(acan.tolist()):
        if k not in seen:
            seen[k] = i
    reps = [tuple(int(x) for x in arr[i]) for i in seen.values()]
    # heuristic "heaviness": many nonzero coords, balanced (small max), more 2s.
    def score(r):
        nz = sum(1 for x in r if x)
        return (nz, -max(r), sum(1 for x in r if x and x % 4 != 0))
    reps.sort(key=score, reverse=True)
    return reps[:sample], len(seen)


def measure_one(n, p, rep):
    """Run one A* eval in this process; return (seconds, peak_rss_kb, nterms)."""
    t0 = time.time()
    base = FH.apply_A_star_translation_even({rep: 1}, mod=p)
    dt = time.time() - t0
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return dt, rss, len(base)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("n", type=int)
    ap.add_argument("--p", type=int, default=13)
    ap.add_argument("--sample", type=int, default=10)
    ap.add_argument("--rep", default=None, help="(internal) single rep as comma-list")
    args = ap.parse_args()

    if args.rep is not None:
        rep = tuple(int(x) for x in args.rep.split(","))
        dt, rss, nt = measure_one(args.n, args.p, rep)
        print("%.2f %d %d" % (dt, rss, nt))
        return

    reps, norb = heaviest_reps(args.n, args.sample)
    print("n=%d p=%d  AGL orbits=%d  probing %d heaviest..." % (args.n, args.p, norb, len(reps)), flush=True)
    worst_rss = 0; worst_t = 0.0
    for r in reps:
        out = subprocess.run([sys.executable, __file__, str(args.n), "--p", str(args.p),
                              "--rep", ",".join(str(x) for x in r)],
                             capture_output=True, text=True, env={**os.environ, "PYTHONPATH": "."})
        if out.returncode != 0:
            print("  rep %s FAILED: %s" % (r, out.stderr.strip()[-200:]), flush=True)
            continue
        dt, rss, nt = out.stdout.split()
        dt = float(dt); rss = int(rss); nt = int(nt)
        worst_rss = max(worst_rss, rss); worst_t = max(worst_t, dt)
        print("  rep=%-28s  t=%6.1fs  peakRSS=%5.2f GB  terms=%d"
              % (str(r), dt, rss / 1e6, nt), flush=True)
    print("\nWORST: peakRSS=%.2f GB  time=%.1fs per orbit" % (worst_rss / 1e6, worst_t), flush=True)
    budget = 56.0   # GB usable (under the 64 GB cap, with margin for the main proc + OS)
    per = max(0.2, worst_rss / 1e6)
    safe_workers = max(1, min(28, int(budget / per)))
    print("RAM-safe workers for one pool (budget %.0f GB): %d  (worst %.2f GB/worker)"
          % (budget, safe_workers, per), flush=True)


if __name__ == "__main__":
    main()
