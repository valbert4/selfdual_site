#!/usr/bin/env python3
"""
Genus-3 self-equation null-space dimension at small length n (Method B at small
scale), to validate the Hilbert-series dimensions D_3(n) from hilbert_genus3.py
(expect 1, 2, 5 for n = 8, 16, 24) and the self-equation machinery itself.

A doubly-even self-dual genus-3 enumerator's coefficient vector c (over the
degree-n support) satisfies the genus-3 MacWilliams self-equation
    sum_m c_m [ (TX)^m - 2^{3n/2} x^m ] = 0,    (TX)_p = sum_q (-1)^{<p,q>} x_q.
Its solution space has dimension D_3(n).  We build the matrix over GF(p) and
report the nullity.

Support at length n: 8-tuples (n_p) summing to n with all 7 nonempty
subset-weights divisible by 4 (doubly-even) and the 3 pairwise inner products
even (self-orthogonal).
"""
import sys
from itertools import product as iproduct

import numpy as np

SIGN = np.empty((8, 8), dtype=np.int64)
for p in range(8):
    for q in range(8):
        SIGN[p, q] = -1 if bin(p & q).count('1') % 2 else 1

# subset-weight functionals: for nonempty S in 1..7, w_S = sum_p [<p,S> odd] n_p
def subset_weight(nvec, S):
    return sum(nvec[p] for p in range(8) if bin(p & S).count('1') % 2)

PAIRS = [(3, 7), (5, 7), (6, 7)]  # <u,v>=n110+n111 etc.


def support(n):
    mons = []
    # enumerate 8-tuples summing to n via the Hadamard parametrization would be
    # faster, but a direct bounded nested enumeration is fine for small n.
    for nv in _compositions(n, 8):
        if any(subset_weight(nv, S) % 4 for S in range(1, 8)):
            continue
        if any((nv[i] + nv[j]) % 2 for (i, j) in PAIRS):
            continue
        mons.append(nv)
    return mons


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for first in range(n + 1):
        for rest in _compositions(n - first, k - 1):
            yield (first,) + rest


def linform(p):
    """(TX)_p as dict { (e0..e7) : coeff } -- a single linear form."""
    d = {}
    for q in range(8):
        e = [0] * 8
        e[q] = 1
        d[tuple(e)] = int(SIGN[p, q])
    return d


LF = [linform(p) for p in range(8)]


def poly_mul(a, b):
    out = {}
    for ea, ca in a.items():
        for eb, cb in b.items():
            e = tuple(ea[i] + eb[i] for i in range(8))
            out[e] = out.get(e, 0) + ca * cb
    return out


def TXpow(m):
    """(TX)^m as a coefficient dict."""
    poly = {(0,) * 8: 1}
    for p in range(8):
        for _ in range(m[p]):
            poly = poly_mul(poly, LF[p])
    return poly


def nullity_at(n, primes=(1000003, 1000033)):
    mons = support(n)
    col_index = {m: j for j, m in enumerate(mons)}
    scale = 1 << (3 * n // 2)
    # build columns: for each support m, coeffs of [(TX)^m - 2^{3n/2} x^m]
    cols = []
    rowset = {}
    for m in mons:
        d = TXpow(m)
        d[m] = d.get(m, 0) - scale
        cols.append(d)
        for e in d:
            if e not in rowset:
                rowset[e] = len(rowset)
    nrows, ncols = len(rowset), len(mons)
    nulls = []
    for p in primes:
        A = np.zeros((nrows, ncols), dtype=np.int64)
        for j, d in enumerate(cols):
            for e, c in d.items():
                A[rowset[e], j] = c % p
        rank = gfp_rank(A, p)
        nulls.append(ncols - rank)
    return ncols, nrows, nulls


def gfp_rank(A, p):
    """Rank of integer matrix A over GF(p) by Gaussian elimination."""
    A = (A % p).astype(np.int64).copy()
    nr, nc = A.shape
    rank = 0
    row = 0
    for col in range(nc):
        piv = -1
        for r in range(row, nr):
            if A[r, col] % p:
                piv = r
                break
        if piv < 0:
            continue
        A[[row, piv]] = A[[piv, row]]
        inv = pow(int(A[row, col]), p - 2, p)
        A[row] = (A[row] * inv) % p
        for r in range(nr):
            if r != row and A[r, col]:
                A[r] = (A[r] - A[r, col] * A[row]) % p
        row += 1
        rank += 1
        if row == nr:
            break
    return rank


def main():
    ns = [int(x) for x in sys.argv[1:]] or [8, 16]
    expect = {8: 1, 16: 2, 24: 5}
    for n in ns:
        ncols, nrows, nulls = nullity_at(n)
        exp = expect.get(n, "?")
        ok = all(x == nulls[0] for x in nulls) and (exp == "?" or nulls[0] == exp)
        print("n=%2d : support=%d rows=%d  nullity=%s  (expect D_3(%d)=%s)  %s"
              % (n, ncols, nrows, nulls, n, exp, "OK" if ok else "MISMATCH"))


if __name__ == "__main__":
    main()
