#!/usr/bin/env sage
"""
Genus-3 invariant space at length n = self-equation null space, built with the
FAST factored Hadamard engine (factored_hadamard.apply_A_star), affine symmetry
transport for orbit columns, and Sage's sparse GF(p) rank.  nullity = D_3(n)
(1,2,5,9,16,31,53,89,152 for n=8..72).

Formulation (orbit-COLUMN, full-row -- correct & column-reduced; see
FACTORED_HADAMARD.md sec 3):
  variable c_o per G-orbit o of the support;  T = sum_o c_o (sum_{m in o} x^m).
  Orbit-column polynomial  Q_o = A*( sum_{m in o} x^m ) - scale * sum_{m in o} x^m,
  scale = 2^{3n/2}.  Rows = every monomial mu appearing in any Q_o.  Then
     sum_o c_o Q_o = A*(T) - scale*T = 0   <=>   T invariant,
  so nullity of the (rows x orbits) matrix = D_3(n).  Rows are NOT orbit-reduced
  (A* does not commute with the (Z/2)^3 translations, only with S_3), which is
  why the orbit-column / full-row split is the correct one.

Run:  sage selfeq_nullspace.sage 8 16 24        (validate 1,2,5)
      sage selfeq_nullspace.sage --primes 13 24 (single-prime scaling probe)
      sage selfeq_nullspace.sage 32             (D_3(32)=9; the first real test)
"""
import os
import re
import subprocess
import sys
import tempfile
import gzip
import json
from builtins import int as py_int
from itertools import permutations, product as iproduct
import factored_hadamard as FH

PRIMES = [13, 17]   # small good primes (13,17 do not divide |G_3|=7.4e8); mod-p
                    # coefficient vanishing sparsifies the dense corner expansions,
                    # making the pure-Python factored engine fast. nullity is
                    # char-independent for good primes (non-modular); cross-checked.
D3 = {8:1, 16:2, 24:5, 32:9, 40:16, 48:31, 56:53, 64:89, 72:152}

# order-48 group as permutations of the 8 indices (same convention as triweight_lib)
def affine_perm(axis, flip):
    perm = [0]*8
    for v in iproduct([0,1], repeat=3):
        # NB: in Sage '^' is exponentiation, so use (a+b)%2 for bit-XOR
        w = ((v[axis[0]]+flip[0])%2, (v[axis[1]]+flip[1])%2, (v[axis[2]]+flip[2])%2)
        perm[v[0]+2*v[1]+4*v[2]] = w[0]+2*w[1]+4*w[2]
    return tuple(perm)

def build_group():
    perms = set()
    for axis in permutations(range(3)):
        for flip in iproduct([0,1], repeat=3):
            perms.add(affine_perm(axis, flip))
    return [list(p) for p in perms]
GROUP = build_group()
AXIS_PERMS = [affine_perm(axis, (0,0,0)) for axis in permutations(range(3))]
BIT_SUPPORTS = [[q for q in range(8) if q & (1 << k)] for k in range(3)]
KEY_SHIFTS = [7*i for i in range(8)]      # n <= 72, so base 128 is collision-free.

def canon(t):
    return min(tuple(t[p[i]] for i in range(8)) for p in GROUP)

def key(t):
    return sum(t[i] << KEY_SHIFTS[i] for i in range(8))

def perm_key(t, perm):
    return sum(t[perm[i]] << KEY_SHIFTS[i] for i in range(8))

# support: 8-tuples summing to n, doubly-even (7 subset-weights divisible by 4)
# and self-orthogonal (pairwise inner products even), via Hadamard parametrization
def sgn(a, b):
    return -1 if bin(a & b).count('1') % 2 else 1
def support(n):
    WS = list(range(0, n+1, 4))
    out = set()
    for tup in iproduct(WS, repeat=7):
        h = [n] + [n - 2*w for w in tup]
        nv = []; ok = True
        for p in range(8):
            v = sum(sgn(p, S)*h[S] for S in range(8))
            if v % 8 or v < 0: ok = False; break
            nv.append(v//8)
        if not ok: continue
        if (nv[3]+nv[7]) % 2 or (nv[5]+nv[7]) % 2 or (nv[6]+nv[7]) % 2: continue
        out.add(tuple(nv))
    return sorted(out)

def orbit_reps(n):
    """Column order used by the support-transform engine: first occurrence of
    each canonical support orbit while scanning lexicographically sorted support."""
    reps = []
    seen = set()
    for m in support(n):
        r = canon(m)
        if r not in seen:
            seen.add(r)
            reps.append(r)
    return reps

def translation_even(mu):
    """Whether the sum over the (Z/2)^3 translation part survives.

    For F(v)=v+b, A*(x^{m o F}) is obtained from A*(x^m) by the diagonal sign
    x_q -> (-1)^{b.q} x_q. Summing all 8 translations kills output monomials
    whose three bit-parity sums are not all even.
    """
    return all(sum(mu[q] for q in qs) % 2 == 0 for qs in BIT_SUPPORTS)

def orbit_column(rep, members, n, p):
    """Column for A*(sum_{m in orbit} x^m) - scale*sum_{m in orbit} x^m.

    Compute A*(x^rep) once.  The full affine group sum repeats each unique orbit
    member |Stab(rep)| times; multiplying by |orbit|/48 converts the group sum
    back to the unique-member orbit column.  Translation signs are summed
    analytically, leaving only translation-even output rows and the six S_3 axis
    permutations.  This is the same full-row system as the direct member-by-member
    build, just much cheaper.
    """
    pp = int(p)
    scale = pow(2, 3*n//2, pp)
    group_inv = pow(len(GROUP), pp-2, pp)
    factor = (len(members) * group_inv) % pp
    translate_sum = 8 % pp
    col = {}
    base = FH.apply_A_star_translation_even({rep: 1}, mod=pp)
    for mu, v in base.items():
        vv = (v * translate_sum * factor) % pp
        if vv == 0:
            continue
        for perm in AXIS_PERMS:
            kk = perm_key(mu, perm)
            col[kk] = (col.get(kk, 0) + vv) % pp
    for m in members:
        kk = key(m)
        col[kk] = (col.get(kk, 0) - scale) % pp
    return {kk: v for kk, v in col.items() if v % pp}

def nullity(n, p, verbose=True, progress_every=None):
    import time
    t0 = time.time()
    supp = support(n)
    # orbit columns
    orb_of = {}; orbits = []
    for m in supp:
        r = canon(m)
        if r not in orb_of:
            orb_of[r] = len(orbits); orbits.append([])
        orbits[orb_of[r]].append(m)
    ncol = len(orbits)
    if progress_every is None and n >= 24:
        progress_every = max(1, ncol // 10)
    row_id = {}
    entries = {}   # {(row,col): val}
    for o in range(ncol):
        rep = canon(orbits[o][0])
        col = orbit_column(rep, orbits[o], n, p)
        for mu, v in col.items():
            if v % p == 0: continue
            r = row_id.setdefault(mu, len(row_id))
            entries[(r, o)] = v % p
        if verbose and progress_every and (o+1) % progress_every == 0:
            print("    n=%d p=%d : orbit-column %d/%d, rows=%d, nnz=%d, elapsed=%.1fs" %
                  (n, p, o+1, ncol, len(row_id), len(entries), time.time()-t0), flush=True)
    nrow = len(row_id)
    t_build = time.time() - t0
    M = matrix(GF(p), nrow, ncol, entries, sparse=True)   # fast bulk constructor
    t1 = time.time()
    rk = M.rank()
    t_rank = time.time() - t1
    if verbose:
        print("  n=%d p=%d : orbit-cols=%d rows=%d nnz=%d rank=%d NULLITY=%d  (build %.1fs, rank %.1fs)"
              % (n, p, ncol, nrow, len(entries), rk, ncol-rk, t_build, t_rank), flush=True)
    return ncol - rk

def compile_support_transform(verbose=True):
    here = os.path.dirname(os.path.abspath(__file__))
    src = os.path.join(here, "support_transform.cpp")
    exe = os.path.join(here, "support_transform")
    needs = (not os.path.exists(exe)) or (os.path.getmtime(exe) < os.path.getmtime(src))
    if needs:
        cmd = ["g++", "-O3", "-std=c++17", "-march=native", "-pipe", src, "-o", exe]
        if verbose:
            print("  compiling support_transform: %s" % " ".join(cmd), flush=True)
        subprocess.check_call(cmd)
    return exe

def write_basis_json(path, n, p, nrow, ncol, nnz, rank, basis, reps):
    def to_int(x):
        if hasattr(x, "lift"):
            x = x.lift()
        return py_int(x)
    payload = {
        "format": "triweight selfeq support-row right-kernel basis over GF(p)",
        "n": to_int(n),
        "p": to_int(p),
        "support_rows": to_int(nrow),
        "orbit_cols": to_int(ncol),
        "nnz": to_int(nnz),
        "rank": to_int(rank),
        "nullity": to_int(len(basis)),
        "orbit_reps": [[to_int(x) for x in r] for r in reps],
        "basis": [[to_int(x) for x in vec] for vec in basis],
    }
    opener = gzip.open if path.endswith(".gz") else open
    mode = "wt" if path.endswith(".gz") else "w"
    with opener(path, mode) as fh:
        json.dump(payload, fh, separators=(",", ":"))

def basis_path_for(path, p, multi_prime):
    if not path:
        return None
    if "{p}" in path:
        return path.format(p=p)
    if not multi_prime:
        return path
    if path.endswith(".json.gz"):
        return path[:-8] + ".p%d.json.gz" % p
    if path.endswith(".gz"):
        return path[:-3] + ".p%d.gz" % p
    root, ext = os.path.splitext(path)
    return root + ".p%d" % p + ext

def nullity_from_tsv(n, p, tsv_path, verbose=True, save_basis=None):
    """Load an already-generated support-row TSV matrix and compute rank/kernel.

    This is used for restart/salvage: support_transform can generate missing
    columns separately, then the TSVs can be concatenated and ranked here without
    recomputing the transform.
    """
    import time
    t0 = time.time()
    reps = orbit_reps(n)
    ncol = len(reps)
    nrow = len(support(n))
    entries = {}
    nnz = 0
    with open(tsv_path) as fh:
        for lineno, line in enumerate(fh, 1):
            if not line.strip():
                continue
            fields = line.split()
            if len(fields) != 3:
                raise RuntimeError("bad TSV line %d in %s: %r" % (lineno, tsv_path, line[:80]))
            r, c, v = [int(x) for x in fields]
            if r < 0 or r >= nrow or c < 0 or c >= ncol:
                raise RuntimeError("TSV index out of range at line %d: row=%d col=%d for shape %d x %d"
                                   % (lineno, r, c, nrow, ncol))
            entries[(r, c)] = v
            nnz += 1
    if len(entries) != nnz:
        raise RuntimeError("duplicate TSV entries detected: %d lines but %d distinct positions"
                           % (nnz, len(entries)))
    M = matrix(GF(p), nrow, ncol, entries, sparse=True)
    t1 = time.time()
    rk = M.rank()
    t_rank = time.time() - t1
    nul = ncol - rk
    t_kernel = 0.0
    if save_basis:
        t2 = time.time()
        basis = M.right_kernel().basis()
        t_kernel = time.time() - t2
        write_basis_json(save_basis, n, p, nrow, ncol, nnz, rk, basis, reps)
    if verbose:
        extra = ""
        if save_basis:
            extra = ", kernel %.1fs, wrote %s" % (t_kernel, save_basis)
        print("  n=%d p=%d : loaded %s support-rows=%d orbit-cols=%d nnz=%d rank=%d NULLITY=%d  (load+matrix %.1fs, rank %.1fs%s)"
              % (n, p, tsv_path, nrow, ncol, nnz, rk, nul, t1-t0, t_rank, extra), flush=True)
    return nul

def support_nullity_compiled(n, p, verbose=True, max_cols=0, progress_every=None, threads=1,
                             save_basis=None):
    """Support-row-only self-equation matrix using the compiled coefficient engine.

    This assumes the support-only conjecture being tested here: rows outside the
    admissible support are not needed to pin the invariant-space dimension.  The
    compiled engine computes only target coefficients in the support row set.
    """
    import time
    t0 = time.time()
    exe = compile_support_transform(verbose=verbose)
    fd, path = tempfile.mkstemp(prefix="triweight_support_%d_%d_" % (n, p), suffix=".tsv")
    os.close(fd)
    try:
        pe = progress_every or 0
        cmd = [exe, str(int(n)), str(int(p)), path, str(int(max_cols or 0)), str(int(pe)), str(int(threads or 1))]
        stderr_target = None if verbose else subprocess.PIPE
        proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=stderr_target, check=True)
        meta_line = proc.stdout.strip().splitlines()[-1]
        m = re.search(r"rows=(\d+) cols=(\d+) emitted_cols=(\d+) nnz=(\d+) seconds=([0-9.eE+-]+)", meta_line)
        if not m:
            raise RuntimeError("could not parse support_transform output: %r" % proc.stdout)
        nrow, ncol, emitted_cols, nnz = [int(m.group(i)) for i in range(1, 5)]
        t_build = float(m.group(5))
        if max_cols and emitted_cols < ncol:
            if verbose:
                print("  n=%d p=%d support-rows=%d cols=%d emitted_cols=%d nnz=%d  (compiled build %.2fs; rank skipped)"
                      % (n, p, nrow, ncol, emitted_cols, nnz, t_build), flush=True)
            return None
        entries = {}
        with open(path) as fh:
            for line in fh:
                r, c, v = [int(x) for x in line.split()]
                entries[(r, c)] = v
        M = matrix(GF(p), nrow, ncol, entries, sparse=True)
        t1 = time.time()
        rk = M.rank()
        t_rank = time.time() - t1
        nul = ncol - rk
        t_kernel = 0.0
        if save_basis:
            t2 = time.time()
            K = M.right_kernel()
            basis = K.basis()
            t_kernel = time.time() - t2
            reps = orbit_reps(n)
            if len(reps) != ncol:
                raise RuntimeError("orbit rep count %d != matrix columns %d" % (len(reps), ncol))
            write_basis_json(save_basis, n, p, nrow, ncol, nnz, rk, basis, reps)
        if verbose:
            extra = ""
            if save_basis:
                extra = ", kernel %.1fs, wrote %s" % (t_kernel, save_basis)
            print("  n=%d p=%d : support-rows=%d orbit-cols=%d nnz=%d rank=%d NULLITY=%d  (compiled build %.1fs, read+rank %.1fs%s)"
                  % (n, p, nrow, ncol, nnz, rk, nul, t_build, (time.time()-t0)-t_build, extra), flush=True)
        return nul
    finally:
        try:
            os.remove(path)
        except OSError:
            pass

def parse_args(argv):
    primes = list(PRIMES)
    progress_every = None
    support_only = False
    compiled = False
    max_cols = 0
    threads = 1
    save_basis = None
    input_tsv = None
    ns = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--primes":
            primes = [int(x) for x in argv[i+1].split(",") if x]
            i += 2
        elif a == "--progress-every":
            progress_every = int(argv[i+1])
            i += 2
        elif a == "--support-only":
            support_only = True
            i += 1
        elif a == "--compiled":
            compiled = True
            i += 1
        elif a == "--max-cols":
            max_cols = int(argv[i+1])
            i += 2
        elif a == "--threads":
            threads = int(argv[i+1])
            i += 2
        elif a == "--save-basis":
            save_basis = argv[i+1]
            i += 2
        elif a == "--input-tsv":
            input_tsv = argv[i+1]
            i += 2
        else:
            ns.append(int(a))
            i += 1
    return ns or [8, 16, 24], primes, progress_every, support_only, compiled, max_cols, threads, save_basis, input_tsv

if __name__ == "__main__" and not os.environ.get("SELFEQ_NOMAIN"):
    ns, primes, progress_every, support_only, compiled, max_cols, threads, save_basis, input_tsv = parse_args(sys.argv[1:])
    for n in ns:
        import time; t = time.time()
        if input_tsv:
            if len(ns) != 1 or len(primes) != 1:
                raise ValueError("--input-tsv expects exactly one n and one prime")
            vals = [nullity_from_tsv(
                n, primes[0],
                input_tsv,
                save_basis=basis_path_for(save_basis, primes[0], False),
            )]
        elif support_only and compiled:
            vals = [support_nullity_compiled(
                n, p,
                progress_every=progress_every,
                max_cols=max_cols,
                threads=threads,
                save_basis=basis_path_for(save_basis, p, len(primes) > 1),
            ) for p in primes]
        elif support_only:
            raise ValueError("--support-only currently requires --compiled")
        else:
            vals = [nullity(n, p, progress_every=progress_every) for p in primes]
        exp = D3.get(n, "?")
        vals_done = [v for v in vals if v is not None]
        ok = bool(vals_done) and (len(set(vals_done)) == 1) and (exp == "?" or vals_done[0] == exp)
        if max_cols:
            ok = True
        print("n=%2d : nullity=%s (expect D_3=%s)  %s  [%.1fs]" %
              (n, vals, exp, "OK" if ok else "MISMATCH", time.time()-t), flush=True)
