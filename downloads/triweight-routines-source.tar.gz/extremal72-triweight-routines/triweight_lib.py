#!/usr/bin/env python3
"""
Core machinery for the genus-3 (triweight) enumerator of binary Type II codes.

A genus-3 enumerator is stored as a dict { exptuple : coeff } where exptuple is
an 8-tuple (n_000, n_001, ..., n_111) indexed by p = a + 2b + 4c (a=u-bit,
b=v-bit, c=w-bit), summing to the length n.  The enumerator of a code C is

    T_C(x) = sum_{(u,v,w) in C^3}  prod_{p} x_p^{ n_p(u,v,w) }.

This module provides:
  - small Type II codes (e8, and direct sums),
  - a numpy brute-force genus-3 enumerator,
  - the direct-sum product (= polynomial product of enumerators),
  - exact evaluation + the genus-3 MacWilliams self-equation check,
  - the order-48 symmetry group and a G-invariance check.

Validated in validate_small.py (run there, not here).
"""
import numpy as np
from itertools import product as iproduct, permutations
from collections import defaultdict

# Gleason weight set for the [72,36,16] target (used only for length-72 support).
W72 = [0, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 72]

# ---------------------------------------------------------------------------
# 8x8 sign / Hadamard data:  sign[p,q] = (-1)^popcount(p & q)
# ---------------------------------------------------------------------------
SIGN = np.empty((8, 8), dtype=np.int64)
for _p in range(8):
    for _q in range(8):
        SIGN[_p, _q] = -1 if bin(_p & _q).count('1') % 2 else 1


# ---------------------------------------------------------------------------
# order-48 symmetry group  G = S_3 |x (Z/2)^3  as permutations of the 8 indices
# (S_3 permutes the bit positions a,b,c; (Z/2)^3 flips bits = translations
#  u->u+1, v->v+1, w->w+1, valid because 1_n is in every Type II code).
# ---------------------------------------------------------------------------
def _build_group():
    perms = set()
    for axis in permutations(range(3)):
        for flip in iproduct([0, 1], repeat=3):
            perm = [0] * 8
            for v in iproduct([0, 1], repeat=3):
                a, b, c = v
                w = (v[axis[0]] ^ flip[0], v[axis[1]] ^ flip[1], v[axis[2]] ^ flip[2])
                src = a + 2 * b + 4 * c
                dst = w[0] + 2 * w[1] + 4 * w[2]
                perm[src] = dst
            perms.add(tuple(perm))
    return [list(p) for p in perms]


GROUP48 = _build_group()
assert len(GROUP48) == 48


# ---------------------------------------------------------------------------
# small Type II codes (as (M, n) 0/1 numpy arrays of all codewords)
# ---------------------------------------------------------------------------
def codewords_from_generators(gens):
    """All 2^k codewords from a list of generator rows (lists of 0/1)."""
    G = np.array(gens, dtype=np.int8)
    k, n = G.shape
    cws = np.zeros((1 << k, n), dtype=np.int8)
    for mask in range(1 << k):
        w = np.zeros(n, dtype=np.int8)
        for j in range(k):
            if (mask >> j) & 1:
                w ^= G[j]
        cws[mask] = w
    return cws


def e8():
    """[8,4,4] = RM(1,3) extended Hamming, the unique Type II code of length 8."""
    return codewords_from_generators([
        [1, 1, 1, 1, 1, 1, 1, 1],
        [0, 1, 0, 1, 0, 1, 0, 1],
        [0, 0, 1, 1, 0, 0, 1, 1],
        [0, 0, 0, 0, 1, 1, 1, 1],
    ])


def direct_sum(C1, C2):
    """Codeword array of C1 (+) C2 (length n1+n2)."""
    M1, n1 = C1.shape
    M2, n2 = C2.shape
    out = np.zeros((M1 * M2, n1 + n2), dtype=np.int8)
    idx = 0
    for i in range(M1):
        for j in range(M2):
            out[idx, :n1] = C1[i]
            out[idx, n1:] = C2[j]
            idx += 1
    return out


# ---------------------------------------------------------------------------
# brute-force genus-3 enumerator
# ---------------------------------------------------------------------------
def genus3_enum_brute(C, verbose=False):
    """T_C as { exptuple : count }, by enumerating all |C|^3 triples.
    Vectorized over the third codeword w."""
    M, n = C.shape
    C = C.astype(np.int64)
    enum = defaultdict(int)
    for iu in range(M):
        u = C[iu]
        for iv in range(M):
            base = u + 2 * C[iv]                 # (n,)
            pats = base[None, :] + 4 * C          # (M, n), value = u+2v+4w per coord
            cnts = np.stack([(pats == val).sum(axis=1) for val in range(8)], axis=1)  # (M,8)
            uniq, counts = np.unique(cnts, axis=0, return_counts=True)
            for row, c in zip(uniq, counts):
                enum[tuple(int(x) for x in row)] += int(c)
        if verbose and (iu % 32 == 0):
            print("    u-index %d/%d, monomials so far %d" % (iu, M, len(enum)))
    return dict(enum)


# ---------------------------------------------------------------------------
# FAST genus-3 enumerator: for fixed u, the 7 subset-weights over all (v,w)
# pairs are bilinear forms in the codewords, computed by matrix products; the
# exptuple is then recovered by the inverse Hadamard transform.  Vectorized over
# the whole (v,w) grid per u; ~10^3 x faster than the per-(u,v) brute routine.
#
#   wt(x+y) = wt(x) + wt(y) - 2 <x,y>,  so popcount(v^w) = wv+ww-2 C C^T, etc.
#   h_S = n - 2 w_S  (h_emptyset = n);  n_p = (1/8) sum_S (-1)^{<p,S>} h_S.
# ---------------------------------------------------------------------------
_BASE = 128  # counts <= n < 128 -> 8-digit base-128 key fits in int64
_POW = np.array([_BASE ** p for p in range(8)], dtype=np.int64)


# precompute, per output index p, the sign coefficients used in the rank-1
# decomposition of  n_p = (1/8) sum_{S=0}^7 sign(p,S) h_S  with
#   h_0=n, h_1=n-2 wt_u, h_2/h_3 = n-2 wt_v / n-2 wtA (cols over v),
#   h_4/h_5 = n-2 wt_w / n-2 wtA_w (rows over w),
#   h_6 = n-2 wt_v -2 wt_w +4<v,w>,  h_7 = n-2 wtA -2 wt_w +4<u+v,w>.
# grouped into scalar + col(v) + row(w) + grid parts.
_SP = SIGN  # alias; _SP[p,S]


def _keys_for_u(C, wt, iu, wblock):
    """Counter of exptuple-keys from a single u, chunked over the w-axis to bound
    memory.  Only two full (M, b) grids (P6=<v,w>, P7=<u+v,w>) are materialized."""
    from collections import Counter
    M, n = C.shape
    u = C[iu]
    A = (C + u[None, :]) & 1                  # u (+) v, (M,n) 0/1
    wtA = A.sum(axis=1).astype(np.int64)      # wt(u+v) per v
    wt_u = int(wt[iu])
    s = _SP
    total = Counter()
    for w0 in range(0, M, wblock):
        Cw = C[w0:w0 + wblock]
        b = Cw.shape[0]
        wtw = wt[w0:w0 + wblock]              # (b,)
        wtAw = wtA[w0:w0 + wblock]            # wtA indexed by w
        P6 = (C @ Cw.T).astype(np.int64)      # <v,w>   (M,b)
        P7 = (A @ Cw.T).astype(np.int64)      # <u+v,w> (M,b)
        key = np.zeros((M, b), dtype=np.int64)
        for p in range(8):
            sp = s[p]
            scal = n * (int(sp[0]) + int(sp[1])) - 2 * wt_u * int(sp[1])
            col = (n * (int(sp[2]) + int(sp[3]) + int(sp[6]) + int(sp[7]))
                   - 2 * wt * (int(sp[2]) + int(sp[6]))
                   - 2 * wtA * (int(sp[3]) + int(sp[7])))          # (M,)
            row = (n * (int(sp[4]) + int(sp[5]))
                   - 2 * wtw * (int(sp[4]) + int(sp[6]) + int(sp[7]))
                   - 2 * wtAw * int(sp[5]))                        # (b,)
            acc = (scal + col[:, None] + row[None, :]).astype(np.int64)
            if sp[6]:
                acc += (4 * int(sp[6])) * P6
            if sp[7]:
                acc += (4 * int(sp[7])) * P7
            acc //= 8
            key += acc * _POW[p]
        uk, uc = np.unique(key, return_counts=True)
        for kk, cc in zip(uk.tolist(), uc.tolist()):
            total[kk] += cc
        del P6, P7, key
    return total


def _decode_keys(total):
    enum = {}
    for kk, cc in total.items():
        e = tuple(int((kk // (_BASE ** p)) % _BASE) for p in range(8))
        enum[e] = cc
    return enum


def genus3_enum_fast(C, wblock=1024, verbose=False):
    """T_C as { exptuple : count } via the matmul/Hadamard method (serial)."""
    from collections import Counter
    C = np.ascontiguousarray(C.astype(np.int64))
    M, n = C.shape
    wt = C.sum(axis=1).astype(np.int64)
    total = Counter()
    for iu in range(M):
        total.update(_keys_for_u(C, wt, iu, wblock))
        if verbose and iu % max(1, M // 8) == 0:
            print("    fast: u %d/%d" % (iu, M))
    return _decode_keys(total)


# parallel driver (multiprocessing over the u-index); memory-bounded
_PAR = {}


def _par_init(C, wt, wblock):
    _PAR['C'], _PAR['wt'], _PAR['wblock'] = C, wt, wblock


def _par_work(u_indices):
    from collections import Counter
    C, wt, wblock = _PAR['C'], _PAR['wt'], _PAR['wblock']
    total = Counter()
    for iu in u_indices:
        total.update(_keys_for_u(C, wt, iu, wblock))
    return total


def genus3_enum_parallel(C, nproc=None, wblock=1024, verbose=True):
    """Parallel genus-3 enumerator: splits the u-index over nproc processes.
    Memory per process is bounded by ~ M*wblock*8 bytes for a few arrays."""
    import os
    from collections import Counter
    from multiprocessing import Pool
    if nproc is None:
        nproc = min(10, max(1, os.cpu_count() - 1))
    C = np.ascontiguousarray(C.astype(np.int64))
    M, n = C.shape
    wt = C.sum(axis=1).astype(np.int64)
    # split u-indices into ~4*nproc tasks for load balance + bounded peak memory
    ntask = max(nproc, 4 * nproc)
    tasks = [list(range(i, M, ntask)) for i in range(ntask)]
    if verbose:
        print("  genus3 parallel: M=%d n=%d nproc=%d wblock=%d tasks=%d"
              % (M, n, nproc, wblock, ntask))
    total = Counter()
    done = 0
    with Pool(nproc, initializer=_par_init, initargs=(C, wt, wblock)) as pool:
        for part in pool.imap_unordered(_par_work, tasks):
            total.update(part)
            done += 1
            if verbose:
                print("    task %d/%d done, distinct keys %d" % (done, ntask, len(total)))
    return _decode_keys(total)


# ---------------------------------------------------------------------------
# direct-sum product of enumerators  (T_{C1 (+) C2} = T_{C1} * T_{C2})
# ---------------------------------------------------------------------------
def enum_product(e1, e2):
    out = defaultdict(int)
    for a, ca in e1.items():
        for b, cb in e2.items():
            s = (a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3],
                 a[4] + b[4], a[5] + b[5], a[6] + b[6], a[7] + b[7])
            out[s] += ca * cb
    return dict(out)


def enum_power(e, k):
    """k-fold product of an enumerator with itself (k>=1)."""
    out = e
    for _ in range(k - 1):
        out = enum_product(out, e)
    return out


# ---------------------------------------------------------------------------
# exact evaluation + genus-3 MacWilliams self-equation
# ---------------------------------------------------------------------------
def eval_enum(enum, x):
    """Exact value of the enumerator polynomial at integer 8-vector x (Python ints)."""
    total = 0
    for exptuple, c in enum.items():
        term = c
        for p in range(8):
            e = exptuple[p]
            if e:
                term *= x[p] ** e
        total += term
    return total


def hadamard_transform_point(x):
    """y_p = sum_q (-1)^{<p,q>} x_q  (the 8x8 Hadamard H^(x)3 applied to x)."""
    return [sum(int(SIGN[p, q]) * x[q] for q in range(8)) for p in range(8)]


def check_self_equation(enum, n, trials=4, seed=0):
    """Genus-3 self-dual MacWilliams identity:  2^{3n/2} T(x) = T(H^3 x).
    Verified as a polynomial identity by exact evaluation at random integer points."""
    rng = np.random.default_rng(seed)
    scale = 1 << (3 * n // 2)          # 2^{3n/2}
    for _ in range(trials):
        x = [int(v) for v in rng.integers(-7, 8, size=8)]
        y = hadamard_transform_point(x)
        lhs = scale * eval_enum(enum, x)
        rhs = eval_enum(enum, y)
        if lhs != rhs:
            return False, (x, lhs, rhs)
    return True, None


def check_G_invariance(enum):
    """Enumerator coefficients constant on order-48 orbits (translations + S_3)."""
    for exptuple, c in enum.items():
        for perm in GROUP48:
            img = tuple(exptuple[perm[p]] for p in range(8))
            if enum.get(img, 0) != c:
                return False, (exptuple, img)
    return True, None


# ---------------------------------------------------------------------------
# lower-genus marginals by variable MERGING (not restriction).
# Genus-(g-1) enumerator = substitute x_{abc...} -> (drop a coordinate's bit),
# which sums coefficients; the code-size factor |C|^{#dropped} is divided out.
# ---------------------------------------------------------------------------
def genus2_marginal(enum, code_size):
    """Merge the w-bit (c): x_abc -> y_ab.  Returns { (n00,n01,n10,n11) : coeff }
    with y-index ab = a + 2b.  Equals |C| * (genus-2 biweight), so divide by |C|.
    Result is the biweight T^{(2)} with coeffs N(wu,wv,t)."""
    out = defaultdict(int)
    for e, c in enum.items():
        # genus-3 p = a+2b+4c ; merge over c -> ab = a+2b
        key = [0, 0, 0, 0]
        for p in range(8):
            ab = p & 3                      # a + 2b
            key[ab] += e[p]
        out[tuple(key)] += c
    assert all(v % code_size == 0 for v in out.values()), "genus-2 marginal not divisible by |C|"
    return {k: v // code_size for k, v in out.items()}


def genus1_marginal(enum, code_size):
    """Merge the v- and w-bits (b,c): x_abc -> z_a.  Returns { (m0,m1) : coeff }
    where m_a = sum of n_p over p with a-bit = a.  Equals |C|^2 * (Hamming
    enumerator), so divide by |C|^2."""
    out = defaultdict(int)
    for e, c in enum.items():
        m0 = e[0] + e[2] + e[4] + e[6]      # p even -> a-bit 0
        m1 = e[1] + e[3] + e[5] + e[7]      # p odd  -> a-bit 1
        out[(m0, m1)] += c
    cs2 = code_size * code_size
    assert all(v % cs2 == 0 for v in out.values()), "genus-1 marginal not divisible by |C|^2"
    return {k: v // cs2 for k, v in out.items()}
