#!/usr/bin/env python3
"""
The shared coordinate system for the genus-3 (triweight) computation: the 78,690
orbits of the order-48 symmetry group G = S_3 |x (Z/2)^3 acting on the 3.49M
length-72 support monomials (8-tuples n_p, p = a + 2b + 4c, sum = 72).

Every G-invariant enumerator (a genus-3 code enumerator, or any element of the
degree-72 invariant ring) is constant on these orbits, so it is faithfully
represented by ONE coefficient per orbit -- an integer vector of length <= 78,690.
build_basis.py / marginals.py / solve_and_test.py all work in these coordinates.

This module provides:
  - canon(exptuple): the canonical representative of an 8-tuple's G-orbit
    (lexicographically minimal image under the 48 permutations); usable on ANY
    8-tuple, not just length-72 support, so it also canonicalizes products of
    shorter-length enumerators.
  - build_table(): enumerate the length-72 support, group into orbits, and
    persist canonical reps + orbit sizes to triweight_orbits.npz.
  - load_table(): reload {rep -> orbit id}, sizes, and reps.

Run `python3 triweight_orbits.py` to (re)build and validate the table; the count
must match count_orbits.py (78,690 orbits over 3,487,009 monomials).
"""
import numpy as np

from triweight_lib import GROUP48

# permutation table as an array for fast vectorized canonicalization
_PERMS = np.array(GROUP48, dtype=np.int64)            # (48, 8)
W = np.array([0, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 72], dtype=np.int64)
_SIGN = np.empty((8, 8), dtype=np.int64)
for _p in range(8):
    for _S in range(8):
        _SIGN[_p, _S] = -1 if bin(_p & _S).count('1') % 2 else 1
_PAIRS = [(3, 7), (5, 7), (6, 7)]                     # <u,v>,<u,w>,<v,w> even

NPZ = "triweight_orbits.npz"


def canon(t):
    """Canonical (lexicographically minimal) representative of the G-orbit of an
    8-tuple t, as a tuple. Works for any nonnegative 8-tuple (any total degree)."""
    a = np.asarray(t, dtype=np.int64)
    imgs = a[_PERMS]                                  # (48, 8): imgs[k] = t[perm_k]
    # lexicographically minimal row
    best = min(map(tuple, imgs.tolist()))
    return best


def canon_array(M):
    """Canonicalize every row of an (N,8) int array; returns (N,8) canon array."""
    N = M.shape[0]
    # imgs[k] applied to all rows: M[:, perm_k] ; stack and take lexicographic min
    out = M.copy()
    for k in range(_PERMS.shape[0]):
        cand = M[:, _PERMS[k]]
        # lexicographic compare cand < out, row-wise
        swap = _lex_less(cand, out)
        out[swap] = cand[swap]
    return out


def _lex_less(A, B):
    """Row-wise lexicographic A < B for (N,8) arrays -> boolean (N,)."""
    less = np.zeros(A.shape[0], dtype=bool)
    settled = np.zeros(A.shape[0], dtype=bool)
    for c in range(A.shape[1]):
        lt = (A[:, c] < B[:, c]) & ~settled
        gt = (A[:, c] > B[:, c]) & ~settled
        less |= lt
        settled |= lt | gt
    return less


def enumerate_support():
    """All length-72 support 8-tuples (n_p) as an (M,8) int array.
    Same admissibility filter as count_support.py."""
    chunks = []
    for wu in W:
        for wv in W:
            g = np.array(np.meshgrid(W, W, W, W, W, indexing='ij')).reshape(5, -1).T
            N = g.shape[0]
            h = np.empty((N, 8), dtype=np.int64)
            h[:, 0] = 72
            h[:, 1] = 72 - 2 * wu
            h[:, 2] = 72 - 2 * wv
            for k in range(5):
                h[:, 3 + k] = 72 - 2 * g[:, k]
            n = h @ _SIGN.T
            ok = np.all(n % 8 == 0, axis=1)
            n8 = n // 8
            ok &= np.all(n8 >= 0, axis=1)
            for (i, j) in _PAIRS:
                ok &= ((n8[:, i] + n8[:, j]) % 2 == 0)
            if ok.any():
                chunks.append(n8[ok])
    return np.concatenate(chunks, axis=0).astype(np.int64)


def build_table():
    print("enumerating length-72 support ...")
    M = enumerate_support()
    print("  support monomials:", M.shape[0])
    print("canonicalizing under the 48 group elements ...")
    C = canon_array(M)
    # unique canonical reps + how many support monomials map to each (orbit size)
    reps, sizes = np.unique(C, axis=0, return_counts=True)
    print("  orbits (distinct reps):", reps.shape[0])
    np.savez_compressed(NPZ, reps=reps, sizes=sizes)
    print("  wrote", NPZ)
    return reps, sizes


def load_table():
    d = np.load(NPZ)
    reps, sizes = d["reps"], d["sizes"]
    index = {tuple(int(x) for x in r): i for i, r in enumerate(reps)}
    return index, sizes, reps


def enum_to_orbit_vector(enum, index):
    """Reduce a G-invariant enumerator dict {exptuple: coeff} to a length-len(index)
    integer vector in orbit coordinates (one coeff per orbit). Asserts the
    enumerator's support lies inside the known orbit table."""
    v = np.zeros(len(index), dtype=object)            # python ints (coeffs are huge)
    for e, c in enum.items():
        r = canon(e)
        j = index.get(r)
        if j is None:
            raise KeyError("monomial %s (canon %s) not in length-72 orbit table" % (e, r))
        v[j] = c
    return v


if __name__ == "__main__":
    from math import comb
    reps, sizes = build_table()
    assert int(sizes.sum()) == 3487009, sizes.sum()
    assert reps.shape[0] == 78690, reps.shape[0]
    # every coordinate of every rep must be the lexicographic minimum of its orbit
    print("sanity: total monomials = sum of orbit sizes =", int(sizes.sum()))
    print("orbit-size histogram (size:count):",
          dict(zip(*[a.tolist() for a in np.unique(sizes, return_counts=True)])))
    print("OK: 78,690 orbits over 3,487,009 support monomials.")
