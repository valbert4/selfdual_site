#!/usr/bin/env python3
"""Validate genus3_enum_fast against genus3_enum_brute, then time it."""
import time
import triweight_lib as L

# 1. correctness on e8 and e8(+)e8
C8 = L.e8()
b8 = L.genus3_enum_brute(C8)
f8 = L.genus3_enum_fast(C8)
print("e8  fast==brute:", b8 == f8, " (%d monomials)" % len(f8))

C16 = L.direct_sum(C8, C8)
b16 = L.genus3_enum_brute(C16)
t = time.time()
f16 = L.genus3_enum_fast(C16)
print("e8(+)e8 fast==brute:", b16 == f16, " (%d monomials, fast %.2fs)" % (len(f16), time.time() - t))

# cross-check self-equation on the fast result
ok, info = L.check_self_equation(f16, 16, trials=3)
print("e8(+)e8 self-equation (fast result):", ok)
