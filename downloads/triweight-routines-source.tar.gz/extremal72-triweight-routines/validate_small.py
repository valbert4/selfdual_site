#!/usr/bin/env python3
"""
Validate the genus-3 machinery on small Type II codes, BEFORE trusting it at
length 72 (mirrors the genus-2 validation-first discipline).

Checks:
  1. [8,4,4]: brute genus-3 enumerator satisfies 2^{3n/2} T(x)=T(H^3 x), is
     order-48 G-invariant, totals |C|^3, and its genus-1 marginal is the Hamming
     enumerator of e8.
  2. direct-sum product matches brute: T_{e8(+)e8} via enum_product equals the
     brute genus-3 enumerator of e8(+)e8 (validates BOTH the brute routine and
     the product operation).  e8(+)e8 self-equation + G-invariance at n=16.
  3. genus-2 marginal of the e8 genus-3 enumerator equals the e8 biweight
     (cross-check against a direct genus-2 brute count).
"""
from collections import Counter
import numpy as np

import triweight_lib as L


def biweight_brute(C):
    """Genus-2 (biweight) enumerator { (n00,n01,n10,n11): count } over C^2."""
    M, n = C.shape
    Ci = C.astype(np.int64)
    cnt = Counter()
    for iu in range(M):
        u = Ci[iu]
        pats = u[None, :] + 2 * Ci          # (M,n): u + 2v, value in {0,1,2,3}
        cc = np.stack([(pats == val).sum(axis=1) for val in range(4)], axis=1)
        uq, k = np.unique(cc, axis=0, return_counts=True)
        for row, c in zip(uq, k):
            cnt[tuple(int(x) for x in row)] += int(c)
    return dict(cnt)


def hamming_brute(C):
    M, n = C.shape
    cnt = Counter()
    for w in C:
        wt = int(w.sum())
        cnt[(n - wt, wt)] += 1
    return dict(cnt)


def main():
    print("=" * 70)
    print("VALIDATION 1: [8,4,4] = e8")
    print("=" * 70)
    C8 = L.e8()
    M, n = C8.shape
    print("  codewords:", M, " length:", n,
          " weights:", sorted(set(int(w.sum()) for w in C8)), "(expect {0,4,8})")
    T8 = L.genus3_enum_brute(C8)
    tot = sum(T8.values())
    print("  genus-3 monomials:", len(T8), " total coeff:", tot,
          " = |C|^3 =", M ** 3, "?", tot == M ** 3)

    ok_se, info = L.check_self_equation(T8, n, trials=5)
    print("  self-equation 2^{3n/2} T(x) = T(H^3 x):", ok_se, "" if ok_se else info)
    ok_g, info = L.check_G_invariance(T8)
    print("  order-48 G-invariance:", ok_g, "" if ok_g else info)

    g1 = L.genus1_marginal(T8, M)
    ham = hamming_brute(C8)
    print("  genus-1 marginal == Hamming enumerator:", g1 == ham, " ", sorted(g1.items()))

    g2 = L.genus2_marginal(T8, M)
    bi = biweight_brute(C8)
    print("  genus-2 marginal == biweight (brute):", g2 == bi,
          " (%d vs %d monomials)" % (len(g2), len(bi)))

    print()
    print("=" * 70)
    print("VALIDATION 2: e8 (+) e8  [16,8,4]  -- product vs brute")
    print("=" * 70)
    C16 = L.direct_sum(C8, C8)
    M16, n16 = C16.shape
    print("  codewords:", M16, " length:", n16)
    T16_prod = L.enum_product(T8, T8)
    print("  product enumerator monomials:", len(T16_prod),
          " total:", sum(T16_prod.values()), " = |C|^3 =", M16 ** 3,
          "?", sum(T16_prod.values()) == M16 ** 3)
    print("  brute-forcing e8(+)e8 genus-3 (256^3 = 1.67e7 triples)...")
    T16_brute = L.genus3_enum_brute(C16, verbose=True)
    print("  product == brute:", T16_prod == T16_brute)

    ok_se, info = L.check_self_equation(T16_prod, n16, trials=4)
    print("  self-equation at n=16:", ok_se, "" if ok_se else info)
    ok_g, info = L.check_G_invariance(T16_prod)
    print("  order-48 G-invariance at n=16:", ok_g, "" if ok_g else info)

    print()
    print("ALL CHECKS:",
          "PASS" if (ok_se and ok_g and T16_prod == T16_brute and g1 == ham and g2 == bi)
          else "FAIL")


if __name__ == "__main__":
    main()
